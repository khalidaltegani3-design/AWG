# نظام تحرير ومعالجة الفيديو - Zoli Chat

## 📋 نظرة عامة

نظام متكامل لتصوير وتحرير ورفع الفيديوهات بأسلوب احترافي مشابه لتطبيقات Reels/TikTok.

## 🎯 المميزات الرئيسية

### 📹 التصوير (Capture)
- **واجهة ريلز احترافية**: Hold-to-Record للتصوير المستمر
- **Flip Camera**: التبديل بين الكاميرا الأمامية والخلفية
- **Flash Control**: التحكم في الفلاش (Auto/On/Off/Torch)
- **Grid Overlay**: شبكة لمساعدة في التكوين
- **60fps**: دعم تصوير بـ 60 إطار في الثانية
- **9:16 Aspect Ratio**: نسبة عرض مثالية للفيديوهات العمودية

### ✂️ التحرير (Edit)
- **Trim/Cut**: قص وتحديد مقاطع متعددة
- **Timeline**: شريط زمني تفاعلي للتحكم الدقيق
- **6 Filters (LUTs)**:
  1. **None**: بدون فلتر
  2. **Vivid**: ألوان حية (+20% saturation)
  3. **Film**: مظهر سينمائي
  4. **Mono**: أبيض وأسود
  5. **Cinema**: درجات سينمائية
  6. **Pop**: ألوان منبثقة
  7. **Natural**: تحسين طبيعي
- **Speed Control**: التحكم في سرعة الفيديو (0.5x - 2x)
- **Text Overlay**: إضافة نصوص
- **Audio Controls**: التحكم في الصوت

### 🗜️ الضغط (Compress)
- **Automatic Quality**: اختيار تلقائي للجودة حسب:
  - طول الفيديو
  - دقة الفيديو
  - حجم الملف
- **Quality Presets**:
  - **Low**: ضغط عالي (للملفات الكبيرة)
  - **Medium**: توازن (افتراضي)
  - **High**: جودة عالية (للملفات الصغيرة)
- **Size Limit**: حد أقصى 200MB مع تنبيه
- **Compression Ratio**: عرض نسبة الضغط

### ☁️ الرفع (Upload)
- **Progress Bar**: شريط تقدم حقيقي من الإنكودر
- **Status Updates**: تحديثات مباشرة للحالة
- **Frame Preview**: معاينة الإطار الرئيسي أثناء الانتظار
- **Firebase Integration**: رفع مباشر لـ Firebase Storage

## 📦 المكتبات المستخدمة

### الأساسية
```yaml
camerawesome: ^2.0.4        # التصوير الاحترافي
video_editor: ^3.0.2        # محرر الفيديو
light_compressor: ^2.1.3    # ضغط خفيف وسريع
```

### الدعم
```yaml
video_player: ^2.8.2        # تشغيل الفيديو
path_provider: ^2.1.5       # إدارة المسارات
connectivity_plus: ^5.0.2   # فحص الاتصال
uuid: ^4.3.3                # معرفات فريدة
```

### معالجة الصوت
```yaml
just_audio: ^0.9.36         # تشغيل صوت
audio_waveforms: ^1.0.5     # موجات صوتية
```

## 🏗️ البنية (Pipeline)

```
┌──────────┐     ┌─────────┐     ┌──────┐     ┌──────────┐     ┌────────┐
│ Capture  │ --> │ Preview │ --> │ Edit │ --> │ Compress │ --> │ Upload │
└──────────┘     └─────────┘     └──────┘     └──────────┘     └────────┘
     │                                │              │              │
  Camera                           Trim          Quality        Firebase
  Settings                        Filter         Selection       Storage
  Grid                            Speed          Size Check
  Flash                           Text           Progress
  Flip                            Audio
```

## 🎬 إعدادات الجودة

### دقة الفيديو (Video Resolutions)
| Preset | الدقة | Bitrate | الاستخدام |
|--------|-------|---------|-----------|
| 720p   | 1280x720 | 5 Mbps | قياسي |
| 1080p  | 1920x1080 | 8 Mbps | عالي |
| 1440p  | 2560x1440 | 12 Mbps | فائق |

### معدل الإطارات (Frame Rate)
- **30fps**: افتراضي للحفاظ على البطارية
- **60fps**: متاح للفيديوهات الرياضية/الحركة

### جودة الضغط (Compression Quality)
| المستوى | CRF | نسبة الضغط | الاستخدام |
|---------|-----|-----------|-----------|
| Low     | 35  | 80%       | ملفات كبيرة |
| Medium  | 28  | 60%       | افتراضي |
| High    | 23  | 40%       | جودة عالية |

## 🔧 الإعداد

### 1. تثبيت المكتبات

```bash
flutter pub get
```

### 2. أذونات Android (AndroidManifest.xml)

```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
```

### 3. أذونات iOS (Info.plist)

```xml
<key>NSCameraUsageDescription</key>
<string>نحتاج الكاميرا لتصوير الفيديو</string>
<key>NSMicrophoneUsageDescription</key>
<string>نحتاج الميكروفون لتسجيل الصوت</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>نحتاج الوصول للمعرض لحفظ الفيديو</string>
```

## 📱 الاستخدام

### فتح شاشة التصوير

```dart
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => const ReelsCameraScreen(),
  ),
);
```

### تحرير فيديو موجود

```dart
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => VideoEditorScreen(
      videoFile: File('/path/to/video.mp4'),
    ),
  ),
);
```

## 🎨 الفلاتر المتاحة

### 1. Vivid (حيوي)
- زيادة التشبع +20%
- ألوان أكثر حيوية
- مناسب للطبيعة والمناظر

### 2. Film (سينمائي)
- مظهر فيلمي كلاسيكي
- ألوان دافئة
- تباين محسن

### 3. Mono (أحادي اللون)
- أبيض وأسود
- تباين عالي
- مظهر فني

### 4. Cinema (سينما)
- درجات لون سينمائية
- ألوان باردة قليلاً
- مناسب للأفلام القصيرة

### 5. Pop (منبثق)
- ألوان منبثقة ساطعة
- تشبع عالي جداً
- مناسب للمحتوى الترفيهي

### 6. Natural (طبيعي)
- تحسينات طفيفة
- ألوان واقعية
- مناسب للفلوقات

## 🔊 معالجة الصوت

### Normalization
- **Target**: -14 LUFS (معيار YouTube/Instagram)
- **Auto-leveling**: موازنة تلقائية للصوت
- **Peak limiting**: منع التشويه

### Noise Reduction
- **Light filter**: فلتر خفيف لإزالة الضوضاء
- **Preserve quality**: الحفاظ على جودة الصوت
- **Platform-native**: استخدام أدوات المنصة الأصلية

### Captions (الترجمة)
- **SRT/VTT Support**: دعم تنسيقات الترجمة
- **Burn-in Option**: دمج الترجمة في الفيديو (اختياري)
- **Multi-language**: دعم لغات متعددة

## 📊 التحليلات والأداء

### المقاييس المسجلة
```dart
- زمن المعالجة (Processing Time)
- أخطاء التصدير (Export Errors)
- نسبة الإلغاء (Cancellation Rate)
- حجم الملف قبل/بعد (File Size Before/After)
- نسبة الضغط (Compression Ratio)
- سرعة الرفع (Upload Speed)
```

### تحسين الأداء
- ✅ Hardware Acceleration مفعل
- ✅ تقليل نسخ الملفات المؤقتة
- ✅ معالجة متعددة الخيوط
- ✅ MediaCodec (Android) / AVFoundation (iOS)

## ⚠️ الحدود والقيود

### حدود الملف
- **الحجم الأقصى**: 200MB
- **المدة القصوى**: 60 ثانية (قابل للتعديل)
- **الدقة القصوى**: 1440p

### حدود الأداء
- **Android**: API 21+ (Lollipop)
- **iOS**: iOS 11+
- **RAM**: 2GB+ مستحسن
- **Storage**: 500MB مساحة حرة

## 🐛 استكشاف الأخطاء

### مشكلة: الكاميرا لا تعمل
```dart
// تحقق من الأذونات
await Permission.camera.request();
await Permission.microphone.request();
```

### مشكلة: الضغط بطيء
```dart
// استخدم جودة أقل
VideoQuality.low  // بدلاً من medium
```

### مشكلة: فشل التصدير
```dart
// تحقق من المساحة المتاحة
final dir = await getTemporaryDirectory();
// تنظيف الملفات القديمة
await videoProcessingService.cleanupTempFiles();
```

## 📈 خارطة الطريق

### النسخة القادمة (v2.0)
- [ ] Multi-clip editing (تحرير مقاطع متعددة)
- [ ] Advanced transitions (انتقالات متقدمة)
- [ ] Stickers and GIFs (ملصقات و GIFs)
- [ ] Music library (مكتبة موسيقى)
- [ ] Collaboration tools (أدوات تعاون)
- [ ] AI-powered features (مميزات AI)

### تحسينات مستقبلية
- [ ] Real-time filters (فلاتر في الوقت الفعلي)
- [ ] 3D effects (تأثيرات 3D)
- [ ] Green screen (شاشة خضراء)
- [ ] Motion tracking (تتبع الحركة)

## 🤝 المساهمة

نرحب بالمساهمات! الرجاء:
1. Fork المشروع
2. إنشاء branch جديد (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push للـ branch (`git push origin feature/amazing-feature`)
5. فتح Pull Request

## 📝 الترخيص

هذا المشروع مرخص تحت MIT License - راجع ملف LICENSE للتفاصيل.

## 📞 الدعم

للمساعدة والأسئلة:
- 📧 Email: support@zolichat.com
- 💬 Discord: Zoli Chat Community
- 📱 Twitter: @ZoliChat

## 🙏 الشكر

شكر خاص لمطوري المكتبات المستخدمة:
- [CamerAwesome](https://github.com/Apparence-io/camera_awesome)
- [VideoEditor](https://github.com/LeGoffMael/video_editor)
- [LightCompressor](https://github.com/AbedElazizShe/light_compressor)

---

Made with ❤️ by Zoli Chat Team
