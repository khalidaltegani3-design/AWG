# 🔥 دليل إعداد Firebase الشامل - مشروع Zoli Chat

## 📋 جدول المحتويات

1. [المتطلبات الأساسية](#المتطلبات-الأساسية)
2. [إعداد مشروع Firebase](#إعداد-مشروع-firebase)
3. [ربط التطبيق بـ Firebase](#ربط-التطبيق-بـ-firebase)
4. [تهيئة Android](#تهيئة-android)
5. [تهيئة iOS](#تهيئة-ios)
6. [تهيئة Web](#تهيئة-web)
7. [إعداد Security Rules](#إعداد-security-rules)
8. [إنشاء Indexes](#إنشاء-indexes)
9. [إعداد Cloud Functions](#إعداد-cloud-functions)
10. [التحقق من الإعداد](#التحقق-من-الإعداد)

---

## 🎯 المتطلبات الأساسية

### البيئة
- ✅ Flutter 3.22+ مثبت
- ✅ Dart 3.0+ مثبت
- ✅ Android Studio / Xcode مثبت
- ✅ Node.js 18+ (لـ Cloud Functions)
- ✅ Firebase CLI مثبت

### حساب Firebase
- حساب Google
- مشروع Firebase موجود مسبقاً

---

## 🔥 إعداد مشروع Firebase

### 1. الدخول إلى Firebase Console

```
https://console.firebase.google.com/
```

### 2. المشروع الحالي

استخدم المشروع الموجود مسبقاً. **لا تُنشئ مشروعاً جديداً**.

```
PROJECT_ID: <اسم-المشروع-الحالي>
```

### 3. تفعيل الخدمات المطلوبة

انتقل إلى Firebase Console وفعّل:

#### أ. Authentication
```
Build → Authentication → Get Started
```
- فعّل Phone Authentication

#### ب. Firestore Database
```
Build → Firestore Database → Create Database
```
- اختر موقع: `asia-southeast1` (أو الأقرب لقطر)
- ابدأ بـ Production Mode

#### ج. Storage
```
Build → Storage → Get Started
```
- استخدم الموقع نفسه

#### د. Cloud Messaging (FCM)
```
Build → Cloud Messaging
```
- سيتم تفعيله تلقائياً

#### هـ. Crashlytics
```
Build → Crashlytics → Enable
```

#### و. Performance Monitoring
```
Release & Monitor → Performance → Enable
```

#### ز. Remote Config
```
Engage → Remote Config → Get Started
```

#### ح. App Check
```
Build → App Check → Get Started
```

---

## 🔗 ربط التطبيق بـ Firebase

### 1. تثبيت FlutterFire CLI

```bash
dart pub global activate flutterfire_cli
```

تحقق من التثبيت:
```bash
flutterfire --version
```

### 2. تسجيل الدخول

```bash
firebase login
```

### 3. تهيئة المشروع

**مهم جداً**: استخدم المشروع الموجود مسبقاً

```bash
flutterfire configure --project=<EXISTING_PROJECT_ID> --platforms=android,ios,web
```

أمثلة:
```bash
# إذا كان PROJECT_ID هو: zoli-chat-qa
flutterfire configure --project=zoli-chat-qa --platforms=android,ios,web
```

### 4. ملف firebase_options.dart

سيتم إنشاء `lib/firebase_options.dart` تلقائياً.

**لا تعدّل هذا الملف يدوياً!**

---

## 📱 تهيئة Android

### 1. تحديث Bundle ID

في `android/app/build.gradle.kts`:

```kotlin
defaultConfig {
    applicationId = "com.awg.zoli"  // ✅ تم تحديثه
}
```

### 2. SHA-1 و SHA-256 للتطبيق

#### Debug SHA-1
```bash
cd android
./gradlew signingReport
```

أو (Windows):
```powershell
cd android
.\gradlew.bat signingReport
```

ابحث عن:
```
Variant: debug
SHA1: xx:xx:xx:...
SHA256: yy:yy:yy:...
```

#### Release SHA-1

إذا كان لديك keystore للإصدار:
```bash
keytool -list -v -keystore path/to/release.keystore -alias your-alias
```

### 3. إضافة SHA في Firebase Console

```
Project Settings → Android App → Add fingerprint
```

أضف:
- Debug SHA-1
- Debug SHA-256
- Release SHA-1 (إن وجد)
- Release SHA-256 (إن وجد)

### 4. تنزيل google-services.json

من Firebase Console:
```
Project Settings → Android App → Download google-services.json
```

ضعه في:
```
android/app/google-services.json
```

### 5. التحقق من build.gradle

تم التحديث تلقائياً! تأكد من:

#### android/build.gradle.kts
```kotlin
plugins {
    id("com.google.gms.google-services") version "4.4.2" apply false
    id("com.google.firebase.crashlytics") version "3.0.2" apply false
    id("com.google.firebase.firebase-perf") version "1.4.2" apply false
}
```

#### android/app/build.gradle.kts
```kotlin
plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
    id("com.google.firebase.firebase-perf")
}
```

### 6. Play Integrity API (App Check)

#### أ. تفعيل Play Integrity في Google Cloud

```
https://console.cloud.google.com/
```

1. اختر المشروع
2. APIs & Services → Library
3. ابحث عن "Play Integrity API"
4. اضغط Enable

#### ب. ربط Play Integrity في Firebase

```
Firebase Console → App Check → Android
```

1. اضغط Register
2. اختر Play Integrity

---

## 🍎 تهيئة iOS

### 1. تحديث Bundle ID

في `ios/Runner.xcodeproj` (عبر Xcode):

```
Bundle Identifier: com.awg.zoli
```

### 2. تنزيل GoogleService-Info.plist

من Firebase Console:
```
Project Settings → iOS App → Download GoogleService-Info.plist
```

ضعه في:
```
ios/Runner/GoogleService-Info.plist
```

**مهم**: افتح Xcode وأضف الملف إلى المشروع بسحبه إلى `Runner` folder.

### 3. تفعيل Push Notifications

في Xcode:
```
Runner → Signing & Capabilities → + Capability
```

أضف:
- ✅ Push Notifications
- ✅ Background Modes
  - ✅ Remote notifications
  - ✅ Background fetch

### 4. تحديث Info.plist

أضف الأذونات المطلوبة:

```xml
<key>NSCameraUsageDescription</key>
<string>نحتاج للوصول إلى الكاميرا لتسجيل الرمشات</string>

<key>NSMicrophoneUsageDescription</key>
<string>نحتاج للوصول إلى الميكروفون لتسجيل الصوت</string>

<key>NSPhotoLibraryUsageDescription</key>
<string>نحتاج للوصول إلى المعرض لاختيار الفيديوهات</string>

<key>NSPhotoLibraryAddUsageDescription</key>
<string>نحتاج لحفظ الفيديوهات في المعرض</string>
```

### 5. APNs (Push Notifications)

#### أ. إنشاء APNs Key

```
https://developer.apple.com/account/
```

1. Certificates, Identifiers & Profiles
2. Keys → Create a new key
3. اختر "Apple Push Notifications service (APNs)"
4. احفظ الـ Key ID و Key File (.p8)

#### ب. رفع APNs Key إلى Firebase

```
Firebase Console → Project Settings → Cloud Messaging → iOS
```

1. اضغط Upload APNs Authentication Key
2. ارفع الملف .p8
3. أدخل Key ID و Team ID

### 6. DeviceCheck (App Check)

```
Firebase Console → App Check → iOS
```

1. اضغط Register
2. اختر DeviceCheck
3. احفظ Token

---

## 🌐 تهيئة Web

### 1. تحديث index.html

في `web/index.html`:

```html
<!-- Firebase SDK -->
<script src="https://www.gstatic.com/firebasejs/10.0.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.0.0/firebase-messaging.js"></script>

<script>
  // تم إنشاؤه تلقائياً في firebase_options.dart
</script>
```

### 2. firebase-messaging-sw.js

أنشئ `web/firebase-messaging-sw.js`:

```javascript
importScripts('https://www.gstatic.com/firebasejs/10.0.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/10.0.0/firebase-messaging.js');

firebase.initializeApp({
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
});

const messaging = firebase.messaging();
```

### 3. ReCaptcha v3 (App Check)

```
Firebase Console → App Check → Web
```

1. سجّل موقعك
2. احصل على ReCaptcha v3 site key
3. أضفه في `main.dart`:

```dart
webProvider: ReCaptchaV3Provider('YOUR_RECAPTCHA_SITE_KEY'),
```

---

## 🔒 إعداد Security Rules

### 1. Firestore Rules

أنشئ/حدّث `firestore.rules`:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper functions
    function isSignedIn() {
      return request.auth != null;
    }
    
    function isOwner(uid) {
      return isSignedIn() && request.auth.uid == uid;
    }
    
    // Users collection
    match /users/{uid} {
      allow read: if isSignedIn();
      allow write: if isOwner(uid);
      
      // User tokens (FCM)
      match /tokens/{token} {
        allow read, write: if isOwner(uid);
      }
    }
    
    // Ramshat collection - READ-ONLY للعامة
    match /ramshat/{ramshaId} {
      // الجميع يمكنهم قراءة الرمشات المنشورة فقط
      allow read: if resource.data.visibility == 'public' 
                  && resource.data.status == 'published';
      
      // فقط المالك يمكنه الكتابة
      allow create: if isSignedIn() 
                    && request.resource.data.uid == request.auth.uid;
      allow update, delete: if isOwner(resource.data.uid);
    }
    
    // Chats - خاص بالمستخدمين المشاركين
    match /chats/{chatId} {
      allow read, write: if isSignedIn() 
                         && request.auth.uid in resource.data.participants;
    }
    
    // Messages
    match /chats/{chatId}/messages/{messageId} {
      allow read: if isSignedIn() 
                  && request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.participants;
      allow create: if isSignedIn();
    }
  }
}
```

### 2. Storage Rules

أنشئ/حدّث `storage.rules`:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    
    // Helper functions
    function isSignedIn() {
      return request.auth != null;
    }
    
    function isOwner(uid) {
      return isSignedIn() && request.auth.uid == uid;
    }
    
    function isValidImage() {
      return request.resource.contentType.matches('image/.*');
    }
    
    function isValidVideo() {
      return request.resource.contentType.matches('video/.*');
    }
    
    // Ramshat videos
    match /ramshat/{uid}/{ramshaId}/{file} {
      allow read: if true; // عام للقراءة
      allow write: if isOwner(uid) 
                   && (isValidVideo() || isValidImage())
                   && request.resource.size < 100 * 1024 * 1024; // 100MB max
    }
    
    // Profile images
    match /users/{uid}/profile.jpg {
      allow read: if true;
      allow write: if isOwner(uid) 
                   && isValidImage()
                   && request.resource.size < 5 * 1024 * 1024; // 5MB max
    }
    
    // Stories
    match /stories/{uid}/{storyId}.jpg {
      allow read: if true;
      allow write: if isOwner(uid) 
                   && isValidImage()
                   && request.resource.size < 10 * 1024 * 1024; // 10MB max
    }
  }
}
```

### 3. نشر Rules

```bash
firebase deploy --only firestore:rules
firebase deploy --only storage:rules
```

---

## 📊 إنشاء Indexes

### 1. Indexes المطلوبة للرمشات

انتقل إلى:
```
Firebase Console → Firestore → Indexes
```

أنشئ Composite Index:

#### Feed Query
```
Collection: ramshat
Fields:
  - visibility: Ascending
  - status: Ascending
  - createdAt: Descending
```

#### User Ramshat Query
```
Collection: ramshat
Fields:
  - uid: Ascending
  - createdAt: Descending
```

#### Trending Query (إن لزم)
```
Collection: ramshat
Fields:
  - visibility: Ascending
  - status: Ascending
  - views: Descending
```

### 2. إنشاء Indexes تلقائياً

عند تشغيل التطبيق، إذا ظهرت رسالة:
```
Firestore index required
```

ستحصل على رابط مباشر لإنشاء Index. **اضغط عليه وانتظر 5-10 دقائق**.

---

## ☁️ إعداد Cloud Functions

### 1. تهيئة Functions

```bash
cd functions
npm install
```

### 2. دوال مطلوبة (أمثلة)

#### أ. معالجة الفيديو بعد الرفع

```javascript
exports.processRamshaVideo = functions.storage
  .bucket()
  .object()
  .onFinalize(async (object) => {
    // معالجة الفيديو
    // تحديث status إلى 'published'
  });
```

#### ب. إرسال إشعار عند نشر رمشة جديدة

```javascript
exports.onRamshaPublished = functions.firestore
  .document('ramshat/{ramshaId}')
  .onCreate(async (snap, context) => {
    // إرسال notification للمتابعين
  });
```

### 3. نشر Functions

```bash
firebase deploy --only functions
```

---

## ✅ التحقق من الإعداد

### 1. اختبار Firebase Initialization

شغّل التطبيق:
```bash
flutter run
```

تحقق من console logs:
```
✅ Firebase initialized
✅ App Check activated
✅ Crashlytics enabled
✅ Performance monitoring enabled
✅ Remote Config fetched
```

### 2. اختبار Firestore

جرب قراءة/كتابة بيانات.

### 3. اختبار Storage

جرب رفع صورة.

### 4. اختبار FCM

أرسل notification test من Firebase Console:
```
Engage → Cloud Messaging → Send test message
```

### 5. اختبار Crashlytics

أضف crash متعمد:
```dart
FirebaseCrashlytics.instance.crash();
```

تحقق من Firebase Console بعد دقائق.

---

## 🎉 الإعداد مكتمل!

### قائمة تحقق نهائية

- ✅ Firebase project مربوط
- ✅ Android SHA-1 مضاف
- ✅ iOS APNs key مرفوع
- ✅ google-services.json موجود
- ✅ GoogleService-Info.plist موجود
- ✅ Security Rules منشورة
- ✅ Firestore Indexes جاهزة
- ✅ FCM يعمل
- ✅ Crashlytics يعمل
- ✅ Performance monitoring يعمل
- ✅ App Check مفعّل

---

## 📞 الدعم

إذا واجهت مشاكل:

1. تحقق من Firebase Console Errors
2. راجع `flutter doctor`
3. تأكد من تطابق Bundle IDs
4. تحقق من Indexes في Firestore
5. راجع Security Rules

---

**تم إعداد هذا الدليل خصيصاً لمشروع Zoli Chat 🎵**

**آخر تحديث**: أكتوبر 2025
