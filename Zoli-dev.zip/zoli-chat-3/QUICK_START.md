# ⚡ البدء السريع - مشروع Zoli Chat

> دليل خطوة بخطوة لإعداد وتشغيل المشروع

---

## ✅ تم الإعداد

### ما تم إنجازه:

- ✅ **Firebase Dependencies** - تم تثبيت جميع الحزم المطلوبة
- ✅ **Firebase Initialization** - تم إعداد App Check, Crashlytics, Performance, Remote Config
- ✅ **Ramshat Model** - نموذج بيانات كامل للرمشات
- ✅ **Services** - StorageService, RamshatService, FCMService, RemoteConfigService
- ✅ **Android Setup** - تحديث gradle, manifest, FCM Service
- ✅ **Documentation** - FIREBASE_SETUP.md, DEPLOYMENT_GUIDE.md, PROJECT_README.md

---

## 🚀 الخطوات التالية (مطلوب منك)

### 1️⃣ ربط المشروع بـ Firebase

**⚠️ مهم جداً**: استخدم مشروع Firebase الموجود مسبقاً

```bash
# تثبيت FlutterFire CLI
dart pub global activate flutterfire_cli

# تسجيل الدخول
firebase login

# ربط المشروع (استبدل <PROJECT_ID> بمعرف مشروعك)
flutterfire configure --project=<PROJECT_ID> --platforms=android,ios,web
```

سيُنشئ ملف `lib/firebase_options.dart` تلقائياً.

---

### 2️⃣ إضافة SHA-1 للتطبيق

#### Android Debug SHA-1

```bash
cd android
./gradlew signingReport
```

أو (Windows PowerShell):
```powershell
cd android
.\gradlew.bat signingReport
```

ابحث عن SHA-1 و SHA-256 تحت `Variant: debug`

#### أضف إلى Firebase Console

```
Firebase Console → Project Settings → Android App → Add fingerprint
```

---

### 3️⃣ تنزيل ملفات التكوين

#### Android
```
Firebase Console → Project Settings → Android App → Download google-services.json
```

ضعه في: `android/app/google-services.json`

#### iOS (إذا كنت تطور لـ iOS)
```
Firebase Console → Project Settings → iOS App → Download GoogleService-Info.plist
```

ضعه في: `ios/Runner/GoogleService-Info.plist`

---

### 4️⃣ تفعيل خدمات Firebase

في Firebase Console، فعّل:

#### أ. Firestore Database
```
Build → Firestore Database → Create Database
```
- الموقع: **asia-southeast1** (أو الأقرب)
- الوضع: **Production mode**

#### ب. Storage
```
Build → Storage → Get Started
```

#### ج. Cloud Messaging
تلقائياً مُفعّل

#### د. نشر Security Rules

راجع `FIREBASE_SETUP.md` للقواعد الكاملة، أو استخدم الأساسية:

**Firestore:**
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /ramshat/{ramshaId} {
      allow read: if resource.data.visibility == 'public' 
                  && resource.data.status == 'published';
      allow write: if request.auth != null 
                   && request.auth.uid == resource.data.uid;
    }
    match /users/{uid} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

**Storage:**
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /ramshat/{uid}/{ramshaId}/{file} {
      allow read: if true;
      allow write: if request.auth != null 
                   && request.auth.uid == uid
                   && request.resource.size < 100 * 1024 * 1024;
    }
  }
}
```

---

### 5️⃣ إنشاء Firestore Indexes

عند تشغيل التطبيق أول مرة، قد تظهر رسالة:
```
Index required
```

ستحصل على **رابط مباشر**. اضغط عليه لإنشاء Index تلقائياً.

أو أنشئها يدوياً:

```
Firebase Console → Firestore → Indexes → Composite
```

**Index 1: Feed**
- Collection: `ramshat`
- Fields:
  - `visibility` (Ascending)
  - `status` (Ascending)
  - `createdAt` (Descending)

**Index 2: User Ramshat**
- Collection: `ramshat`
- Fields:
  - `uid` (Ascending)
  - `createdAt` (Descending)

---

### 6️⃣ تفعيل App Check (اختياري لكن موصى به)

#### Android - Play Integrity

1. في Google Cloud Console:
```
APIs & Services → Library → Play Integrity API → Enable
```

2. في Firebase Console:
```
Build → App Check → Android → Register
```

#### iOS - DeviceCheck

```
Firebase Console → App Check → iOS → Register
```

---

### 7️⃣ تشغيل التطبيق

```bash
# تنظيف البناء
flutter clean

# تثبيت Dependencies
flutter pub get

# تشغيل
flutter run
```

---

## 📱 اختبار الميزات

### 1. اختبار Firebase Connection

عند تشغيل التطبيق، تحقق من Console:
```
✅ Firebase initialized
✅ App Check activated
✅ Crashlytics enabled
✅ Performance monitoring enabled
✅ Remote Config fetched
```

### 2. اختبار Remote Config

```dart
import 'package:zoli_chat/services/remote_config_service.dart';

final config = RemoteConfigService();
print('Feed page size: ${config.feedPageSize}');
print('Video quality: ${config.videoQuality}');
```

### 3. اختبار FCM (الإشعارات)

أرسل notification test من Firebase Console:
```
Engage → Cloud Messaging → Send test message
```

---

## 🎯 المعلومات التي نحتاجها منك

يرجى تزويدنا بالمعلومات التالية عند جاهزيتها:

### ✉️ معلومات المشروع

```
[ ] Firebase Project ID: _________________
[ ] Package Name: com.awg.zoli (تم الضبط)
[ ] App Name: Zoli (تم الضبط)
```

### 🔐 SHA Fingerprints

```
[ ] Debug SHA-1: _________________
[ ] Debug SHA-256: _________________
[ ] Release SHA-1 (بعد إنشاء keystore): _________________
[ ] Release SHA-256: _________________
```

### 🔑 ملفات Google Services

```
[ ] google-services.json - تم التنزيل ووضعه في android/app/
[ ] GoogleService-Info.plist - تم التنزيل ووضعه في ios/Runner/
```

### ☁️ خدمات Firebase

```
[ ] Firestore - مفعّل
[ ] Storage - مفعّل
[ ] Cloud Messaging - مفعّل
[ ] Crashlytics - مفعّل
[ ] Performance - مفعّل
[ ] Remote Config - مفعّل
[ ] App Check - مفعّل (اختياري)
```

### 📊 Indexes

```
[ ] Feed Index - تم إنشاؤه
[ ] User Ramshat Index - تم إنشاؤه
```

---

## 📚 التوثيق الكامل

للحصول على التفاصيل الكاملة، راجع:

- **[FIREBASE_SETUP.md](FIREBASE_SETUP.md)** - دليل Firebase الشامل (500+ سطر)
- **[PROJECT_README.md](PROJECT_README.md)** - نظرة شاملة على المشروع
- **[DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)** - دليل النشر للمتاجر

---

## 🔧 حل المشاكل الشائعة

### ❌ خطأ: "MissingPluginException"
```bash
flutter clean
flutter pub get
flutter run
```

### ❌ خطأ: "Firebase not initialized"
تأكد من:
1. ملف `firebase_options.dart` موجود
2. تم تشغيل `flutterfire configure`
3. ملفات `google-services.json` / `GoogleService-Info.plist` موجودة

### ❌ خطأ: "Index required"
اضغط على الرابط في الخطأ لإنشاء Index تلقائياً

### ❌ خطأ: "Permission denied" في Firestore
تحقق من Security Rules في Firebase Console

---

## 🎉 جاهز للبدء!

بعد إتمام الخطوات أعلاه، المشروع سيكون جاهزاً بالكامل.

### أوامر سريعة:

```bash
# تشغيل
flutter run

# بناء APK
flutter build apk --release

# بناء AAB (للبلاي ستور)
flutter build appbundle --release

# تحليل الكود
flutter analyze

# الاختبارات
flutter test
```

---

## 📞 تحتاج مساعدة؟

إذا واجهت أي مشاكل:

1. راجع `FIREBASE_SETUP.md` للتفاصيل
2. تحقق من Firebase Console للأخطاء
3. راجع `flutter doctor` للتأكد من البيئة
4. تحقق من console logs في التطبيق

---

## ✅ قائمة مراجعة سريعة

- [ ] تم ربط Firebase بالمشروع (`flutterfire configure`)
- [ ] تم إضافة SHA-1 في Firebase Console
- [ ] تم تنزيل `google-services.json` ووضعه في `android/app/`
- [ ] تم تفعيل Firestore و Storage
- [ ] تم نشر Security Rules
- [ ] تم إنشاء Indexes
- [ ] تم تشغيل `flutter pub get`
- [ ] تم اختبار التطبيق (`flutter run`)
- [ ] Firebase يعمل بنجاح (تحقق من console logs)

---

**🚀 استمتع بالتطوير!**

**© 2025 AWG - Zoli Chat**
