package com.zoli.app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.media.*
import java.nio.ByteBuffer

class MainActivity : FlutterActivity() {
    private val CHANNEL = "shorts_kit"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "trim" -> {
                        val inPath = call.argument<String>("in") ?: return@setMethodCallHandler result.error("BAD_ARGS", "Missing input path", null)
                        val outPath = call.argument<String>("out") ?: return@setMethodCallHandler result.error("BAD_ARGS", "Missing output path", null)
                        val startMs = call.argument<Int>("startMs") ?: return@setMethodCallHandler result.error("BAD_ARGS", "Missing startMs", null)
                        val endMs = call.argument<Int>("endMs") ?: return@setMethodCallHandler result.error("BAD_ARGS", "Missing endMs", null)
                        
                        try {
                            trimMp4(inPath, outPath, startMs * 1000L, endMs * 1000L) // Convert ms to microseconds
                            result.success(outPath)
                        } catch (e: Exception) {
                            result.error("TRIM_FAIL", e.message, null)
                        }
                    }
                    "speed" -> {
                        // Speed adjustment not implemented yet - requires re-encoding
                        result.error("NYI", "speed() not implemented yet", null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun trimMp4(input: String, output: String, startUs: Long, endUs: Long) {
        val extractor = MediaExtractor()
        extractor.setDataSource(input)
        
        val muxer = MediaMuxer(output, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        
        val trackCount = extractor.trackCount
        val indexMap = IntArray(trackCount)
        
        for (i in 0 until trackCount) {
            extractor.selectTrack(i)
            val format = extractor.getTrackFormat(i)
            indexMap[i] = muxer.addTrack(format)
        }
        
        muxer.start()
        
        val bufferSize = 1 * 1024 * 1024 // 1MB buffer
        val dstBuf = ByteBuffer.allocate(bufferSize)
        val bufferInfo = MediaCodec.BufferInfo()
        
        for (i in 0 until trackCount) {
            extractor.selectTrack(i)
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            
            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = extractor.readSampleData(dstBuf, 0)
                
                if (bufferInfo.size < 0) break
                
                val sampleTime = extractor.sampleTime
                if (sampleTime > endUs) break
                
                bufferInfo.presentationTimeUs = sampleTime
                bufferInfo.flags = extractor.sampleFlags
                
                muxer.writeSampleData(indexMap[i], dstBuf, bufferInfo)
                extractor.advance()
            }
            
            extractor.unselectTrack(i)
        }
        
        muxer.stop()
        muxer.release()
        extractor.release()
    }
}
