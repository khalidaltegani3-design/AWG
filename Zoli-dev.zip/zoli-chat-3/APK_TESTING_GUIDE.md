# 📱 دليل اختبار APK - Zoli Chat

## ✅ ما تم إنجازه

### 1. تفعيل Firebase Authentication
```dart
✅ Anonymous Sign-in تلقائي
✅ StreamBuilder لتتبع حالة المستخدم
✅ Fallback إلى LoginScreen إذا لزم الأمر
```

### 2. بناء APK
```bash
✅ flutter clean
✅ flutter pub get
⏳ flutter build apk --release (جاري...)
```

---

## 📦 موقع ملف APK

بعد اكتمال البناء، ستجد APK في:

```
C:\Users\khali\zoli-chat\build\app\outputs\flutter-apk\app-release.apk
```

---

## 🚀 خطوات التثبيت والاختبار

### 1. نقل APK للهاتف

**الطريقة 1: USB**
```
1. وصّل الهاتف بالكمبيوتر عبر USB
2. افتح مجلد الهاتف
3. انسخ app-release.apk إلى الهاتف
4. افتح الملف من الهاتف للتثبيت
```

**الطريقة 2: البريد الإلكتروني**
```
1. أرسل app-release.apk لنفسك عبر البريد
2. افتح البريد من الهاتف
3. حمّل المرفق وثبّته
```

**الطريقة 3: Google Drive / Dropbox**
```
1. ارفع app-release.apk إلى Drive
2. افتح Drive من الهاتف
3. حمّل وثبّت
```

### 2. تفعيل Unknown Sources (إذا لزم)

```
Settings → Security → Unknown Sources → Enable
أو
Settings → Apps → Special Access → Install Unknown Apps → Chrome/Gmail → Allow
```

### 3. تثبيت التطبيق

```
1. افتح ملف app-release.apk
2. اضغط "Install"
3. اضغط "Open" بعد التثبيت
```

---

## 🧪 اختبار الميزات

### ✅ عند فتح التطبيق

**ما يجب أن يحدث:**
1. شاشة تحميل: "جاري التهيئة..."
2. تسجيل دخول تلقائي كضيف (Anonymous)
3. الانتقال مباشرة للشاشة الرئيسية

**في Logs (إذا متصل بالكمبيوتر):**
```
🔐 No user found, signing in anonymously...
✅ Anonymous sign-in successful
✅ Firebase initialized
✅ Crashlytics enabled
✅ Performance monitoring enabled
```

### ✅ Firebase Authentication

**التحقق من Firebase Console:**
```
1. افتح: https://console.firebase.google.com/
2. اختر مشروعك (zoliapp-prod)
3. Build → Authentication → Users
4. يجب أن ترى مستخدم جديد (Anonymous)
```

### ✅ اختبار Blinks

**خطوات:**
1. انتقل إلى تبويب Blinks/Reels
2. حاول إنشاء blink جديد
3. اختر فيديو من الجهاز
4. انتظر:
   - الضغط (0-50%)
   - الرفع (50-100%)
5. تحقق من ظهور الفيديو

**ما يجب أن يحدث:**
- ✅ رفع الفيديو بنجاح
- ✅ ضغط تلقائي (70% تقليل)
- ✅ الفيديو يظهر في Feed
- ✅ يمكن للآخرين رؤيته

---

## 🔍 فحص الأداء

### Firebase Performance

**في Firebase Console:**
```
1. Build → Performance
2. تحقق من:
   - App Start Time
   - Screen Rendering
   - Network Requests
```

### Crashlytics

**في Firebase Console:**
```
1. Build → Crashlytics
2. يجب أن يظهر:
   - App Version
   - Device Info
   - No Crashes (hopefully! 😄)
```

---

## 📊 معلومات APK

### التفاصيل التقنية:

```
Package Name: com.zoli.app
Version: 1.0.0+1
Min SDK: 24 (Android 7.0)
Target SDK: 34 (Android 14)
Architecture: ARM + ARM64 + x86_64
Size: ~50-80 MB (بدون ضغط)
```

### الميزات المدمجة:

```
✅ Firebase Core
✅ Firebase Authentication (Anonymous)
✅ Cloud Firestore (Rules deployed)
✅ Firebase Storage (Rules deployed)
✅ Firebase Messaging (FCM)
✅ Crashlytics (Error Tracking)
✅ Performance Monitoring
✅ Remote Config
✅ Video Compression (70%)
✅ Blinks/Reels (Public Feed)
```

---

## 🐛 حل المشاكل الشائعة

### مشكلة 1: التطبيق يتعطل عند الفتح

**الحل:**
1. تأكد من اتصال الإنترنت
2. تحقق من Firebase Console:
   - Authentication مفعّل؟
   - Firestore مفعّل؟
   - Storage مفعّل؟

### مشكلة 2: لا يمكن رفع فيديو

**الحل:**
1. تحقق من الـ Permissions:
   ```
   Settings → Apps → Zoli → Permissions
   - Camera: Allow
   - Storage: Allow
   ```
2. تحقق من Storage Rules منشورة

### مشكلة 3: الفيديوهات لا تظهر

**الحل:**
1. تحقق من Firestore Rules منشورة
2. تأكد من collection name = "reels"
3. تحقق من الاتصال بالإنترنت

### مشكلة 4: "Installation Blocked"

**الحل:**
```
Settings → Security → Install Unknown Apps → [Browser] → Allow
```

---

## 📱 اختبار متقدم

### باستخدام ADB (إذا كان Android Studio مثبت):

```bash
# توصيل الجهاز
adb devices

# تثبيت APK
adb install app-release.apk

# مشاهدة Logs
adb logcat | findstr "Flutter"

# إلغاء التثبيت
adb uninstall com.zoli.app
```

---

## 📈 مراقبة الأداء

### من VS Code (إذا متصل بالكمبيوتر):

```bash
# تشغيل في Release Mode
flutter run --release

# مراقبة Performance
flutter run --profile
```

### من Firebase Console:

```
1. Performance → Dashboard
   - App Start Time
   - Screen Traces
   - Network Requests

2. Crashlytics → Dashboard
   - Crash-free Users %
   - Crashes by Version

3. Analytics (إذا مفعّل)
   - Active Users
   - Screen Views
   - Events
```

---

## ✅ Checklist اختبار

### قبل الاختبار:
- [✅] APK تم بناؤه بنجاح
- [✅] Firebase Authentication مفعّل
- [✅] Firestore Rules منشورة
- [✅] Storage Rules منشورة
- [✅] الهاتف متصل بالإنترنت

### أثناء الاختبار:
- [ ] التطبيق يفتح بدون أخطاء
- [ ] تسجيل الدخول التلقائي يعمل
- [ ] الشاشة الرئيسية تظهر
- [ ] يمكن التنقل بين التبويبات
- [ ] يمكن إنشاء Blink جديد
- [ ] رفع الفيديو يعمل (مع ضغط)
- [ ] الفيديو يظهر في Feed
- [ ] يمكن مشاهدة الفيديوهات

### بعد الاختبار:
- [ ] لا توجد crashes في Crashlytics
- [ ] Performance جيد
- [ ] المستخدمين يظهرون في Authentication
- [ ] Blinks محفوظة في Firestore
- [ ] الفيديوهات محفوظة في Storage

---

## 🎯 الخطوات التالية

### للنشر على Google Play:

1. **إنشاء App Bundle (AAB)**:
   ```bash
   flutter build appbundle --release
   ```

2. **التوقيع الرقمي**:
   ```bash
   # إنشاء keystore
   keytool -genkey -v -keystore zoli-release.keystore -alias zoli -keyalg RSA -keysize 2048 -validity 10000
   ```

3. **تكوين الـ signing**:
   ```
   android/key.properties
   android/app/build.gradle.kts
   ```

4. **رفع على Google Play Console**:
   ```
   - Internal Testing → Upload AAB
   - Beta Testing → Promote
   - Production → Publish
   ```

راجع: `DEPLOYMENT_GUIDE.md` للتفاصيل الكاملة

---

## 📞 الدعم

### إذا واجهت مشاكل:

1. **تحقق من Logs**:
   ```bash
   adb logcat | findstr "Flutter"
   ```

2. **تحقق من Firebase Console**:
   - Authentication
   - Firestore
   - Storage
   - Crashlytics

3. **راجع التوثيق**:
   - `docs/DEPLOY_RULES_MANUALLY.md`
   - `docs/VIDEO_COMPRESSION_GUIDE.md`
   - `FIREBASE_SETUP.md`

---

## 🎉 النجاح!

إذا كان كل شيء يعمل:
- ✅ التطبيق يفتح بدون أخطاء
- ✅ Authentication يعمل
- ✅ Blinks يمكن إنشاؤها ورؤيتها
- ✅ Performance جيد

**مبروك! التطبيق جاهز للنشر! 🚀**

---

**تاريخ البناء**: 3 أكتوبر 2025  
**النسخة**: 1.0.0+1  
**Package**: com.zoli.app  
**حالة**: ✅ جاهز للاختبار
