# 🚀 Zoli Chat - Production Release Build Guide
## Version 1.1.0 (Build 2) - October 4, 2025

---

## 📋 **Table of Contents**

1. [Pre-Build Configuration](#pre-build-configuration)
2. [Security & App Check Setup](#security--app-check-setup)
3. [ProGuard/R8 Configuration](#proguardr8-configuration)
4. [Building Production APK](#building-production-apk)
5. [Testing Checklist](#testing-checklist)
6. [Firebase Configuration](#firebase-configuration)
7. [Play Store Deployment](#play-store-deployment)

---

## 1. Pre-Build Configuration

### ✅ Version Information
```gradle
versionCode: 2
versionName: 1.1.0
applicationId: com.zoli.app
minSdk: 24
targetSdk: 36
```

### ✅ Build Variants
```
- Debug: com.zoli.app.debug (development only)
- Release: com.zoli.app (production)
```

### ✅ Production Features Implemented
- ✅ Video Editor Screen (trim, title, privacy, upload)
- ✅ reCAPTCHA hidden (works in background via App Check)
- ✅ Real Firebase services (Chat, Users, Ramshat)
- ✅ DevicePreview removed
- ✅ All test/demo code removed

---

## 2. Security & App Check Setup

### 🔐 Firebase App Check Configuration

**Already Implemented in `lib/main.dart`:**
```dart
await FirebaseAppCheck.instance.activate(
  androidProvider: AndroidProvider.playIntegrity,  // ✅ Production
  appleProvider: AppleProvider.deviceCheck,
  webProvider: ReCaptchaV3Provider('recaptcha-v3-site-key'),
);
```

### 📱 Google Play Integrity API Setup

#### Step 1: Enable Play Integrity API
```bash
# Go to Google Cloud Console
https://console.cloud.google.com/

# Navigate to:
APIs & Services → Enable APIs → Search "Play Integrity API" → Enable
```

#### Step 2: Link to Firebase
```bash
# Firebase Console
https://console.firebase.google.com/

# Navigate to:
Project Settings → App Check → Android App → 
Select "Play Integrity" → Register
```

#### Step 3: Configure App Check Enforcement
```
Firestore: Enabled ✅
Storage: Enabled ✅
Auth: Optional (recommended for production)
```

### 🔑 Get SHA-1 Fingerprint

```bash
# For release keystore:
keytool -list -v -keystore android/app/keystore/release.jks \
  -alias zoli-release \
  -storepass zoli2025secure

# Copy SHA-1 and SHA-256 fingerprints
```

**Add to Firebase:**
```
Firebase Console → Project Settings → Your Apps → 
Android → Add fingerprint → Paste SHA-1 and SHA-256
```

---

## 3. ProGuard/R8 Configuration

### ✅ Already Configured in `android/app/build.gradle.kts`:

```kotlin
buildTypes {
    release {
        isMinifyEnabled = true        // ✅ Enable R8
        isShrinkResources = true      // ✅ Remove unused resources
        proguardFiles(
            getDefaultProguardFile("proguard-android-optimize.txt"),
            "proguard-rules.pro"
        )
    }
}
```

### 📄 ProGuard Rules (`android/app/proguard-rules.pro`)

**Critical keeps for production:**
- ✅ Firebase classes
- ✅ WebRTC (voice/video calls)
- ✅ Flutter plugins
- ✅ Video processing libraries
- ✅ Crashlytics (for proper stack traces)

---

## 4. Building Production APK

### 🔨 Build Commands

#### Option A: Signed Release APK (Recommended)
```bash
cd c:\Users\khali\zoli-chat

# Clean previous builds
flutter clean

# Get dependencies
flutter pub get

# Build signed release APK
flutter build apk --release

# Output location:
# build\app\outputs\flutter-apk\app-release.apk
```

#### Option B: Using Gradle directly
```bash
cd android

# Clean
.\gradlew clean

# Build release
.\gradlew assembleRelease

# Output:
# app\build\outputs\apk\release\app-release.apk
```

### 📊 Expected Build Stats
```
APK Size: ~60-70 MB (optimized with R8)
Build Time: 5-10 minutes
Min Android: 7.0 (API 24)
Target Android: 15 (API 36)
```

---

## 5. Testing Checklist

### ✅ Pre-Release QA Tests

#### Authentication
- [ ] Phone number login (OTP) works without showing reCAPTCHA to user
- [ ] App Check verifies requests successfully
- [ ] Login/logout flow stable

#### Messaging
- [ ] Send/receive text messages (1-on-1)
- [ ] Send/receive images
- [ ] Group chat functionality
- [ ] Real-time message updates

#### Voice/Video Calls
- [ ] Audio call initiation
- [ ] Video call initiation
- [ ] Audio ↔ Video switching
- [ ] Call quality on different networks (4G/5G/WiFi)
- [ ] NAT traversal works (TURN fallback if needed)

#### Ramshat (Reels)
- [ ] Upload video (trim, add title, set privacy)
- [ ] Video processing completes
- [ ] Thumbnail generation works
- [ ] Videos appear in feed
- [ ] Public/Friends/Private visibility works

#### File Sharing
- [ ] Upload images
- [ ] Upload documents
- [ ] File size limits enforced
- [ ] Download works

#### General
- [ ] No crashes on startup
- [ ] Crashlytics logging works
- [ ] Performance metrics captured
- [ ] App doesn't show debug UI
- [ ] No test screens visible
- [ ] Remote Config loads correctly

---

## 6. Firebase Configuration

### 🔥 Required Firebase Services

#### Firestore Database
```
Mode: Production
Region: asia-southeast1 (or nearest)
Rules: ✅ Configured (see FIREBASE_SETUP.md)
Indexes: ✅ Created as needed
```

#### Storage
```
Rules: ✅ Configured
CORS: ✅ Configured for web uploads
Max file size: 100MB (configurable via Remote Config)
```

#### Authentication
```
Providers: Phone (SMS)
App Check: ✅ Enabled
reCAPTCHA: v3 (invisible, works in background)
```

#### App Check
```
Android: Play Integrity ✅
iOS: DeviceCheck
Web: reCAPTCHA v3
Enforcement: Enabled for Firestore & Storage
```

#### Remote Config
```yaml
feed_page_size: 10
upload_max_duration_ms: 180000  # 3 minutes
upload_max_size_mb: 100
bitrate_target: 2500000  # 2.5 Mbps
video_quality: 720p
enable_compression: true
enable_notifications: true
maintenance_mode: false
```

### 📸 Firebase Console Screenshots Checklist

**Required screenshots for documentation:**
1. [ ] App Check enabled (showing Play Integrity)
2. [ ] SHA-1 fingerprints added
3. [ ] Firestore rules deployed
4. [ ] Storage rules deployed
5. [ ] Remote Config values set

---

## 7. Play Store Deployment

### 📦 Recommended: AAB (Android App Bundle)

```bash
# Build AAB for Play Store
flutter build appbundle --release

# Output:
# build\app\outputs\bundle\release\app-release.aab
```

**Benefits of AAB:**
- ✅ Smaller download size (Play Store optimizes per device)
- ✅ Play App Signing (Google manages keystore)
- ✅ Dynamic delivery
- ✅ Required for new apps on Play Store

### 📱 Direct APK Distribution

**If distributing APK directly (not via Play Store):**
```bash
flutter build apk --release

# Output:
# build\app\outputs\flutter-apk\app-release.apk
```

**APK Distribution Checklist:**
- [ ] Signed with production keystore
- [ ] Version code incremented
- [ ] Release notes prepared
- [ ] SHA-1 added to Firebase
- [ ] Tested on physical devices
- [ ] Install instructions provided

---

## 8. CI/CD Integration (GitHub Actions)

### 🤖 Automated Build Workflow

**Create `.github/workflows/release.yml`:**

```yaml
name: Build Production Release

on:
  push:
    tags:
      - 'v*'

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/setup-java@v3
        with:
          distribution: 'zulu'
          java-version: '17'
      
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.x'
      
      - name: Decode keystore
        run: echo "${{ secrets.KEYSTORE_BASE64 }}" | base64 -d > android/app/keystore/release.jks
      
      - name: Build Release APK
        env:
          ZOLI_KEYSTORE_PASSWORD: ${{ secrets.KEYSTORE_PASSWORD }}
          ZOLI_KEY_ALIAS: ${{ secrets.KEY_ALIAS }}
          ZOLI_KEY_PASSWORD: ${{ secrets.KEY_PASSWORD }}
        run: |
          flutter pub get
          flutter build apk --release
      
      - name: Upload APK
        uses: actions/upload-artifact@v3
        with:
          name: app-release.apk
          path: build/app/outputs/flutter-apk/app-release.apk
```

---

## 9. Security Best Practices

### 🔒 Production Security Checklist

#### Keystore Management
- [ ] Keystore stored securely (NOT in git)
- [ ] Backup created and encrypted
- [ ] Passwords stored in CI/CD secrets
- [ ] SHA fingerprints documented

#### Firebase Security
- [ ] App Check enabled and enforced
- [ ] Firestore rules restrict unauthorized access
- [ ] Storage rules validate file types/sizes
- [ ] API keys restricted by bundle ID

#### Code Security
- [ ] No debug flags in release build
- [ ] ProGuard/R8 enabled
- [ ] No hardcoded secrets
- [ ] HTTPS only for all network calls

#### Privacy & Compliance
- [ ] Privacy policy linked in app
- [ ] Terms of service accessible
- [ ] GDPR compliance (if applicable)
- [ ] Data retention policy documented

---

## 10. Release Notes - v1.1.0

### ✨ New Features
- ✅ Complete video editor with trim, title, and privacy settings
- ✅ Seamless video upload to Ramshat (Reels)
- ✅ Real-time chat with Firebase integration
- ✅ User search and chat creation
- ✅ Enhanced authentication flow

### 🔒 Security Improvements
- ✅ Firebase App Check with Play Integrity
- ✅ reCAPTCHA working in background (invisible to users)
- ✅ ProGuard/R8 code obfuscation
- ✅ Secure production keystore

### 🧹 Code Cleanup
- ✅ Removed DevicePreview
- ✅ Removed all test/demo code
- ✅ Production-only configuration
- ✅ Optimized build size

### 🐛 Bug Fixes
- ✅ Fixed build issues with video processing
- ✅ Resolved Gradle cache problems
- ✅ Improved stability

---

## 11. Troubleshooting

### Common Issues

#### Build fails with R8 errors
```bash
# Disable R8 temporarily to identify issue:
android/app/build.gradle.kts:
isMinifyEnabled = false
```

#### App Check verification fails
```bash
# Check:
1. Play Integrity API enabled in Google Cloud
2. SHA-1 added to Firebase
3. App registered in Play Console (for production)
```

#### Keystore not found
```bash
# Verify path:
ls android/app/keystore/release.jks

# Or use environment variable:
export ZOLI_KEYSTORE_PATH="/absolute/path/to/release.jks"
```

---

## 12. Contact & Support

**Build Engineer:** GitHub Copilot  
**Date:** October 4, 2025  
**Version:** 1.1.0 (Build 2)  
**Bundle ID:** com.zoli.app

**Documentation:**
- `BUILD_SOLUTIONS.md` - Build troubleshooting
- `UPDATES_OCT_4_2025.md` - Latest changes
- `FIREBASE_SETUP.md` - Firebase configuration
- `DEPLOYMENT_GUIDE.md` - Deployment guide

---

## ✅ Final Checklist

Before distributing to production:

### Build
- [ ] Version code incremented (2)
- [ ] Version name updated (1.1.0)
- [ ] Signed with production keystore
- [ ] ProGuard/R8 enabled
- [ ] APK size optimized (<70MB)

### Firebase
- [ ] App Check enabled
- [ ] Play Integrity configured
- [ ] SHA-1 fingerprints added
- [ ] Security rules deployed
- [ ] Remote Config values set

### Testing
- [ ] All QA tests passed
- [ ] No crashes detected
- [ ] Tested on multiple devices
- [ ] Network conditions tested
- [ ] reCAPTCHA hidden from users

### Security
- [ ] No debug code
- [ ] No test accounts
- [ ] Keystore secured
- [ ] API keys restricted

### Documentation
- [ ] Release notes written
- [ ] Installation guide provided
- [ ] Screenshots taken
- [ ] Changelog updated

---

🎉 **Ready for Production Deployment!**

---

**Build Command:**
```bash
flutter build apk --release
```

**Output Location:**
```
build\app\outputs\flutter-apk\app-release.apk
```

**Expected Size:** ~60-70 MB  
**Build Time:** 5-10 minutes  
**Target Users:** Production (all users)

---

**END OF PRODUCTION BUILD GUIDE**
