# 📥 دليل التثبيت اليدوي لـ Flutter

## ✅ تم تنظيف الملفات المؤقتة بنجاح!

الآن اتبع هذه الخطوات البسيطة لتثبيت Flutter يدوياً:

---

## 📋 **الخطوات:**

### 1️⃣ **تحميل Flutter:**
- اذهب إلى: **https://docs.flutter.dev/get-started/install/windows**
- أو استخدم الرابط المباشر: **https://storage.googleapis.com/flutter_infra_release/releases/stable/windows/flutter_windows_3.24.4-stable.zip**
- احفظ الملف على سطح المكتب أو في مجلد Downloads

### 2️⃣ **استخراج الملفات:**
- انقر بزر الماوس الأيمن على ملف `flutter_windows_3.24.4-stable.zip`
- اختر **"Extract All..."** أو **"استخراج الكل..."**
- استخرج المجلد إلى **`C:\`** مباشرة (ليس داخل مجلد آخر)
- النتيجة النهائية: يجب أن يكون لديك **`C:\flutter\bin\flutter.bat`**

### 3️⃣ **إضافة Flutter للـ PATH:**

**الطريقة الأولى (باستخدام PowerShell):**
```powershell
$currentPath = [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::User)
$newPath = $currentPath + ";C:\flutter\bin"
[Environment]::SetEnvironmentVariable("Path", $newPath, [EnvironmentVariableTarget]::User)
```

**أو الطريقة الثانية (يدوياً):**
1. اضغط `Windows + R`
2. اكتب: `sysdm.cpl` واضغط Enter
3. اذهب لتبويب **"Advanced"**
4. اضغط **"Environment Variables"**
5. في قسم "User variables"، اختر **"Path"** واضغط **"Edit"**
6. اضغط **"New"** وأضف: `C:\flutter\bin`
7. اضغط **OK** على جميع النوافذ

### 4️⃣ **إعادة تشغيل VS Code:**
- أغلق Visual Studio Code **تماماً**
- افتحه من جديد

### 5️⃣ **التحقق من التثبيت:**
- في Terminal داخل VS Code، اكتب:
```bash
flutter --version
```
- إذا ظهرت معلومات Flutter، التثبيت نجح! ✅

---

## 🚀 **بعد التثبيت الناجح:**

أخبرني فقط، وسأقوم بـ:
1. ✅ تثبيت مكتبات المشروع (`flutter pub get`)
2. ✅ تشغيل المعاينة على المتصفح
3. ✅ عرض التطبيق بشكل الهاتف المحمول

---

## 💡 **نصيحة:**
إذا واجهت أي مشكلة، تأكد من:
- ✅ استخراج المجلد في `C:\` مباشرة (ليس `C:\flutter\flutter`)
- ✅ إعادة تشغيل VS Code بعد إضافة PATH
- ✅ وجود اتصال إنترنت للتثبيت الأولي

---

**جاهز؟ أخبرني عند الانتهاء!** 🎉