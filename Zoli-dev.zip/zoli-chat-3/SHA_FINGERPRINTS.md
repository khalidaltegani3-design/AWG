# 🔐 SHA Fingerprints - Zoli Chat

> **تاريخ الإنشاء**: 4 أكتوبر 2025  
> **Package Name**: com.zoli.app  
> **Build Type**: Debug (للتطوير)

---

## 📋 البصمات المستخرجة

### **SHA-1 Fingerprint:**
```
CD:F2:F4:29:18:0C:AE:C9:F3:39:C8:51:21:BD:C4:98:F8:B4:E2:1A
```

### **SHA-256 Fingerprint:**
```
93:90:B4:3A:5F:7A:EB:CA:63:D1:75:68:FE:53:46:9B:CB:B0:AA:8B:93:C6:56:12:DB:50:FE:95:D0:A0:FF:1E
```

---

## ✅ الخطوات التالية (مطلوبة منك)

### **1. إضافة البصمات في Firebase Console**

#### الخطوة 1: افتح Firebase Console
```
https://console.firebase.google.com/
```

#### الخطوة 2: اختر المشروع
- اختر مشروع **Zoli Chat**

#### الخطوة 3: اذهب إلى Project Settings
```
⚙️ (أيقونة الإعدادات بجانب Project Overview)
  ↓
Project Settings
  ↓
Your apps
  ↓
Android app (com.zoli.app)
```

⚠️ **ملاحظة مهمة**: إذا لم يكن لديك تطبيق Android مسجل، اضغط **"Add app"** → **Android** → أدخل:
```
Android package name: com.zoli.app
App nickname (optional): Zoli Chat
```

#### الخطوة 4: أضف SHA-1
```
أسفل الصفحة → SHA certificate fingerprints
  ↓
اضغط "Add fingerprint"
  ↓
الصق: CD:F2:F4:29:18:0C:AE:C9:F3:39:C8:51:21:BD:C4:98:F8:B4:E2:1A
  ↓
اضغط "Save"
```

#### الخطوة 5: أضف SHA-256
```
اضغط "Add fingerprint" مرة أخرى
  ↓
الصق: 93:90:B4:3A:5F:7A:EB:CA:63:D1:75:68:FE:53:46:9B:CB:B0:AA:8B:93:C6:56:12:DB:50:FE:95:D0:A0:FF:1E
  ↓
اضغط "Save"
```

✅ **يجب أن ترى الآن 2 بصمات مضافة**

---

### **2. تنزيل google-services.json الجديد**

⚠️ **مهم جداً**: يجب تنزيل الملف **بعد** إضافة البصمات!

#### في نفس صفحة Project Settings:
```
Android app → com.zoli.app
  ↓
اضغط "google-services.json" (زر التنزيل)
  ↓
احفظ الملف
```

#### ضع الملف في المشروع:
```
استبدل: android/app/google-services.json
```

**📌 ملاحظة**: إذا لم يكن الملف موجوداً، ضعه في:
```
c:\Users\khali\zoli-chat\android\app\google-services.json
```

---

### **3. تفعيل Play Integrity API**

#### الخطوة 1: افتح Google Cloud Console
```
https://console.cloud.google.com/
```

#### الخطوة 2: اختر نفس المشروع
- يجب أن يكون نفس اسم Firebase Project

#### الخطوة 3: فعّل Play Integrity API
```
في شريط البحث أعلى الصفحة → اكتب:
"Play Integrity API"
  ↓
اختر "Play Integrity API"
  ↓
اضغط "Enable" (تفعيل)
  ↓
انتظر حتى تظهر: ✅ API enabled
```

**⚠️ تنبيه**: قد يطلب منك:
- تفعيل Billing (قد يحتاج بطاقة ائتمان للتحقق فقط)
- Play Integrity API **مجاني** للاستخدام العادي

---

### **4. تسجيل Play Integrity في Firebase App Check**

#### الخطوة 1: في Firebase Console
```
القائمة الجانبية → Build → App Check
```

#### الخطوة 2: اختر تطبيق Android
```
Apps → Android app (com.zoli.app)
```

#### الخطوة 3: سجّل Play Integrity
```
في قسم "Play Integrity"
  ↓
اضغط "Register"
  ↓
بعد التسجيل، ستظهر:
✅ Play Integrity provider registered
```

#### الخطوة 4: (اختياري) تفعيل Enforcement
```
⚠️ لا تفعّلها في بيئة التطوير!

في تبويب "APIs":
- Authentication: Not enforced (اتركها)
- Firestore: Not enforced (اتركها)
- Storage: Not enforced (اتركها)

يمكن تفعيلها لاحقاً في الإنتاج
```

---

### **5. اختبار الحل**

#### نظف المشروع:
```powershell
flutter clean
cd android
.\gradlew clean
cd ..
```

#### احذف التطبيق من الجهاز (إذا كان مثبتاً)

#### أعد التثبيت:
```powershell
flutter pub get
flutter run -d <DEVICE_ID>
```

#### اختبر تسجيل الدخول:
1. أدخل رقم هاتف
2. **يجب أن لا تظهر أي صفحة reCAPTCHA** ✅
3. OTP يُرسل مباشرة
4. أدخل الكود وتم!

---

## 📊 ملخص البصمات

| Type | Value | Status |
|------|-------|--------|
| **SHA-1** | CD:F2:F4:29:18:0C:AE:C9:F3:39:C8:51:21:BD:C4:98:F8:B4:E2:1A | ⏳ يحتاج إضافة في Firebase |
| **SHA-256** | 93:90:B4:3A:5F:7A:EB:CA:63:D1:75:68:FE:53:46:9B:CB:B0:AA:8B:93:C6:56:12:DB:50:FE:95:D0:A0:FF:1E | ⏳ يحتاج إضافة في Firebase |
| **Build Type** | Debug | للتطوير |
| **Package** | com.zoli.app | ✅ |
| **Keystore** | Debug keystore | C:\Users\khali\.android\debug.keystore |

---

## ⚠️ ملاحظات مهمة

### 1. Debug vs Release
- البصمات الحالية من **debug keystore**
- جيدة **للتطوير** فقط
- عند الإنتاج، ستحتاج بصمات **release keystore**

### 2. Release Keystore (لاحقاً)
عندما تنشئ production keystore:
```bash
keytool -list -v -keystore android/app/keystore/release.jks \
  -alias zoli-release -storepass zoli2025secure
```
ستحصل على SHA-1 و SHA-256 جديدة للإنتاج، أضفها أيضاً في Firebase.

### 3. Web Platform (اختياري)
إذا كنت تستخدم Web أيضاً:
```
Firebase Console → App Check → Web app
  ↓
reCAPTCHA v3 site key (موجود في الكود بالفعل)
```

---

## 🔍 التحقق من النجاح

### في Firebase Console:
```
Project Settings → Android app → SHA certificate fingerprints
  ↓
يجب أن ترى:
✅ SHA-1: CD:F2:F4:29...
✅ SHA-256: 93:90:B4:3A...
```

### في Google Cloud Console:
```
Play Integrity API
  ↓
Status: ✅ Enabled
```

### في Firebase App Check:
```
Apps → Android
  ↓
Play Integrity: ✅ Registered
```

### عند تشغيل التطبيق:
```
Console logs:
✅ Firebase initialized
✅ App Check activated
✅ Play Integrity provider ready
```

### عند تسجيل الدخول:
```
✅ لا تظهر صفحة reCAPTCHA
✅ OTP يُرسل مباشرة
✅ تجربة سلسة
```

---

## 📚 الموارد

### الأدلة المتوفرة:
1. **RECAPTCHA_FIX_GUIDE.md** - دليل شامل لإخفاء reCAPTCHA
2. **PRODUCTION_BUILD_GUIDE.md** - دليل بناء الإنتاج
3. **FIREBASE_SETUP.md** - إعداد Firebase الكامل

### الروابط:
- Firebase Console: https://console.firebase.google.com/
- Google Cloud Console: https://console.cloud.google.com/
- FlutterFire Docs: https://firebase.flutter.dev/

---

## ✅ Checklist سريع

- [ ] SHA-1 مضاف في Firebase Console
- [ ] SHA-256 مضاف في Firebase Console
- [ ] google-services.json مُنزّل ومحدّث
- [ ] Play Integrity API مفعّلة في Google Cloud
- [ ] Play Integrity مسجّل في Firebase App Check
- [ ] flutter clean تم تشغيله
- [ ] التطبيق مُعاد تثبيته
- [ ] اختبار تسجيل الدخول نجح بدون صفحة reCAPTCHA

---

**🎯 الآن أكمل الخطوات أعلاه وأخبرني بالنتيجة!**

---

**تم إنشاؤه**: 4 أكتوبر 2025  
**المشروع**: Zoli Chat  
**الهدف**: إخفاء reCAPTCHA عن طريق Play Integrity API
