import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

/// Widget لمعاينة الفيديو وتشغيله في محرر الرمشات
class ShortEditorPreview extends StatefulWidget {
  final File file;
  
  const ShortEditorPreview({super.key, required this.file});

  @override
  State<ShortEditorPreview> createState() => _ShortEditorPreviewState();
}

class _ShortEditorPreviewState extends State<ShortEditorPreview> {
  late final VideoPlayerController _vc;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _vc = VideoPlayerController.file(widget.file)
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _ready = true);
        _vc.setLooping(true);
        _vc.play();
      });
  }

  @override
  void dispose() {
    _vc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }
    
    final ar = _vc.value.aspectRatio == 0 ? 9 / 16 : _vc.value.aspectRatio;
    
    return AspectRatio(
      aspectRatio: ar,
      child: VideoPlayer(_vc),
    );
  }
}
