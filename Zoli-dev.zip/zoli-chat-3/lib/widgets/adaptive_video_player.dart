import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdaptiveVideoPlayer extends StatefulWidget {
  final String videoId;

  const AdaptiveVideoPlayer({Key? key, required this.videoId})
    : super(key: key);

  @override
  State<AdaptiveVideoPlayer> createState() => _AdaptiveVideoPlayerState();
}

class _AdaptiveVideoPlayerState extends State<AdaptiveVideoPlayer> {
  VideoPlayerController? controller;
  String currentQuality = '480p';
  bool isLoading = true;
  Map<String, String> qualities = {};

  @override
  void initState() {
    super.initState();
    initializePlayer();
  }

  Future<void> initializePlayer() async {
    final doc = await FirebaseFirestore.instance
        .collection('videos')
        .doc(widget.videoId)
        .get();

    final data = doc.data();
    if (data == null || data['status'] != 'ready') {
      setState(() => isLoading = false);
      return;
    }

    qualities = Map<String, String>.from(data['qualities'] ?? {});

    final quality = await selectQuality();
    await loadVideo(quality);
  }

  Future<String> selectQuality() async {
    final connectivityResult = await Connectivity().checkConnectivity();

    // connectivity_plus 5.0.2: checkConnectivity() returns List<ConnectivityResult>
    final results = connectivityResult as List?;
    if (results != null) {
      if (results.contains(ConnectivityResult.wifi)) {
        return qualities.containsKey('720p') ? '720p' : '480p';
      } else if (results.contains(ConnectivityResult.mobile)) {
        return qualities.containsKey('480p') ? '480p' : '360p';
      }
    }

    return '360p';
  }

  Future<void> loadVideo(String quality) async {
    if (!qualities.containsKey(quality)) return;

    controller?.dispose();

    controller = VideoPlayerController.networkUrl(
      Uri.parse(qualities[quality]!),
    );

    await controller!.initialize();
    await controller!.play();

    setState(() {
      currentQuality = quality;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Loading'),
          ],
        ),
      );
    }

    if (controller == null || !controller!.value.isInitialized) {
      return const Center(child: Text('Failed to load video'));
    }

    return Stack(
      children: [
        AspectRatio(
          aspectRatio: controller!.value.aspectRatio,
          child: VideoPlayer(controller!),
        ),
        Positioned(
          top: 8,
          right: 8,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              currentQuality,
              style: const TextStyle(color: Colors.white, fontSize: 12),
            ),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }
}
