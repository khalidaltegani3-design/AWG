import 'dart:async';

// Data models for Status
class Status {
  final String url;
  final Duration duration;
  final String type; // 'image' or 'video'
  final DateTime createdAt;

  Status({
    required this.url,
    required this.duration,
    this.type = 'image',
    required this.createdAt,
  });
}

class UserStatus {
  final String userId;
  final String username;
  final String? avatarUrl;
  final List<Status> statuses;

  UserStatus({
    required this.userId,
    required this.username,
    this.avatarUrl,
    required this.statuses,
  });
}

class StatusService {
  // Mock database of statuses
  final List<UserStatus> _userStatuses = [
    UserStatus(
      userId: 'my_status',
      username: 'My status',
      statuses: [], // Initially no status for the current user
    ),
    UserStatus(
      userId: 'user1',
      username: 'Zoli',
      avatarUrl:
          'https://firebasestorage.googleapis.com/v0/b/zoliapp-prod.appspot.com/o/002-zoli.png?alt=media&token=f42923a7-4401-424a-8365-c2323414355a',
      statuses: [
        Status(
          url:
              'https://firebasestorage.googleapis.com/v0/b/zoliapp-prod.appspot.com/o/zoli-story.png?alt=media&token=29389e5c-8125-4225-9458-23cd32d04103',
          duration: const Duration(seconds: 5),
          createdAt: DateTime.now(),
        ),
      ],
    ),
  ];

  // Stream controller to provide reactive updates
  final _statusStreamController =
      StreamController<List<UserStatus>>.broadcast();
  Stream<List<UserStatus>> get statusStream => _statusStreamController.stream;
  Timer? _timer;

  StatusService() {
    // Periodically check for and remove old statuses
    _timer = Timer.periodic(const Duration(minutes: 1), (timer) {
      _removeOldStatuses();
      if (!_statusStreamController.isClosed) {
        _statusStreamController.add(_getFilteredStatuses());
      }
    });
  }

  List<UserStatus> _getFilteredStatuses() {
    final now = DateTime.now();
    final filteredUserStatuses = _userStatuses.map((userStatus) {
      final recentStatuses = userStatus.statuses.where((status) {
        return now.difference(status.createdAt).inHours < 24;
      }).toList();

      // Return a new UserStatus object with only the recent statuses
      return UserStatus(
        userId: userStatus.userId,
        username: userStatus.username,
        avatarUrl: userStatus.avatarUrl,
        statuses: recentStatuses,
      );
    }).toList();

    // Don't show users who have no recent statuses (unless it's the current user)
    filteredUserStatuses.removeWhere(
      (userStatus) =>
          userStatus.statuses.isEmpty && userStatus.userId != 'my_status',
    );

    return filteredUserStatuses;
  }

  void _removeOldStatuses() {
    final now = DateTime.now();
    for (var userStatus in _userStatuses) {
      userStatus.statuses.removeWhere(
        (status) => now.difference(status.createdAt).inHours >= 24,
      );
    }
  }

  Stream<List<UserStatus>> getStatuses() async* {
    // Initially, return the current state
    yield _getFilteredStatuses();
    // Return the stream for future updates
    yield* _statusStreamController.stream;
  }

  Future<void> addMyStatus(String url, {String type = 'image'}) async {
    final myStatus = _userStatuses.firstWhere((s) => s.userId == 'my_status');

    // Limit to 15 statuses
    if (myStatus.statuses.length >= 15) {
      print("Cannot add more than 15 statuses.");
      return;
    }

    final newStatus = Status(
      url: url,
      duration: const Duration(seconds: 3), // Default 3 seconds for images
      type: type,
      createdAt: DateTime.now(),
    );

    myStatus.statuses.add(newStatus);
    _statusStreamController.add(_getFilteredStatuses());
    print("New status added!");
  }

  void dispose() {
    _timer?.cancel();
    _statusStreamController.close();
  }
}
