import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:flutter/foundation.dart';

/// خدمة إدارة Remote Config
/// تُستخدم لإدارة القيم الافتراضية والميزات من لوحة Firebase
class RemoteConfigService {
  static final RemoteConfigService _instance = RemoteConfigService._internal();
  factory RemoteConfigService() => _instance;
  RemoteConfigService._internal();

  final FirebaseRemoteConfig _remoteConfig = FirebaseRemoteConfig.instance;

  /// القيم الافتراضية
  static const Map<String, dynamic> _defaults = {
    'feed_page_size': 10,
    'upload_max_duration_ms': 60000, // 60 seconds
    'upload_max_size_mb': 100,
    'bitrate_target': 2500000, // 2.5 Mbps
    'video_quality': '720p',
    'enable_compression': true,
    'enable_notifications': true,
    'min_app_version': '1.0.0',
    'force_update': false,
    'maintenance_mode': false,
    'maintenance_message':
        'The app is under maintenance. Please try again later.',
  };

  /// تهيئة Remote Config
  Future<void> initialize() async {
    try {
      await _remoteConfig.setConfigSettings(
        RemoteConfigSettings(
          fetchTimeout: const Duration(seconds: 10),
          minimumFetchInterval: const Duration(hours: 1),
        ),
      );

      await _remoteConfig.setDefaults(_defaults);
      await _remoteConfig.fetchAndActivate();

      debugPrint('Remote Config initialized successfully');
    } catch (e) {
      debugPrint('Failed to initialize Remote Config: $e');
    }
  }

  /// جلب القيم وتفعيلها
  Future<bool> fetchAndActivate() async {
    try {
      return await _remoteConfig.fetchAndActivate();
    } catch (e) {
      debugPrint('Failed to fetch and activate: $e');
      return false;
    }
  }

  // ===== Feed Settings =====

  /// حجم صفحة Feed (عدد Blinks في الصفحة الواحدة)
  int get feedPageSize => _remoteConfig.getInt('feed_page_size');

  // ===== Upload Settings =====

  /// الحد الأقصى لمدة الفيديو بالميلي ثانية
  int get uploadMaxDurationMs => _remoteConfig.getInt('upload_max_duration_ms');

  /// الحد الأقصى لحجم الفيديو بالميغابايت
  int get uploadMaxSizeMb => _remoteConfig.getInt('upload_max_size_mb');

  /// معدل البت المستهدف (bitrate)
  int get bitrateTarget => _remoteConfig.getInt('bitrate_target');

  /// جودة الفيديو (480p, 720p, 1080p)
  String get videoQuality => _remoteConfig.getString('video_quality');

  /// تفعيل ضغط الفيديو
  bool get enableCompression => _remoteConfig.getBool('enable_compression');

  // ===== Notifications Settings =====

  /// تفعيل الإشعارات
  bool get enableNotifications => _remoteConfig.getBool('enable_notifications');

  // ===== App Version Settings =====

  /// أقل إصدار مطلوب للتطبيق
  String get minAppVersion => _remoteConfig.getString('min_app_version');

  /// فرض التحديث
  bool get forceUpdate => _remoteConfig.getBool('force_update');

  // ===== Maintenance Settings =====

  /// وضع الصيانة
  bool get maintenanceMode => _remoteConfig.getBool('maintenance_mode');

  /// رسالة الصيانة
  String get maintenanceMessage =>
      _remoteConfig.getString('maintenance_message');

  // ===== Custom Methods =====

  /// الحصول على قيمة String مخصصة
  String getString(String key, {String defaultValue = ''}) {
    try {
      return _remoteConfig.getString(key);
    } catch (e) {
      return defaultValue;
    }
  }

  /// الحصول على قيمة Int مخصصة
  int getInt(String key, {int defaultValue = 0}) {
    try {
      return _remoteConfig.getInt(key);
    } catch (e) {
      return defaultValue;
    }
  }

  /// الحصول على قيمة Bool مخصصة
  bool getBool(String key, {bool defaultValue = false}) {
    try {
      return _remoteConfig.getBool(key);
    } catch (e) {
      return defaultValue;
    }
  }

  /// الحصول على قيمة Double مخصصة
  double getDouble(String key, {double defaultValue = 0.0}) {
    try {
      return _remoteConfig.getDouble(key);
    } catch (e) {
      return defaultValue;
    }
  }

  /// الحصول على جميع القيم
  Map<String, RemoteConfigValue> getAll() {
    return _remoteConfig.getAll();
  }

  /// طباعة جميع القيم للتصحيح
  void debugPrintAll() {
    if (kDebugMode) {
      final all = getAll();
      debugPrint('=== Remote Config Values ===');
      all.forEach((key, value) {
        debugPrint('$key: ${value.asString()}');
      });
      debugPrint('============================');
    }
  }
}
