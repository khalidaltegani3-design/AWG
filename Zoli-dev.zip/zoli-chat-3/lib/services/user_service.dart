import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:zoli_chat/models/user_model.dart';

class UserService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<AppUser>> getUsersStream() {
    return _firestore.collection('users').snapshots().map((snapshot) {
      return snapshot.docs
          .map((doc) => AppUser.fromMap(doc.data(), doc.id))
          .toList();
    });
  }

  Stream<List<Map<String, dynamic>>> getUsers() {
    return _firestore.collection('users').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        final user = doc.data();
        return {'email': user['email'], 'uid': user['uid']};
      }).toList();
    });
  }

  Future<bool> isNewUser(String uid) async {
    final userDoc = await _firestore.collection('users').doc(uid).get();
    // If the document doesn't exist, or it exists but doesn't have a 'name' field,
    // consider the user new and in need of profile setup.
    return !userDoc.exists || userDoc.data()?['displayName'] == null;
  }

  Future<bool> isZoliUser(String phoneNumber) async {
    final normalizedNumber = phoneNumber.replaceAll(RegExp(r'[\s\-\(\)]'), '');
    final querySnapshot = await _firestore
        .collection('users')
        .where('phoneNumber', isEqualTo: normalizedNumber)
        .limit(1)
        .get();
    return querySnapshot.docs.isNotEmpty;
  }
}
