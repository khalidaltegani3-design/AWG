import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uuid/uuid.dart';

class VideoUploadService {
  final FirebaseStorage storage = FirebaseStorage.instance;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final FirebaseAuth auth = FirebaseAuth.instance;

  Future<String?> uploadVideo(
    File videoFile, {
    Function(double)? onProgress,
    Function(String)? onStatusChange,
  }) async {
    try {
      final userId = auth.currentUser?.uid;
      if (userId == null) throw Exception('User not authenticated');

      final videoId = const Uuid().v4();

      onStatusChange?.call('Uploading');

      final storageRef = storage.ref().child(
        'videos/$userId/$videoId/original.mp4',
      );
      final uploadTask = storageRef.putFile(videoFile);

      uploadTask.snapshotEvents.listen((snapshot) {
        final progress = snapshot.bytesTransferred / snapshot.totalBytes;
        onProgress?.call(progress);
      });

      await uploadTask;

      await firestore.collection('videos').doc(videoId).set({
        'userId': userId,
        'status': 'processing',
        'originalPath': 'videos/$userId/$videoId/original.mp4',
        'uploadedAt': FieldValue.serverTimestamp(),
        'qualities': {},
      });

      onStatusChange?.call('Upload complete');

      return videoId;
    } catch (e) {
      print('Error uploading video: $e');
      return null;
    }
  }

  Stream<Map<String, dynamic>> watchVideoStatus(String videoId) {
    return firestore
        .collection('videos')
        .doc(videoId)
        .snapshots()
        .map((doc) => doc.data() ?? {});
  }
}
