import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'dart:io' show Platform;

/// معالج الرسائل في الخلفية (يجب أن يكون top-level function)
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  debugPrint('Handling background message: ${message.messageId}');
  // يمكن إضافة معالجة إضافية هنا
}

/// خدمة إدارة الإشعارات (FCM - Firebase Cloud Messaging)
/// تُستخدم لإدارة tokens و topics والتعامل مع الإشعارات
class FCMService {
  static final FCMService _instance = FCMService._internal();
  factory FCMService() => _instance;
  FCMService._internal();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String? _currentToken;
  String? get currentToken => _currentToken;

  /// تهيئة FCM
  Future<void> initialize() async {
    try {
      // طلب الأذونات (iOS بشكل أساسي)
      await _requestPermissions();

      // الحصول على الـ token
      await _getToken();

      // الاشتراك في topic الافتراضي
      await subscribeToTopic('blinks-new');

      // معالجة الرسائل
      _setupMessageHandlers();

      debugPrint('FCM Service initialized successfully');
    } catch (e) {
      debugPrint('Failed to initialize FCM: $e');
    }
  }

  /// طلب الأذونات (iOS)
  Future<void> _requestPermissions() async {
    if (Platform.isIOS) {
      NotificationSettings settings = await _messaging.requestPermission(
        alert: true,
        announcement: false,
        badge: true,
        carPlay: false,
        criticalAlert: false,
        provisional: false,
        sound: true,
      );

      debugPrint(
        'Notification permission status: ${settings.authorizationStatus}',
      );
    } else {
      // Android - الأذونات تُمنح تلقائياً
      debugPrint('Android - Notifications enabled by default');
    }
  }

  /// الحصول على FCM token
  Future<String?> _getToken() async {
    try {
      _currentToken = await _messaging.getToken();
      debugPrint('FCM Token: $_currentToken');

      if (_currentToken != null) {
        // حفظ الـ token في Firestore
        await _saveTokenToFirestore(_currentToken!);
      }

      // الاستماع لتحديثات الـ token
      _messaging.onTokenRefresh.listen((newToken) {
        _currentToken = newToken;
        _saveTokenToFirestore(newToken);
      });

      return _currentToken;
    } catch (e) {
      debugPrint('Failed to get FCM token: $e');
      return null;
    }
  }

  /// حفظ الـ token في Firestore
  Future<void> _saveTokenToFirestore(String token) async {
    try {
      final uid = _getCurrentUserId();
      if (uid == null) {
        debugPrint('No user logged in, skipping token save');
        return;
      }

      await _firestore
          .collection('users')
          .doc(uid)
          .collection('tokens')
          .doc(token)
          .set({
            'token': token,
            'platform': Platform.operatingSystem,
            'createdAt': FieldValue.serverTimestamp(),
            'updatedAt': FieldValue.serverTimestamp(),
          });

      debugPrint('Token saved to Firestore');
    } catch (e) {
      debugPrint('Failed to save token: $e');
    }
  }

  /// حذف الـ token من Firestore
  Future<void> deleteToken() async {
    try {
      if (_currentToken == null) return;

      final uid = _getCurrentUserId();
      if (uid == null) return;

      await _firestore
          .collection('users')
          .doc(uid)
          .collection('tokens')
          .doc(_currentToken!)
          .delete();

      await _messaging.deleteToken();
      _currentToken = null;

      debugPrint('Token deleted successfully');
    } catch (e) {
      debugPrint('Failed to delete token: $e');
    }
  }

  /// إعداد معالجات الرسائل
  void _setupMessageHandlers() {
    // الرسائل في المقدمة (Foreground)
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      debugPrint('Foreground message received: ${message.messageId}');
      _handleMessage(message);
    });

    // عند النقر على الإشعار (App في الخلفية)
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint('Message opened app: ${message.messageId}');
      _handleMessageTap(message);
    });

    // التحقق من رسالة فتحت التطبيق (App كان مغلقاً تماماً)
    _checkInitialMessage();
  }

  /// معالجة الرسالة في المقدمة
  void _handleMessage(RemoteMessage message) {
    debugPrint('Message data: ${message.data}');

    if (message.notification != null) {
      debugPrint('Message notification: ${message.notification!.title}');
      // يمكن عرض notification محلي هنا
    }

    // معالجة حسب نوع الرسالة
    _handleMessageData(message.data);
  }

  /// معالجة النقر على الإشعار
  void _handleMessageTap(RemoteMessage message) {
    debugPrint('User tapped notification');

    // التنقل إلى الشاشة المناسبة
    final type = message.data['type'];
    final id = message.data['id'];

    if (type == 'blink' && id != null) {
      // TODO: Navigate to BlinkDetailScreen
      debugPrint('Navigate to Blink: $id');
    } else if (type == 'chat' && id != null) {
      // TODO: Navigate to ChatScreen
      debugPrint('Navigate to Chat: $id');
    }
  }

  /// معالجة بيانات الرسالة
  void _handleMessageData(Map<String, dynamic> data) {
    final type = data['type'];

    switch (type) {
      case 'blink_published':
        debugPrint('New blink published');
        break;
      case 'blink_liked':
        debugPrint('Someone liked your blink');
        break;
      case 'blink_commented':
        debugPrint('Someone commented on your blink');
        break;
      case 'new_follower':
        debugPrint('New follower');
        break;
      default:
        debugPrint('Unknown message type: $type');
    }
  }

  /// التحقق من رسالة فتحت التطبيق
  Future<void> _checkInitialMessage() async {
    RemoteMessage? initialMessage = await _messaging.getInitialMessage();

    if (initialMessage != null) {
      debugPrint('App opened from terminated state by notification');
      _handleMessageTap(initialMessage);
    }
  }

  /// الاشتراك في topic
  Future<void> subscribeToTopic(String topic) async {
    try {
      await _messaging.subscribeToTopic(topic);
      debugPrint('Subscribed to topic: $topic');
    } catch (e) {
      debugPrint('Failed to subscribe to topic: $e');
    }
  }

  /// إلغاء الاشتراك من topic
  Future<void> unsubscribeFromTopic(String topic) async {
    try {
      await _messaging.unsubscribeFromTopic(topic);
      debugPrint('Unsubscribed from topic: $topic');
    } catch (e) {
      debugPrint('Failed to unsubscribe from topic: $e');
    }
  }

  /// الحصول على معرف المستخدم الحالي (يجب تعديلها حسب نظام المصادقة)
  String? _getCurrentUserId() {
    // TODO: الحصول على uid من AuthService
    try {
      // مثال: return FirebaseAuth.instance.currentUser?.uid;
      return null; // placeholder
    } catch (e) {
      return null;
    }
  }

  /// إيقاف الخدمة
  void dispose() {
    // تنظيف الموارد إذا لزم الأمر
  }
}

/// Topics المتاحة
class FCMTopics {
  static const String blinksNew = 'blinks-new';
  static const String blinksTrending = 'blinks-trending';
  static const String systemAnnouncements = 'system-announcements';
  static const String maintenance = 'maintenance';
}

/// أنواع الإشعارات
class NotificationType {
  static const String blinkPublished = 'blink_published';
  static const String blinkLiked = 'blink_liked';
  static const String blinkCommented = 'blink_commented';
  static const String newFollower = 'new_follower';
  static const String newMessage = 'new_message';
  static const String systemAlert = 'system_alert';
}
