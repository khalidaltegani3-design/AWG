import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/music_track.dart';

/// خدمة للحصول على الموسيقى من مصادر مختلفة
/// ملاحظة: SoundCloud API يتطلب تسجيل وموافقة، لذا نستخدم قائمة محلية
class MusicService {
  static const String _baseUrl = 'https://freemusicarchive.org/api';

  /// الأنواع الموسيقية المتاحة
  static const List<String> genres = [
    'All',
    'Electronic',
    'Hip-Hop',
    'Pop',
    'Rock',
    'Jazz',
    'Classical',
    'Ambient',
    'Dance',
    'R&B',
  ];

  /// تراكات موسيقية محلية (يمكن استبدالها بـ API حقيقي)
  static final List<MusicTrack> _localTracks = [
    MusicTrack(
      id: '1',
      title: 'Summer Vibes',
      artist: 'DJ Cool',
      genre: 'Electronic',
      duration: const Duration(minutes: 3, seconds: 45),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400',
      waveformUrl: '',
    ),
    MusicTrack(
      id: '2',
      title: 'Chill Beats',
      artist: 'Lo-Fi Master',
      genre: 'Hip-Hop',
      duration: const Duration(minutes: 2, seconds: 30),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400',
      waveformUrl: '',
    ),
    MusicTrack(
      id: '3',
      title: 'Upbeat Energy',
      artist: 'Pop Stars',
      genre: 'Pop',
      duration: const Duration(minutes: 3, seconds: 15),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400',
      waveformUrl: '',
    ),
    MusicTrack(
      id: '4',
      title: 'Rock Anthem',
      artist: 'The Rockers',
      genre: 'Rock',
      duration: const Duration(minutes: 4, seconds: 0),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=400',
      waveformUrl: '',
    ),
    MusicTrack(
      id: '5',
      title: 'Jazz Night',
      artist: 'Smooth Jazz',
      genre: 'Jazz',
      duration: const Duration(minutes: 3, seconds: 50),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1415201364774-f6f0bb35f28f?w=400',
      waveformUrl: '',
    ),
    MusicTrack(
      id: '6',
      title: 'Classical Symphony',
      artist: 'Orchestra',
      genre: 'Classical',
      duration: const Duration(minutes: 5, seconds: 20),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
      waveformUrl: '',
    ),
    MusicTrack(
      id: '7',
      title: 'Ambient Dreams',
      artist: 'Ambient Space',
      genre: 'Ambient',
      duration: const Duration(minutes: 4, seconds: 30),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400',
      waveformUrl: '',
    ),
    MusicTrack(
      id: '8',
      title: 'Dance Floor',
      artist: 'EDM Producer',
      genre: 'Dance',
      duration: const Duration(minutes: 3, seconds: 40),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=400',
      waveformUrl: '',
    ),
    MusicTrack(
      id: '9',
      title: 'R&B Smooth',
      artist: 'Soul Singer',
      genre: 'R&B',
      duration: const Duration(minutes: 3, seconds: 25),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400',
      waveformUrl: '',
    ),
    MusicTrack(
      id: '10',
      title: 'Electronic Pulse',
      artist: 'Techno Master',
      genre: 'Electronic',
      duration: const Duration(minutes: 4, seconds: 10),
      audioUrl:
          'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
      coverArtUrl:
          'https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?w=400',
      waveformUrl: '',
    ),
  ];

  /// البحث عن التراكات
  Future<List<MusicTrack>> searchTracks(
    String query, {
    String genre = 'All',
  }) async {
    await Future.delayed(const Duration(milliseconds: 500)); // محاكاة تأخير API

    var results = _localTracks;

    // تصفية حسب النوع
    if (genre != 'All') {
      results = results.where((track) => track.genre == genre).toList();
    }

    // تصفية حسب البحث
    if (query.isNotEmpty) {
      results = results.where((track) {
        final searchLower = query.toLowerCase();
        return track.title.toLowerCase().contains(searchLower) ||
            track.artist.toLowerCase().contains(searchLower);
      }).toList();
    }

    return results;
  }

  /// الحصول على التراكات الشائعة
  Future<List<MusicTrack>> getTrendingTracks() async {
    await Future.delayed(const Duration(milliseconds: 300));
    return _localTracks.take(5).toList();
  }

  /// الحصول على تراكات حسب النوع
  Future<List<MusicTrack>> getTracksByGenre(String genre) async {
    await Future.delayed(const Duration(milliseconds: 300));
    if (genre == 'All') {
      return _localTracks;
    }
    return _localTracks.where((track) => track.genre == genre).toList();
  }

  /// تحميل التراك (في التطبيق الحقيقي)
  Future<String> downloadTrack(MusicTrack track) async {
    // في التطبيق الحقيقي، هنا سيتم تحميل الملف
    // الآن نعيد URL مباشرة
    return track.audioUrl;
  }
}
