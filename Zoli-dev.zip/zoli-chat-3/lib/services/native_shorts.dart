import 'package:flutter/services.dart';

/// Native bridge for video trimming and speed adjustment
/// Uses MediaExtractor/MediaMuxer on Android and AVFoundation on iOS
class NativeShorts {
  static const _ch = MethodChannel('shorts_kit');

  /// Trim video from msStart to msEnd (in milliseconds)
  /// Returns the output file path on success
  static Future<String> trim(
    String inPath,
    String outPath,
    int msStart,
    int msEnd,
  ) async {
    try {
      final result = await _ch.invokeMethod('trim', {
        'in': inPath,
        'out': outPath,
        'startMs': msStart,
        'endMs': msEnd,
      });
      return result as String;
    } catch (e) {
      throw Exception('Trim failed: $e');
    }
  }

  /// Change video speed (e.g., 1.25x, 0.5x)
  /// Returns the output file path on success
  /// Note: Speed functionality may not be implemented yet
  static Future<String> speed(
    String inPath,
    String outPath,
    double rate,
  ) async {
    try {
      final result = await _ch.invokeMethod('speed', {
        'in': inPath,
        'out': outPath,
        'rate': rate,
      });
      return result as String;
    } catch (e) {
      throw Exception('Speed adjustment failed: $e');
    }
  }
}
