// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class SEn extends S {
  SEn([String locale = 'en']) : super(locale);

  @override
  String get settings => 'Settings';

  @override
  String get profile => 'Profile';

  @override
  String get editBio => 'Edit Bio';

  @override
  String get writeSomethingAboutYourself => 'Write something about yourself';

  @override
  String get channelManagement => 'Channel Management';

  @override
  String get manageMyBlinks => 'Manage My Blinks';

  @override
  String get viewDeleteOrChangePrivacy =>
      'View, delete, or change privacy of your videos';

  @override
  String get viewMyProfile => 'View My Profile';

  @override
  String get seeYourPublicProfile => 'See your public profile';

  @override
  String get appSettings => 'App Settings';

  @override
  String get darkMode => 'Dark Mode';

  @override
  String get language => 'Language';

  @override
  String get account => 'Account';

  @override
  String get changePhoneNumber => 'Change Phone Number';

  @override
  String get updateYourPhoneNumber =>
      'Update the phone number associated with your account';

  @override
  String get deleteAccount => 'Delete Account';

  @override
  String get permanentlyDeleteYourAccount =>
      'Permanently delete your account and all data';

  @override
  String get takeNewPhoto => 'Take a new photo';

  @override
  String get chooseFromGallery => 'Choose from gallery';

  @override
  String get tapToChangeProfilePicture =>
      'Tap the image to change your profile picture.';

  @override
  String get save => 'Save';

  @override
  String get bioSaved => 'Bio Saved (Not Implemented)';

  @override
  String get manageVideosScreen =>
      'Navigate to Manage Videos screen (Not Implemented)';

  @override
  String get ramashatScreen => 'Navigate to Ramashat screen (Not Implemented)';

  @override
  String get languageSelection => 'Language selection (Not Implemented)';

  @override
  String get changePhoneNumberScreen =>
      'Navigate to Change Phone Number screen (Not Implemented)';

  @override
  String get accountDeletion => 'Account Deletion (Not Implemented)';

  @override
  String get darkModeEnabled => 'Dark Mode Enabled (UI Only)';

  @override
  String get darkModeDisabled => 'Dark Mode Disabled (UI Only)';

  @override
  String get newPhoneNumber => 'New Phone Number';

  @override
  String get phoneNumberUpdated => 'Phone Number Updated (Not Implemented)';

  @override
  String get areYouSureYouWantToDeleteYourAccount =>
      'Are you sure you want to delete your account? This action is irreversible.';

  @override
  String get cancel => 'Cancel';

  @override
  String get delete => 'Delete';

  @override
  String get makePublic => 'Make Public';

  @override
  String get makePrivate => 'Make Private';

  @override
  String get privacyUpdated => 'Privacy Updated';

  @override
  String get deleteVideo => 'Delete Video';

  @override
  String get areYouSureYouWantToDeleteThisVideo =>
      'Are you sure you want to delete this video?';

  @override
  String get videoDeleted => 'Video Deleted';

  @override
  String get loginWelcome => 'Welcome ...';

  @override
  String get loginEnterPhone => 'Enter your phone number to continue';

  @override
  String get loginEnterOTP => 'Enter the verification code';

  @override
  String get loginSendOTP => 'Send Code';

  @override
  String get loginVerifyOTP => 'Verify Code';

  @override
  String get loginChangeNumber => 'Change Number?';

  @override
  String get loginInvalidCountryCode => 'Invalid';

  @override
  String get loginEnterPhoneNumber => 'Please enter a phone number';

  @override
  String get loginInvalidOTP => 'Please enter a valid code';

  @override
  String get loginOTPCode => 'OTP Code';

  @override
  String get loginPhoneNumberHint => 'Phone Number';

  @override
  String get editVideo => 'Edit Video';

  @override
  String get speed => 'Speed';

  @override
  String get text => 'Text';

  @override
  String get audio => 'Audio';

  @override
  String get exporting => 'Exporting...';

  @override
  String get pleaseLoginFirst => 'Please login first';

  @override
  String get applyingFilters => 'Applying filters...';

  @override
  String get failedToApplyFilter => 'Failed to apply filter';

  @override
  String get compressing => 'Compressing...';

  @override
  String get compressionFailed => 'Compression failed';

  @override
  String get uploading => 'Uploading...';

  @override
  String get saving => 'Saving...';

  @override
  String get publishedSuccessfully => 'Published successfully! ✅';

  @override
  String get videoPublishedSuccessfully => 'Video published successfully!';

  @override
  String get error => 'Error';

  @override
  String get publishingFailed => 'Publishing failed';
}
