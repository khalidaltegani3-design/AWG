import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of S
/// returned by `S.of(context)`.
///
/// Applications need to include `S.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'generated/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: S.localizationsDelegates,
///   supportedLocales: S.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the S.supportedLocales
/// property.
abstract class S {
  S(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static S? of(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  static const LocalizationsDelegate<S> delegate = _SDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en'),
  ];

  /// No description provided for @settings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settings;

  /// No description provided for @profile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get profile;

  /// No description provided for @editBio.
  ///
  /// In en, this message translates to:
  /// **'Edit Bio'**
  String get editBio;

  /// No description provided for @writeSomethingAboutYourself.
  ///
  /// In en, this message translates to:
  /// **'Write something about yourself'**
  String get writeSomethingAboutYourself;

  /// No description provided for @channelManagement.
  ///
  /// In en, this message translates to:
  /// **'Channel Management'**
  String get channelManagement;

  /// No description provided for @manageMyBlinks.
  ///
  /// In en, this message translates to:
  /// **'Manage My Blinks'**
  String get manageMyBlinks;

  /// No description provided for @viewDeleteOrChangePrivacy.
  ///
  /// In en, this message translates to:
  /// **'View, delete, or change privacy of your videos'**
  String get viewDeleteOrChangePrivacy;

  /// No description provided for @viewMyProfile.
  ///
  /// In en, this message translates to:
  /// **'View My Profile'**
  String get viewMyProfile;

  /// No description provided for @seeYourPublicProfile.
  ///
  /// In en, this message translates to:
  /// **'See your public profile'**
  String get seeYourPublicProfile;

  /// No description provided for @appSettings.
  ///
  /// In en, this message translates to:
  /// **'App Settings'**
  String get appSettings;

  /// No description provided for @darkMode.
  ///
  /// In en, this message translates to:
  /// **'Dark Mode'**
  String get darkMode;

  /// No description provided for @language.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get language;

  /// No description provided for @account.
  ///
  /// In en, this message translates to:
  /// **'Account'**
  String get account;

  /// No description provided for @changePhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Change Phone Number'**
  String get changePhoneNumber;

  /// No description provided for @updateYourPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Update the phone number associated with your account'**
  String get updateYourPhoneNumber;

  /// No description provided for @deleteAccount.
  ///
  /// In en, this message translates to:
  /// **'Delete Account'**
  String get deleteAccount;

  /// No description provided for @permanentlyDeleteYourAccount.
  ///
  /// In en, this message translates to:
  /// **'Permanently delete your account and all data'**
  String get permanentlyDeleteYourAccount;

  /// No description provided for @takeNewPhoto.
  ///
  /// In en, this message translates to:
  /// **'Take a new photo'**
  String get takeNewPhoto;

  /// No description provided for @chooseFromGallery.
  ///
  /// In en, this message translates to:
  /// **'Choose from gallery'**
  String get chooseFromGallery;

  /// No description provided for @tapToChangeProfilePicture.
  ///
  /// In en, this message translates to:
  /// **'Tap the image to change your profile picture.'**
  String get tapToChangeProfilePicture;

  /// No description provided for @save.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// No description provided for @bioSaved.
  ///
  /// In en, this message translates to:
  /// **'Bio Saved (Not Implemented)'**
  String get bioSaved;

  /// No description provided for @manageVideosScreen.
  ///
  /// In en, this message translates to:
  /// **'Navigate to Manage Videos screen (Not Implemented)'**
  String get manageVideosScreen;

  /// No description provided for @ramashatScreen.
  ///
  /// In en, this message translates to:
  /// **'Navigate to Ramashat screen (Not Implemented)'**
  String get ramashatScreen;

  /// No description provided for @languageSelection.
  ///
  /// In en, this message translates to:
  /// **'Language selection (Not Implemented)'**
  String get languageSelection;

  /// No description provided for @changePhoneNumberScreen.
  ///
  /// In en, this message translates to:
  /// **'Navigate to Change Phone Number screen (Not Implemented)'**
  String get changePhoneNumberScreen;

  /// No description provided for @accountDeletion.
  ///
  /// In en, this message translates to:
  /// **'Account Deletion (Not Implemented)'**
  String get accountDeletion;

  /// No description provided for @darkModeEnabled.
  ///
  /// In en, this message translates to:
  /// **'Dark Mode Enabled (UI Only)'**
  String get darkModeEnabled;

  /// No description provided for @darkModeDisabled.
  ///
  /// In en, this message translates to:
  /// **'Dark Mode Disabled (UI Only)'**
  String get darkModeDisabled;

  /// No description provided for @newPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'New Phone Number'**
  String get newPhoneNumber;

  /// No description provided for @phoneNumberUpdated.
  ///
  /// In en, this message translates to:
  /// **'Phone Number Updated (Not Implemented)'**
  String get phoneNumberUpdated;

  /// No description provided for @areYouSureYouWantToDeleteYourAccount.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to delete your account? This action is irreversible.'**
  String get areYouSureYouWantToDeleteYourAccount;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @delete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get delete;

  /// No description provided for @makePublic.
  ///
  /// In en, this message translates to:
  /// **'Make Public'**
  String get makePublic;

  /// No description provided for @makePrivate.
  ///
  /// In en, this message translates to:
  /// **'Make Private'**
  String get makePrivate;

  /// No description provided for @privacyUpdated.
  ///
  /// In en, this message translates to:
  /// **'Privacy Updated'**
  String get privacyUpdated;

  /// No description provided for @deleteVideo.
  ///
  /// In en, this message translates to:
  /// **'Delete Video'**
  String get deleteVideo;

  /// No description provided for @areYouSureYouWantToDeleteThisVideo.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to delete this video?'**
  String get areYouSureYouWantToDeleteThisVideo;

  /// No description provided for @videoDeleted.
  ///
  /// In en, this message translates to:
  /// **'Video Deleted'**
  String get videoDeleted;

  /// No description provided for @loginWelcome.
  ///
  /// In en, this message translates to:
  /// **'Welcome ...'**
  String get loginWelcome;

  /// No description provided for @loginEnterPhone.
  ///
  /// In en, this message translates to:
  /// **'Enter your phone number to continue'**
  String get loginEnterPhone;

  /// No description provided for @loginEnterOTP.
  ///
  /// In en, this message translates to:
  /// **'Enter the verification code'**
  String get loginEnterOTP;

  /// No description provided for @loginSendOTP.
  ///
  /// In en, this message translates to:
  /// **'Send Code'**
  String get loginSendOTP;

  /// No description provided for @loginVerifyOTP.
  ///
  /// In en, this message translates to:
  /// **'Verify Code'**
  String get loginVerifyOTP;

  /// No description provided for @loginChangeNumber.
  ///
  /// In en, this message translates to:
  /// **'Change Number?'**
  String get loginChangeNumber;

  /// No description provided for @loginInvalidCountryCode.
  ///
  /// In en, this message translates to:
  /// **'Invalid'**
  String get loginInvalidCountryCode;

  /// No description provided for @loginEnterPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Please enter a phone number'**
  String get loginEnterPhoneNumber;

  /// No description provided for @loginInvalidOTP.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid code'**
  String get loginInvalidOTP;

  /// No description provided for @loginOTPCode.
  ///
  /// In en, this message translates to:
  /// **'OTP Code'**
  String get loginOTPCode;

  /// No description provided for @loginPhoneNumberHint.
  ///
  /// In en, this message translates to:
  /// **'Phone Number'**
  String get loginPhoneNumberHint;

  /// No description provided for @editVideo.
  ///
  /// In en, this message translates to:
  /// **'Edit Video'**
  String get editVideo;

  /// No description provided for @speed.
  ///
  /// In en, this message translates to:
  /// **'Speed'**
  String get speed;

  /// No description provided for @text.
  ///
  /// In en, this message translates to:
  /// **'Text'**
  String get text;

  /// No description provided for @audio.
  ///
  /// In en, this message translates to:
  /// **'Audio'**
  String get audio;

  /// No description provided for @exporting.
  ///
  /// In en, this message translates to:
  /// **'Exporting...'**
  String get exporting;

  /// No description provided for @pleaseLoginFirst.
  ///
  /// In en, this message translates to:
  /// **'Please login first'**
  String get pleaseLoginFirst;

  /// No description provided for @applyingFilters.
  ///
  /// In en, this message translates to:
  /// **'Applying filters...'**
  String get applyingFilters;

  /// No description provided for @failedToApplyFilter.
  ///
  /// In en, this message translates to:
  /// **'Failed to apply filter'**
  String get failedToApplyFilter;

  /// No description provided for @compressing.
  ///
  /// In en, this message translates to:
  /// **'Compressing...'**
  String get compressing;

  /// No description provided for @compressionFailed.
  ///
  /// In en, this message translates to:
  /// **'Compression failed'**
  String get compressionFailed;

  /// No description provided for @uploading.
  ///
  /// In en, this message translates to:
  /// **'Uploading...'**
  String get uploading;

  /// No description provided for @saving.
  ///
  /// In en, this message translates to:
  /// **'Saving...'**
  String get saving;

  /// No description provided for @publishedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Published successfully! ✅'**
  String get publishedSuccessfully;

  /// No description provided for @videoPublishedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Video published successfully!'**
  String get videoPublishedSuccessfully;

  /// No description provided for @error.
  ///
  /// In en, this message translates to:
  /// **'Error'**
  String get error;

  /// No description provided for @publishingFailed.
  ///
  /// In en, this message translates to:
  /// **'Publishing failed'**
  String get publishingFailed;
}

class _SDelegate extends LocalizationsDelegate<S> {
  const _SDelegate();

  @override
  Future<S> load(Locale locale) {
    return SynchronousFuture<S>(lookupS(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_SDelegate old) => false;
}

S lookupS(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar':
      return SAr();
    case 'en':
      return SEn();
  }

  throw FlutterError(
    'S.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
