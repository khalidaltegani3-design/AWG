// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class SAr extends S {
  SAr([String locale = 'ar']) : super(locale);

  @override
  String get settings => 'الإعدادات';

  @override
  String get profile => 'الملف الشخصي';

  @override
  String get editBio => 'تعديل السيرة الذاتية';

  @override
  String get writeSomethingAboutYourself => 'اكتب شيئًا عن نفسك';

  @override
  String get channelManagement => 'إدارة القناة';

  @override
  String get manageMyBlinks => 'إدارة مقاطعي (بلينكس)';

  @override
  String get viewDeleteOrChangePrivacy =>
      'عرض أو حذف أو تغيير خصوصية مقاطع الفيديو الخاصة بك';

  @override
  String get viewMyProfile => 'عرض ملفي الشخصي';

  @override
  String get seeYourPublicProfile => 'شاهد ملفك الشخصي العام';

  @override
  String get appSettings => 'إعدادات التطبيق';

  @override
  String get darkMode => 'الوضع الداكن';

  @override
  String get language => 'اللغة';

  @override
  String get account => 'الحساب';

  @override
  String get changePhoneNumber => 'تغيير رقم الهاتف';

  @override
  String get updateYourPhoneNumber => 'تحديث رقم الهاتف المرتبط بحسابك';

  @override
  String get deleteAccount => 'حذف الحساب';

  @override
  String get permanentlyDeleteYourAccount =>
      'حذف حسابك وجميع بياناتك بشكل دائم';

  @override
  String get takeNewPhoto => 'التقاط صورة جديدة';

  @override
  String get chooseFromGallery => 'الاختيار من المعرض';

  @override
  String get tapToChangeProfilePicture =>
      'انقر على الصورة لتغيير صورة ملفك الشخصي.';

  @override
  String get save => 'حفظ';

  @override
  String get bioSaved => 'تم حفظ السيرة الذاتية (غير مطبق)';

  @override
  String get manageVideosScreen =>
      'الانتقال إلى شاشة إدارة مقاطع الفيديو (غير مطبق)';

  @override
  String get ramashatScreen => 'الانتقال إلى شاشة رماشت (غير مطبق)';

  @override
  String get languageSelection => 'اختيار اللغة (غير مطبق)';

  @override
  String get changePhoneNumberScreen =>
      'الانتقال إلى شاشة تغيير رقم الهاتف (غير مطبق)';

  @override
  String get accountDeletion => 'حذف الحساب (غير مطبق)';

  @override
  String get darkModeEnabled => 'تمكين الوضع الداكن (واجهة المستخدم فقط)';

  @override
  String get darkModeDisabled => 'تعطيل الوضع الداكن (واجهة المستخدم فقط)';

  @override
  String get newPhoneNumber => 'رقم الهاتف الجديد';

  @override
  String get phoneNumberUpdated => 'تم تحديث رقم الهاتف (غير مطبق)';

  @override
  String get areYouSureYouWantToDeleteYourAccount =>
      'هل أنت متأكد أنك تريد حذف حسابك؟ هذا الإجراء لا يمكن التراجع عنه.';

  @override
  String get cancel => 'إلغاء';

  @override
  String get delete => 'حذف';

  @override
  String get makePublic => 'جعله عامًا';

  @override
  String get makePrivate => 'جعله خاصًا';

  @override
  String get privacyUpdated => 'تم تحديث الخصوصية';

  @override
  String get deleteVideo => 'حذف الفيديو';

  @override
  String get areYouSureYouWantToDeleteThisVideo =>
      'هل أنت متأكد أنك تريد حذف هذا الفيديو؟';

  @override
  String get videoDeleted => 'تم حذف الفيديو';

  @override
  String get loginWelcome => 'أهلاً بك ...';

  @override
  String get loginEnterPhone => 'أدخل رقم هاتفك للمتابعة';

  @override
  String get loginEnterOTP => 'أدخل رمز التحقق';

  @override
  String get loginSendOTP => 'إرسال الرمز';

  @override
  String get loginVerifyOTP => 'تحقق من الرمز';

  @override
  String get loginChangeNumber => 'تغيير الرقم؟';

  @override
  String get loginInvalidCountryCode => 'غير صالح';

  @override
  String get loginEnterPhoneNumber => 'يرجى إدخال رقم هاتف';

  @override
  String get loginInvalidOTP => 'يرجى إدخال رمز صالح';

  @override
  String get loginOTPCode => 'رمز التحقق';

  @override
  String get loginPhoneNumberHint => 'رقم الهاتف';

  @override
  String get editVideo => 'تعديل الفيديو';

  @override
  String get speed => 'سرعة';

  @override
  String get text => 'نص';

  @override
  String get audio => 'صوت';

  @override
  String get exporting => 'جاري التصدير...';

  @override
  String get pleaseLoginFirst => 'الرجاء تسجيل الدخول أولا';

  @override
  String get applyingFilters => 'تطبيق الفلاتر...';

  @override
  String get failedToApplyFilter => 'فشل تطبيق الفلتر';

  @override
  String get compressing => 'جاري الضغط...';

  @override
  String get compressionFailed => 'فشل الضغط';

  @override
  String get uploading => 'جاري الرفع...';

  @override
  String get saving => 'جاري الحفظ...';

  @override
  String get publishedSuccessfully => 'تم النشر بنجاح! ✅';

  @override
  String get videoPublishedSuccessfully => 'تم نشر الفيديو بنجاح!';

  @override
  String get error => 'خطأ';

  @override
  String get publishingFailed => 'فشل النشر';
}
