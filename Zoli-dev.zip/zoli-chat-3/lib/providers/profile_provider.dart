import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileProvider with ChangeNotifier {
  String _bio = "";
  File? _profileImage;
  String _username = "";

  String get bio => _bio;
  File? get profileImage => _profileImage;
  String get username => _username;

  ProfileProvider() {
    _loadProfile();
  }

  void _loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    _bio = prefs.getString('user_bio') ?? 'Write something about yourself...';
    String? imagePath = prefs.getString('profile_image_path');
    if (imagePath != null) {
      _profileImage = File(imagePath);
    }
    notifyListeners();
  }

  Future<void> updateBio(String newBio) async {
    if (_bio == newBio) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_bio', newBio);
    _bio = newBio;
    notifyListeners();
  }

  Future<void> updateProfileImage(File image) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('profile_image_path', image.path);
    _profileImage = image;
    notifyListeners();
  }
}
