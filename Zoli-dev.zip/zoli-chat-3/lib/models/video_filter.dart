import 'package:flutter/material.dart';
import 'package:flutter_gpu_video_filters/flutter_gpu_video_filters.dart';

class VideoFilter {
  final String name;
  final GPUFilterConfiguration configuration;

  VideoFilter(this.name, this.configuration);
}

final videoFilters = [
  VideoFilter('Original', PassthroughShaderConfiguration()),
  VideoFilter('Sepia', SepiaShaderConfiguration()),
  VideoFilter('Grayscale', GrayscaleShaderConfiguration()),
  VideoFilter('Invert', InvertShaderConfiguration()),
  VideoFilter('Vignette', VignetteShaderConfiguration()),
  VideoFilter('Box Blur', BoxBlurShaderConfiguration()),
  VideoFilter('Gaussian Blur', GaussianBlurShaderConfiguration()),
  VideoFilter('Zoom Blur', ZoomBlurShaderConfiguration()),
  VideoFilter('Toon', ToonShaderConfiguration()),
  VideoFilter('Luminance', LuminanceShaderConfiguration()),
  VideoFilter('Brightness', BrightnessShaderConfiguration()),
  VideoFilter('Contrast', ContrastShaderConfiguration()),
  VideoFilter('Exposure', ExposureShaderConfiguration()),
  VideoFilter('Hue', HueShaderConfiguration()),
  VideoFilter('Gamma', GammaShaderConfiguration()),
  VideoFilter('Saturation', SaturationShaderConfiguration()),
  VideoFilter('Sharpen', SharpenShaderConfiguration()),
  VideoFilter('Levels', LevelsShaderConfiguration()),
];
