/// نموذج لتراك الموسيقى
class MusicTrack {
  final String id;
  final String title;
  final String artist;
  final String genre;
  final Duration duration;
  final String audioUrl;
  final String coverArtUrl;
  final String waveformUrl;

  MusicTrack({
    required this.id,
    required this.title,
    required this.artist,
    required this.genre,
    required this.duration,
    required this.audioUrl,
    required this.coverArtUrl,
    required this.waveformUrl,
  });

  factory MusicTrack.fromJson(Map<String, dynamic> json) {
    return MusicTrack(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      artist: json['artist'] ?? '',
      genre: json['genre'] ?? '',
      duration: Duration(milliseconds: json['duration'] ?? 0),
      audioUrl: json['audioUrl'] ?? '',
      coverArtUrl: json['coverArtUrl'] ?? '',
      waveformUrl: json['waveformUrl'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'artist': artist,
      'genre': genre,
      'duration': duration.inMilliseconds,
      'audioUrl': audioUrl,
      'coverArtUrl': coverArtUrl,
      'waveformUrl': waveformUrl,
    };
  }

  String get formattedDuration {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '$minutes:${seconds.toString().padLeft(2, '0')}';
  }
}
