import 'package:cloud_firestore/cloud_firestore.dart';

/// نموذج بيانات الرمشة (Ramshat)
/// يحتوي على جميع المعلومات المتعلقة بفيديو الرمشة
class RamshatModel {
  final String id;
  final String uid; // صاحب الرمشة
  final String title;
  final int durationMs; // مدة الفيديو بالميلي ثانية
  final String visibility; // public, private, friends
  final String status; // draft, processing, published, blocked
  final String? videoUrl; // رابط الفيديو في Storage
  final String? thumbUrl; // رابط الصورة المصغرة
  final int likes;
  final int views;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final String? transcodeProfile; // feed-720p, full-1080p, etc.
  final String? region; // QA, SA, etc.
  final Map<String, dynamic>? metadata; // بيانات إضافية

  RamshatModel({
    required this.id,
    required this.uid,
    required this.title,
    this.durationMs = 0,
    this.visibility = 'public',
    this.status = 'draft',
    this.videoUrl,
    this.thumbUrl,
    this.likes = 0,
    this.views = 0,
    required this.createdAt,
    this.updatedAt,
    this.transcodeProfile,
    this.region,
    this.metadata,
  });

  /// التحويل من Firebase Document إلى Model
  factory RamshatModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;

    return RamshatModel(
      id: doc.id,
      uid: data['uid'] ?? '',
      title: data['title'] ?? '',
      durationMs: data['durationMs'] ?? 0,
      visibility: data['visibility'] ?? 'public',
      status: data['status'] ?? 'draft',
      videoUrl: data['videoUrl'],
      thumbUrl: data['thumbUrl'],
      likes: data['likes'] ?? 0,
      views: data['views'] ?? 0,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
      transcodeProfile: data['transcodeProfile'],
      region: data['region'],
      metadata: data['metadata'] as Map<String, dynamic>?,
    );
  }

  /// التحويل من Map إلى Model
  factory RamshatModel.fromMap(Map<String, dynamic> map, String id) {
    return RamshatModel(
      id: id,
      uid: map['uid'] ?? '',
      title: map['title'] ?? '',
      durationMs: map['durationMs'] ?? 0,
      visibility: map['visibility'] ?? 'public',
      status: map['status'] ?? 'draft',
      videoUrl: map['videoUrl'],
      thumbUrl: map['thumbUrl'],
      likes: map['likes'] ?? 0,
      views: map['views'] ?? 0,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (map['updatedAt'] as Timestamp?)?.toDate(),
      transcodeProfile: map['transcodeProfile'],
      region: map['region'],
      metadata: map['metadata'] as Map<String, dynamic>?,
    );
  }

  /// التحويل من Model إلى Map لحفظها في Firestore
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'title': title,
      'durationMs': durationMs,
      'visibility': visibility,
      'status': status,
      'videoUrl': videoUrl,
      'thumbUrl': thumbUrl,
      'likes': likes,
      'views': views,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'transcodeProfile': transcodeProfile,
      'region': region,
      'metadata': metadata,
    };
  }

  /// نسخ Model مع تعديل بعض القيم
  RamshatModel copyWith({
    String? id,
    String? uid,
    String? title,
    int? durationMs,
    String? visibility,
    String? status,
    String? videoUrl,
    String? thumbUrl,
    int? likes,
    int? views,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? transcodeProfile,
    String? region,
    Map<String, dynamic>? metadata,
  }) {
    return RamshatModel(
      id: id ?? this.id,
      uid: uid ?? this.uid,
      title: title ?? this.title,
      durationMs: durationMs ?? this.durationMs,
      visibility: visibility ?? this.visibility,
      status: status ?? this.status,
      videoUrl: videoUrl ?? this.videoUrl,
      thumbUrl: thumbUrl ?? this.thumbUrl,
      likes: likes ?? this.likes,
      views: views ?? this.views,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      transcodeProfile: transcodeProfile ?? this.transcodeProfile,
      region: region ?? this.region,
      metadata: metadata ?? this.metadata,
    );
  }

  /// تنسيق المدة بشكل مقروء (MM:SS)
  String get formattedDuration {
    final seconds = durationMs ~/ 1000;
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  /// هل الرمشة منشورة؟
  bool get isPublished => status == 'published';

  /// هل الرمشة قيد المعالجة؟
  bool get isProcessing => status == 'processing';

  /// هل الرمشة محظورة؟
  bool get isBlocked => status == 'blocked';

  /// هل الرمشة عامة؟
  bool get isPublic => visibility == 'public';

  @override
  String toString() {
    return 'RamshatModel(id: $id, title: $title, status: $status, visibility: $visibility)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is RamshatModel && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}

/// حالات الرمشة
enum RamshatStatus { draft, processing, published, blocked }

/// مستويات الرؤية
enum RamshatVisibility { public, private, friends }

/// Extension للتحويل من/إلى String
extension RamshatStatusExtension on RamshatStatus {
  String get value {
    switch (this) {
      case RamshatStatus.draft:
        return 'draft';
      case RamshatStatus.processing:
        return 'processing';
      case RamshatStatus.published:
        return 'published';
      case RamshatStatus.blocked:
        return 'blocked';
    }
  }

  static RamshatStatus fromString(String status) {
    switch (status) {
      case 'draft':
        return RamshatStatus.draft;
      case 'processing':
        return RamshatStatus.processing;
      case 'published':
        return RamshatStatus.published;
      case 'blocked':
        return RamshatStatus.blocked;
      default:
        return RamshatStatus.draft;
    }
  }
}

extension RamshatVisibilityExtension on RamshatVisibility {
  String get value {
    switch (this) {
      case RamshatVisibility.public:
        return 'public';
      case RamshatVisibility.private:
        return 'private';
      case RamshatVisibility.friends:
        return 'friends';
    }
  }

  static RamshatVisibility fromString(String visibility) {
    switch (visibility) {
      case 'public':
        return RamshatVisibility.public;
      case 'private':
        return RamshatVisibility.private;
      case 'friends':
        return RamshatVisibility.friends;
      default:
        return RamshatVisibility.public;
    }
  }
}
