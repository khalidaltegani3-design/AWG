import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:zoli_chat/providers/language_provider.dart';
import 'package:zoli_chat/providers/theme_provider.dart';
import 'package:zoli_chat/providers/profile_provider.dart';
import 'package:zoli_chat/services/call_service.dart';
import 'package:zoli_chat/services/status_service.dart';
import 'package:zoli_chat/services/user_service.dart';
import 'package:zoli_chat/themes.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:zoli_chat/screens/login_screen.dart';
import 'package:zoli_chat/services/auth_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_performance/firebase_performance.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:zoli_chat/screens/profile_setup_screen.dart';
import 'firebase_options.dart';

import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // App Check is disabled to avoid reCAPTCHA prompts
  // Firebase Phone Auth will use automatic verification when possible
  // For production with Play Store, enable App Check with Play Integrity provider
  
  // Initialize Crashlytics
  FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
  PlatformDispatcher.instance.onError = (error, stack) {
    FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    return true;
  };

  // Initialize Performance Monitoring
  FirebasePerformance.instance.setPerformanceCollectionEnabled(true);

  // Configure Firestore settings
  FirebaseFirestore.instance.settings = const Settings(
    persistenceEnabled: true,
    cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
  );

  // Initialize Remote Config with default values
  final remoteConfig = FirebaseRemoteConfig.instance;
  await remoteConfig.setConfigSettings(
    RemoteConfigSettings(
      fetchTimeout: const Duration(seconds: 10),
      minimumFetchInterval: const Duration(hours: 1),
    ),
  );
  await remoteConfig.setDefaults(<String, dynamic>{
    'feed_page_size': 10,
    'upload_max_duration_ms': 60000, // 60 seconds
    'upload_max_size_mb': 100,
    'bitrate_target': 2500000, // 2.5 Mbps
    'video_quality': '720p',
    'enable_compression': true,
    'enable_notifications': true,
  });
  try {
    await remoteConfig.fetchAndActivate();
  } catch (e) {
    debugPrint('Remote Config fetch failed: $e');
  }

  // Create the theme provider
  final themeProvider = await ThemeProvider.create();

  runApp(
    MultiProvider(
      providers: [
        Provider<AuthService>(create: (_) => AuthService()),
        Provider<UserService>(create: (_) => UserService()),
        ChangeNotifierProvider.value(value: themeProvider),
        ChangeNotifierProvider(create: (_) => LanguageProvider()),
        ChangeNotifierProvider(create: (_) => ProfileProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<StatusService>(
          create: (_) => StatusService(),
          dispose: (_, service) => service.dispose(),
        ),
        Provider<CallService>(
          create: (_) => CallService(),
          dispose: (_, service) => service.dispose(),
        ),
      ],
      child: Consumer2<ThemeProvider, LanguageProvider>(
        builder: (context, themeProvider, languageProvider, child) {
          return MaterialApp(
            locale: languageProvider.appLocale, // Can be null
            localeResolutionCallback: (locale, supportedLocales) {
              // If the app locale is set, use it.
              if (languageProvider.appLocale != null) {
                return languageProvider.appLocale;
              }
              // Otherwise, try to match the device locale with a supported locale.
              for (var supportedLocale in supportedLocales) {
                if (supportedLocale.languageCode == locale?.languageCode) {
                  return supportedLocale;
                }
              }
              // If no match is found, fall back to the first supported locale.
              return supportedLocales.first;
            },
            title: 'Zoli',
            theme: AppThemes.lightTheme,
            darkTheme: AppThemes.darkTheme,
            themeMode: themeProvider.themeMode,
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            supportedLocales: const [
              Locale('en', ''), // English, no country code
              Locale('ar', ''), // Arabic, no country code
            ],
            home: const AuthWrapper(),
          );
        },
      ),
    );
  }
}

class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context);
    final userService = Provider.of<UserService>(context, listen: false);

    return StreamBuilder<User?>(
      stream: authService.user,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.hasData && snapshot.data != null) {
          // User is logged in, check if they are a new user
          return FutureBuilder<bool>(
            future: userService.isNewUser(snapshot.data!.uid),
            builder: (context, isNewUserSnapshot) {
              if (isNewUserSnapshot.connectionState == ConnectionState.waiting) {
                return const Scaffold(
                  body: Center(child: CircularProgressIndicator()),
                );
              }

              if (isNewUserSnapshot.data == true) {
                // New user, redirect to profile setup
                return const ProfileSetupScreen();
              } else {
                // Existing user, go to home screen
                return const HomeScreen();
              }
            },
          );
        }

        // User is not logged in
        return const LoginScreen();
      },
    );
  }
}
