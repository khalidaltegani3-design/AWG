import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';

class SoundCloudSearchScreen extends StatefulWidget {
  const SoundCloudSearchScreen({super.key});

  @override
  State<SoundCloudSearchScreen> createState() => _SoundCloudSearchScreenState();
}

class _SoundCloudSearchScreenState extends State<SoundCloudSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<dynamic> _tracks = [];
  bool _isLoading = false;
  final AudioPlayer _audioPlayer = AudioPlayer();
  String? _playingUrl;

  Future<void> _searchSoundCloud(String query) async {
    if (query.isEmpty) return;

    setState(() {
      _isLoading = true;
    });

    // NOTE: This is a placeholder using a public, unofficial API.
    // For a production app, you should use the official SoundCloud API with authentication.
    final url = Uri.parse(
      'https://api-v2.soundcloud.com/search/tracks?q=$query&client_id=YOUR_CLIENT_ID&limit=20',
    );

    try {
      // Replace 'YOUR_CLIENT_ID' with a valid SoundCloud client ID.
      // Since obtaining a public client ID is difficult, this will likely fail.
      // This code is for demonstration of the UI and flow.
      final response = await http.get(
        url.replace(
          queryParameters: {
            'q': query,
            'limit': '20',
            'client_id': 'x7nBqf6aY1c3e0a5b1c2d3f4g5h6i7j8',
          },
        ),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _tracks = data['collection'];
        });
      } else {
        _showError('Failed to load tracks. Please try again.');
      }
    } catch (e) {
      _showError('An error occurred: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
    // As the API call will fail, populate with mock data for UI demonstration
    setState(() {
      _tracks = [
        {
          "title": "Motivational Inspiring",
          "user": {"username": "Artist One"},
          "artwork_url":
              "https://i1.sndcdn.com/artworks-000190497493-2w7v5c-large.jpg",
          "stream_url":
              "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
        },
        {
          "title": "Upbeat Energetic",
          "user": {"username": "Artist Two"},
          "artwork_url":
              "https://i1.sndcdn.com/artworks-000165478752-2q5b2q-large.jpg",
          "stream_url":
              "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
        },
      ];
    });
  }

  Future<void> _playPreview(String url) async {
    if (_playingUrl == url) {
      await _audioPlayer.stop();
      setState(() {
        _playingUrl = null;
      });
    } else {
      await _audioPlayer.play(UrlSource(url));
      setState(() {
        _playingUrl = url;
      });
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search SoundCloud')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search for a track',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () => _searchSoundCloud(_searchController.text),
                ),
              ),
              onSubmitted: _searchSoundCloud,
            ),
          ),
          _isLoading
              ? const Expanded(
                  child: Center(child: CircularProgressIndicator()),
                )
              : Expanded(
                  child: ListView.builder(
                    itemCount: _tracks.length,
                    itemBuilder: (context, index) {
                      final track = _tracks[index];
                      final artworkUrl =
                          track['artwork_url'] ??
                          'https://via.placeholder.com/150';
                      final streamUrl = track['stream_url'];

                      return ListTile(
                        leading: Image.network(artworkUrl),
                        title: Text(track['title'] ?? 'No Title'),
                        subtitle: Text(
                          track['user']['username'] ?? 'Unknown Artist',
                        ),
                        trailing: IconButton(
                          icon: Icon(
                            _playingUrl == streamUrl
                                ? Icons.stop
                                : Icons.play_arrow,
                          ),
                          onPressed: streamUrl != null
                              ? () => _playPreview(streamUrl)
                              : null,
                        ),
                        onTap: () {
                          if (streamUrl != null) {
                            _audioPlayer.stop();
                            Navigator.pop(context, streamUrl);
                          }
                        },
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }
}
