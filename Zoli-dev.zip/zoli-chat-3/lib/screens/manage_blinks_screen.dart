import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class ManageBlinksScreen extends StatefulWidget {
  const ManageBlinksScreen({super.key});

  @override
  State<ManageBlinksScreen> createState() => _ManageBlinksScreenState();
}

class _ManageBlinksScreenState extends State<ManageBlinksScreen> {
  late List<Map<String, dynamic>> _userVideos;

  @override
  void initState() {
    super.initState();
    // Mock data for user's videos
    _userVideos = List.generate(15, (index) {
      return {
        'id': 'video$index',
        'thumbnailUrl': 'https://picsum.photos/seed/video$index/300/500',
        'title': 'My Awesome Video ${index + 1}',
        'isPublic': index % 3 != 0, // Mock privacy status
      };
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage My Blinks"),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 1,
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(4.0),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4.0,
          mainAxisSpacing: 4.0,
          childAspectRatio:
              9 / 16, // Portrait aspect ratio for video thumbnails
        ),
        itemCount: _userVideos.length,
        itemBuilder: (context, index) {
          final video = _userVideos[index];
          return VideoThumbnailCard(
            thumbnailUrl: video['thumbnailUrl'],
            isPublic: video['isPublic'],
            onTap: () {
              _showVideoOptions(context, video, index);
            },
          );
        },
      ),
    );
  }

  void _showVideoOptions(
    BuildContext context,
    Map<String, dynamic> video,
    int index,
  ) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                title: Text(
                  video['title'],
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              const Divider(),
              ListTile(
                leading: Icon(video['isPublic'] ? Icons.lock_open : Icons.lock),
                title: Text(video['isPublic'] ? "Make Private" : "Make Public"),
                onTap: () {
                  setState(() {
                    _userVideos[index]['isPublic'] = !video['isPublic'];
                  });
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Privacy updated")),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete, color: Colors.red),
                title: const Text(
                  "Delete Video",
                  style: TextStyle(color: Colors.red),
                ),
                onTap: () {
                  Navigator.of(context).pop();
                  _showDeleteConfirmation(context, video['title'], index);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showDeleteConfirmation(
    BuildContext context,
    String videoTitle,
    int index,
  ) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Delete Video"),
          content: const Text("Are you sure you want to delete this video?"),
          actions: <Widget>[
            TextButton(
              child: const Text("Cancel"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text("Delete", style: TextStyle(color: Colors.red)),
              onPressed: () {
                setState(() {
                  _userVideos.removeAt(index);
                });
                Navigator.of(context).pop();
                ScaffoldMessenger.of(
                  context,
                ).showSnackBar(const SnackBar(content: Text("Video deleted")));
              },
            ),
          ],
        );
      },
    );
  }
}

class VideoThumbnailCard extends StatelessWidget {
  final String thumbnailUrl;
  final bool isPublic;
  final VoidCallback onTap;

  const VideoThumbnailCard({
    super.key,
    required this.thumbnailUrl,
    required this.isPublic,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: GridTile(
        footer: GridTileBar(
          backgroundColor: Colors.black45,
          leading: Icon(
            isPublic ? Icons.public : Icons.lock,
            color: Colors.white,
            size: 16,
          ),
          title: const Text(''), // Empty title, icon is enough
        ),
        child: Image.network(
          thumbnailUrl,
          fit: BoxFit.cover,
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) return child;
            return const Center(child: CircularProgressIndicator());
          },
          errorBuilder: (context, error, stackTrace) {
            return const Center(child: Icon(Icons.error, color: Colors.red));
          },
        ),
      ),
    );
  }
}
