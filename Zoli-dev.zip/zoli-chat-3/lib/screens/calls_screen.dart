import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:zoli_chat/screens/on_call_screen.dart';
import 'package:zoli_chat/services/call_service.dart';
import 'package:zoli_chat/providers/language_provider.dart';
import 'package:provider/provider.dart';

class CallsScreen extends StatefulWidget {
  const CallsScreen({super.key});

  @override
  State<CallsScreen> createState() => _CallsScreenState();
}

class _CallsScreenState extends State<CallsScreen> {
  late final CallService _callService;

  @override
  void initState() {
    super.initState();
    _callService = Provider.of<CallService>(context, listen: false);
    _callService.getCallLogs(); // Initial fetch of call logs
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    return Scaffold(
      body: StreamBuilder<List<CallLog>>(
        stream: _callService.callLogsStream,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Text(
                isArabic ? 'لا توجد سجلات مكالمات بعد.' : 'No call logs yet.',
              ),
            );
          }

          final callLogs = snapshot.data!;

          return ListView.builder(
            itemCount: callLogs.length,
            itemBuilder: (context, index) {
              final call = callLogs[index];
              // A simple way to format the time without the intl package
              final timeString =
                  '${call.timestamp.toLocal().hour}:${call.timestamp.toLocal().minute.toString().padLeft(2, '0')}';

              return ListTile(
                leading: CircleAvatar(
                  backgroundImage: NetworkImage(call.avatarUrl),
                ),
                title: Text(call.name),
                subtitle: Row(
                  children: [
                    Icon(
                      call.type == CallType.incoming
                          ? Ionicons.arrow_down_outline
                          : call.type == CallType.outgoing
                          ? Ionicons.arrow_up_outline
                          : Ionicons.arrow_down_outline,
                      color: call.type == CallType.missed
                          ? Colors.red
                          : Colors.green,
                      size: 16,
                    ),
                    const SizedBox(width: 4),
                    // TODO: Use intl package for better date formatting later
                    Text(timeString),
                  ],
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(
                        Ionicons.call_outline,
                        color: Theme.of(context).primaryColor,
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => OnCallScreen(
                              contactName: call.name,
                              contactAvatarUrl: call.avatarUrl,
                            ),
                          ),
                        );
                      },
                    ),
                    IconButton(
                      icon: Icon(
                        Ionicons.videocam_outline,
                        color: Theme.of(context).primaryColor,
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => OnCallScreen(
                              contactName: call.name,
                              contactAvatarUrl: call.avatarUrl,
                              isVideo: true,
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
