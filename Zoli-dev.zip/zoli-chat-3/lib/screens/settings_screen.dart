import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:provider/provider.dart';
import 'package:zoli_chat/providers/language_provider.dart';
import 'package:zoli_chat/providers/profile_provider.dart';
import 'package:zoli_chat/providers/theme_provider.dart';
import 'package:zoli_chat/services/auth_service.dart';
import 'change_phone_number_screen.dart';
import 'manage_blinks_screen.dart';
import 'profile_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _bioController;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final profileProvider = Provider.of<ProfileProvider>(context);
    _bioController = TextEditingController(text: profileProvider.bio);
  }

  @override
  void dispose() {
    _bioController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(
    ImageSource source,
    ProfileProvider profileProvider,
  ) async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: source);

    if (image != null) {
      await profileProvider.updateProfileImage(File(image.path));
    }
  }

  void _showImagePickerOptions(
    BuildContext context,
    ProfileProvider profileProvider,
  ) {
    final languageProvider = Provider.of<LanguageProvider>(
      context,
      listen: false,
    );
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: Text(isArabic ? "التقاط صورة جديدة" : "Take New Photo"),
                onTap: () {
                  _pickImage(ImageSource.camera, profileProvider);
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: Text(
                  isArabic ? "اختيار من المعرض" : "Choose From Gallery",
                ),
                onTap: () {
                  _pickImage(ImageSource.gallery, profileProvider);
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showLanguagePicker(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(
      context,
      listen: false,
    );
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return SimpleDialog(
          title: Text(isArabic ? "اللغة" : "Language"),
          children: <Widget>[
            SimpleDialogOption(
              onPressed: () {
                languageProvider.changeLanguage(const Locale('en'));
                Navigator.pop(context);
              },
              child: const Text('English'),
            ),
            SimpleDialogOption(
              onPressed: () {
                languageProvider.changeLanguage(const Locale('ar'));
                Navigator.pop(context);
              },
              child: const Text('العربية'),
            ),
          ],
        );
      },
    );
  }

  void _showDeleteAccountConfirmation(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(
      context,
      listen: false,
    );
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(isArabic ? "حذف الحساب" : "Delete Account"),
          content: Text(
            isArabic
                ? "هل أنت متأكد أنك تريد حذف حسابك؟"
                : "Are you sure you want to delete your account?",
          ),
          actions: <Widget>[
            TextButton(
              child: Text(isArabic ? "إلغاء" : "Cancel"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text(
                isArabic ? "حذف" : "Delete",
                style: const TextStyle(color: Colors.red),
              ),
              onPressed: () async {
                try {
                  await Provider.of<AuthService>(
                    context,
                    listen: false,
                  ).deleteAccount();
                  Navigator.of(context).popUntil((route) => route.isFirst);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        isArabic
                            ? "تم حذف الحساب بنجاح."
                            : "Account deleted successfully.",
                      ),
                    ),
                  );
                } catch (e) {
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        isArabic
                            ? "فشل حذف الحساب. قد تحتاج إلى إعادة تسجيل الدخول."
                            : "Failed to delete account. You may need to sign in again.",
                      ),
                    ),
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final languageProvider = Provider.of<LanguageProvider>(context);
    final profileProvider = Provider.of<ProfileProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? "الإعدادات" : "Settings"),
        elevation: 1,
      ),
      body: ListView(
        children: [
          _buildSectionHeader(isArabic ? "الملف الشخصي" : "Profile"),
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 8.0,
            ),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () =>
                      _showImagePickerOptions(context, profileProvider),
                  child: CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.grey.shade300,
                    backgroundImage: profileProvider.profileImage != null
                        ? FileImage(profileProvider.profileImage!)
                        : null,
                    child: profileProvider.profileImage == null
                        ? const Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                            size: 30,
                          )
                        : null,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    isArabic
                        ? "اضغط لتغيير صورة الملف الشخصي"
                        : "Tap to change profile picture",
                    style: TextStyle(
                      color: Theme.of(
                        context,
                      ).textTheme.bodyMedium?.color?.withOpacity(0.6),
                    ),
                  ),
                ),
              ],
            ),
          ),
          _buildTextFieldTile(
            isArabic ? "تعديل النبذة" : "Edit Bio",
            _bioController,
            isArabic ? "اكتب شيئاً عن نفسك" : "Write something about yourself",
            profileProvider,
          ),

          _buildSectionHeader(isArabic ? "إدارة القناة" : "Channel Management"),
          _buildSettingsTile(
            isArabic ? "إدارة رمشاتي" : "Manage My Blinks",
            isArabic
                ? "عرض، حذف، أو تغيير الخصوصية"
                : "View, delete, or change privacy",
            Icons.video_library,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ManageBlinksScreen(),
                ),
              );
            },
          ),
          _buildSettingsTile(
            isArabic ? "عرض ملفي الشخصي" : "View My Profile",
            isArabic ? "شاهد ملفك الشخصي العام" : "See your public profile",
            Icons.person,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      ProfileScreen(username: profileProvider.username),
                ),
              );
            },
          ),

          _buildSectionHeader(isArabic ? "إعدادات التطبيق" : "App Settings"),
          SwitchListTile(
            title: Text(isArabic ? "الوضع الداكن" : "Dark Mode"),
            secondary: const Icon(Icons.brightness_6),
            value: themeProvider.themeMode == ThemeMode.dark,
            onChanged: (bool value) {
              themeProvider.toggleTheme(value);
            },
          ),
          _buildSettingsTile(
            isArabic ? "اللغة" : "Language",
            languageProvider.appLocale?.languageCode == 'ar'
                ? 'العربية'
                : 'English',
            Icons.language,
            () {
              _showLanguagePicker(context);
            },
          ),

          _buildSectionHeader(isArabic ? "الحساب" : "Account"),
          _buildSettingsTile(
            isArabic ? "تغيير رقم الهاتف" : "Change Phone Number",
            isArabic ? "تحديث رقم هاتفك" : "Update your phone number",
            Icons.phone,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ChangePhoneNumberScreen(),
                ),
              );
            },
          ),
          _buildSettingsTile(
            isArabic ? "حذف الحساب" : "Delete Account",
            isArabic ? "حذف حسابك نهائياً" : "Permanently delete your account",
            Icons.delete_forever,
            () {
              _showDeleteAccountConfirmation(context);
            },
            isDestructive: true,
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16.0, 20.0, 16.0, 8.0),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          color: Theme.of(context).primaryColor,
          fontWeight: FontWeight.bold,
          fontSize: 14,
        ),
      ),
    );
  }

  Widget _buildSettingsTile(
    String title,
    String subtitle,
    IconData icon,
    VoidCallback onTap, {
    bool isDestructive = false,
  }) {
    final color = isDestructive
        ? Colors.red
        : Theme.of(context).iconTheme.color;
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(
        title,
        style: TextStyle(color: isDestructive ? Colors.red : null),
      ),
      subtitle: Text(subtitle),
      onTap: onTap,
    );
  }

  Widget _buildTextFieldTile(
    String label,
    TextEditingController controller,
    String hint,
    ProfileProvider profileProvider,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: const OutlineInputBorder(),
          suffixIcon: IconButton(
            icon: const Icon(Icons.save),
            onPressed: () {
              profileProvider.updateBio(controller.text);
              FocusScope.of(context).unfocus();
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text("Bio Saved")));
            },
          ),
        ),
        maxLines: 3,
      ),
    );
  }
}
