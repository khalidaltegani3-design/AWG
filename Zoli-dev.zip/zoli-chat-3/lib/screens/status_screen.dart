import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:zoli_chat/screens/status_viewer_screen.dart';
import 'package:zoli_chat/services/status_service.dart';
import 'package:zoli_chat/providers/language_provider.dart';
import 'package:provider/provider.dart';

class StatusScreen extends StatefulWidget {
  const StatusScreen({super.key});

  @override
  State<StatusScreen> createState() => _StatusScreenState();
}

class _StatusScreenState extends State<StatusScreen> {
  final ImagePicker _picker = ImagePicker();
  late final StatusService _statusService;

  @override
  void initState() {
    super.initState();
    _statusService = Provider.of<StatusService>(context, listen: false);
  }

  void _showAddStatusOptions() {
    final languageProvider = Provider.of<LanguageProvider>(
      context,
      listen: false,
    );
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Ionicons.camera_outline),
                title: Text(isArabic ? 'الكاميرا' : 'Camera'),
                onTap: () async {
                  Navigator.of(context).pop();
                  final XFile? image = await _picker.pickImage(
                    source: ImageSource.camera,
                  );
                  if (image != null) {
                    _statusService.addMyStatus(image.path);
                  }
                },
              ),
              ListTile(
                leading: const Icon(Ionicons.images_outline),
                title: Text(isArabic ? 'المعرض' : 'Gallery'),
                onTap: () async {
                  Navigator.of(context).pop();
                  final XFile? image = await _picker.pickImage(
                    source: ImageSource.gallery,
                  );
                  if (image != null) {
                    _statusService.addMyStatus(image.path);
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    return Scaffold(
      body: StreamBuilder<List<UserStatus>>(
        stream: _statusService.getStatuses(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Text(
                isArabic ? 'لا توجد حالات متاحة.' : 'No statuses available.',
              ),
            );
          }

          final allStatuses = snapshot.data!;
          final myStatus = allStatuses.firstWhere(
            (s) => s.userId == 'my_status',
            orElse: () => UserStatus(
              userId: 'my_status',
              username: 'My Status',
              statuses: [],
            ),
          );
          final recentUpdates = allStatuses
              .where((s) => s.userId != 'my_status' && s.statuses.isNotEmpty)
              .toList();

          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // My Status section
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: GestureDetector(
                      onTap: myStatus.statuses.isNotEmpty
                          ? () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      StatusViewerScreen(userStatus: myStatus),
                                ),
                              );
                            }
                          : _showAddStatusOptions,
                      child: Stack(
                        alignment: Alignment.bottomRight,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: myStatus.statuses.isNotEmpty
                                    ? theme.primaryColor
                                    : Colors.grey,
                                width: 3,
                              ),
                            ),
                            child: CircleAvatar(
                              radius: 30,
                              backgroundImage: myStatus.avatarUrl != null
                                  ? NetworkImage(myStatus.avatarUrl!)
                                  : null,
                              child: myStatus.avatarUrl == null
                                  ? const Icon(Icons.person, size: 30)
                                  : null,
                            ),
                          ),
                          if (myStatus.statuses.isEmpty)
                            CircleAvatar(
                              radius: 12,
                              backgroundColor: theme.primaryColor,
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                        ],
                      ),
                    ),
                    title: Text(
                      isArabic ? 'حالتي' : 'My status',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      myStatus.statuses.isEmpty
                          ? (isArabic
                                ? 'اضغط لإضافة حالة'
                                : 'Tap to add status update')
                          : (isArabic ? 'عرض حالتي' : 'View my update'),
                    ),
                    onTap: myStatus.statuses.isNotEmpty
                        ? () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    StatusViewerScreen(userStatus: myStatus),
                              ),
                            );
                          }
                        : _showAddStatusOptions,
                  ),
                  const SizedBox(height: 16),

                  // Recent updates section
                  if (recentUpdates.isNotEmpty)
                    Text(
                      isArabic ? 'التحديثات الأخيرة' : 'Recent updates',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  if (recentUpdates.isNotEmpty) const SizedBox(height: 10),

                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: recentUpdates.length,
                    itemBuilder: (context, index) {
                      final userStatus = recentUpdates[index];
                      return ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 8.0,
                        ),
                        leading: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: theme.primaryColor,
                              width: 3,
                            ),
                          ),
                          child: CircleAvatar(
                            radius: 30,
                            backgroundImage: userStatus.avatarUrl != null
                                ? NetworkImage(userStatus.avatarUrl!)
                                : null,
                            child: userStatus.avatarUrl == null
                                ? const Icon(Icons.person, size: 30)
                                : null,
                          ),
                        ),
                        title: Text(
                          userStatus.username,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          'Today, ${DateTime.now().hour}:${DateTime.now().minute - index * 5}',
                        ), // Mock time
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  StatusViewerScreen(userStatus: userStatus),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddStatusOptions,
        backgroundColor: theme.primaryColor,
        child: const Icon(Ionicons.camera, color: Colors.white),
      ),
    );
  }
}
