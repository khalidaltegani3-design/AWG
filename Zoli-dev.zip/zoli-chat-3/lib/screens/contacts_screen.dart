import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:zoli_chat/services/user_service.dart';
import 'package:zoli_chat/screens/chat_screen.dart';

class ContactsScreen extends StatefulWidget {
  const ContactsScreen({super.key});

  @override
  State<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  List<Contact> _contacts = [];
  Map<String, bool> _zoliUsersStatus = {};
  bool _isLoading = true;
  final UserService _userService = UserService();

  @override
  void initState() {
    super.initState();
    _fetchContacts();
  }

  Future<void> _fetchContacts() async {
    if (await FlutterContacts.requestPermission()) {
      final contacts = await FlutterContacts.getContacts(withProperties: true);
      setState(() {
        _contacts = contacts;
      });
      _checkZoliUsers();
    } else {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _checkZoliUsers() async {
    for (var contact in _contacts) {
      if (contact.phones.isNotEmpty) {
        final phone = contact.phones.first.number;
        final isZoliUser = await _userService.isZoliUser(phone);
        setState(() {
          _zoliUsersStatus[phone] = isZoliUser;
        });
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Chat'),
        actions: [
          IconButton(
            icon: const Icon(Ionicons.search_outline),
            onPressed: () {
              // TODO: Implement search functionality
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _contacts.length,
              itemBuilder: (context, index) {
                final contact = _contacts[index];
                final phoneNumber =
                    contact.phones.isNotEmpty ? contact.phones.first.number : null;
                final isZoliUser = _zoliUsersStatus[phoneNumber] ?? false;

                return ListTile(
                  leading: CircleAvatar(
                    child: Text(
                      contact.displayName.isNotEmpty
                          ? contact.displayName[0]
                          : '',
                    ),
                  ),
                  title: Text(contact.displayName),
                  subtitle: Text(phoneNumber ?? 'No phone number'),
                  trailing: isZoliUser
                      ? ElevatedButton(
                          child: const Text('Chat'),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ChatScreen(
                                  peerId: contact.id,
                                  peerName: contact.displayName,
                                  peerAvatar: '', // No avatar from contacts
                                ),
                              ),
                            );
                          },
                        )
                      : OutlinedButton(
                          child: const Text('Invite'),
                          onPressed: () {
                            // TODO: Implement invite functionality
                          },
                        ),
                );
              },
            ),
    );
  }
}
