# دليل استخدام SoundCloud API 🎵

## نظرة عامة

هذا الدليل يشرح كيفية استخدام SoundCloud API في تطبيق Zoli Chat.

---

## ⚠️ **تحذيرات مهمة**

### القيود القانونية
- ❌ SoundCloud أوقف قبول تطبيقات API جديدة منذ 2018
- ❌ استخدام Client ID غير رسمي قد يخالف شروط الخدمة
- ❌ لا يسمح بالتحميل التجاري
- ⚠️ قد يتم حظر Client ID في أي وقت

### المخاطر التقنية
- API قد يتغير دون إشعار
- Client ID قد يتوقف عن العمل
- قد تكون هناك قيود على عدد الطلبات
- جودة الصوت محدودة (preview/streaming فقط)

---

## 📋 **خطوات الإعداد**

### 1️⃣ الحصول على Client ID

#### الطريقة 1: يدوياً (موصى بها)
```bash
1. افتح https://soundcloud.com
2. افتح Developer Tools (F12)
3. اذهب لـ Network tab
4. شغل أي أغنية
5. ابحث عن طلب يحتوي على "client_id"
6. انسخ القيمة
```

#### الطريقة 2: باستخدام Python
```python
# نفذ extract_soundcloud_client_id.py
python extract_soundcloud_client_id.py
```

#### الطريقة 3: استخدام Client ID معروف (للاختبار فقط)
```dart
// ⚠️ قد لا يعمل - للاختبار فقط
static const String _clientId = 'iZIs9mchVcX5lhVRyQGGAYlNPVldzAoX';
```

### 2️⃣ إضافة Client ID للتطبيق

في `lib/services/soundcloud_service.dart`:
```dart
static const String _clientId = 'YOUR_CLIENT_ID_HERE';
```

### 3️⃣ استخدام الشاشة الجديدة

في `lib/screens/video_editor_screen.dart`:
```dart
import 'screens/music_picker_screen_with_soundcloud.dart';

// استبدل MusicPickerScreen بـ:
final selectedTrack = await Navigator.push<MusicTrack>(
  context,
  MaterialPageRoute(
    builder: (context) => const MusicPickerScreenWithSoundCloud(),
  ),
);
```

---

## 🔧 **الوظائف المتاحة**

### البحث عن تراكات
```dart
final soundCloud = SoundCloudService();

// بحث بالكلمة المفتاحية
final tracks = await soundCloud.searchTracks('summer vibes', limit: 20);

// عرض النتائج
for (var track in tracks) {
  print('${track.title} by ${track.artist}');
}
```

### الحصول على التراكات الشائعة
```dart
// كل الأنواع
final trending = await soundCloud.getTrendingTracks();

// نوع محدد
final jazzTrending = await soundCloud.getTrendingTracks(genre: 'jazzblues');
```

### الحصول على معلومات تراك
```dart
final track = await soundCloud.getTrack(123456789);

if (track != null) {
  print('Title: ${track.title}');
  print('Artist: ${track.artist}');
  print('Duration: ${track.formattedDuration}');
}
```

### الحصول على رابط البث
```dart
final streamUrl = await soundCloud.getStreamUrl(123456789);

if (streamUrl != null) {
  await audioPlayer.setUrl(streamUrl);
  await audioPlayer.play();
}
```

---

## 🎨 **الأنواع الموسيقية المتاحة**

```dart
SoundCloudService.genres = [
  'all-music',           // الكل
  'alternativerock',     // روك بديل
  'ambient',             // أمبينت
  'classical',           // كلاسيكي
  'country',             // كانتري
  'danceedm',            // رقص EDM
  'deephouse',           // Deep House
  'dubstep',             // Dubstep
  'electronic',          // إلكتروني
  'hiphoprap',           // هيب هوب/راب
  'house',               // House
  'indie',               // إندي
  'jazzblues',           // جاز/بلوز
  'metal',               // ميتال
  'pop',                 // بوب
  'rbsoul',              // R&B/Soul
  'reggae',              // ريغي
  'rock',                // روك
  'techno',              // تكنو
  'trance',              // ترانس
  'trap',                // Trap
  ...
];
```

---

## 🎬 **واجهة المستخدم**

### مميزات MusicPickerScreenWithSoundCloud

#### 1. تبديل المصدر
```
- مكتبة محلية (Local Library)
- SoundCloud
```

#### 2. مؤشر المصدر
```
🟣 Purple   → مكتبة محلية
🟠 Orange   → SoundCloud
```

#### 3. البحث
```
- بحث محلي: بالعنوان أو الفنان
- بحث SoundCloud: في كل المنصة
```

#### 4. التصفية
```
- متاحة فقط للمكتبة المحلية
- SoundCloud: البحث المباشر بدلاً من التصفية
```

---

## 📊 **هيكل البيانات**

### MusicTrack من SoundCloud
```dart
MusicTrack {
  id: "123456789",
  title: "Amazing Song",
  artist: "Cool Artist",
  genre: "electronic",
  duration: Duration(minutes: 3, seconds: 45),
  audioUrl: "https://api.soundcloud.com/tracks/.../stream",
  coverArtUrl: "https://i1.sndcdn.com/.../t500x500.jpg",
  waveformUrl: "https://wave.sndcdn.com/.../waveform.json",
}
```

### استجابة API
```json
{
  "collection": [
    {
      "id": 123456789,
      "title": "Amazing Song",
      "user": {
        "username": "Cool Artist"
      },
      "genre": "Electronic",
      "duration": 225000,
      "stream_url": "...",
      "artwork_url": "...",
      "waveform_url": "..."
    }
  ]
}
```

---

## 🔐 **الأمان وأفضل الممارسات**

### 1. إخفاء Client ID
```dart
// ❌ لا تضع Client ID مباشرة في الكود
static const String _clientId = 'abc123...';

// ✅ استخدم Environment Variables
static String get _clientId => 
  const String.fromEnvironment('SOUNDCLOUD_CLIENT_ID');

// أو استخدم .env file
import 'package:flutter_dotenv/flutter_dotenv.dart';
static String get _clientId => dotenv.env['SOUNDCLOUD_CLIENT_ID']!;
```

### 2. معالجة الأخطاء
```dart
try {
  final tracks = await soundCloud.searchTracks(query);
  // استخدم التراكات
} on HttpException {
  // خطأ في الاتصال
  showError('فشل الاتصال بـ SoundCloud');
} on FormatException {
  // خطأ في تحليل JSON
  showError('خطأ في البيانات');
} catch (e) {
  // أخطاء أخرى
  showError('حدث خطأ: $e');
}
```

### 3. حد الطلبات (Rate Limiting)
```dart
class SoundCloudService {
  static DateTime? _lastRequestTime;
  static const _minRequestInterval = Duration(milliseconds: 500);
  
  Future<void> _waitIfNeeded() async {
    if (_lastRequestTime != null) {
      final elapsed = DateTime.now().difference(_lastRequestTime!);
      if (elapsed < _minRequestInterval) {
        await Future.delayed(_minRequestInterval - elapsed);
      }
    }
    _lastRequestTime = DateTime.now();
  }
}
```

### 4. التخزين المؤقت
```dart
// تخزين النتائج لتقليل الطلبات
Map<String, List<MusicTrack>> _searchCache = {};

Future<List<MusicTrack>> searchTracks(String query) async {
  if (_searchCache.containsKey(query)) {
    return _searchCache[query]!;
  }
  
  final tracks = await _performSearch(query);
  _searchCache[query] = tracks;
  return tracks;
}
```

---

## 🐛 **استكشاف الأخطاء**

### المشكلة: Client ID لا يعمل
```
الحل:
1. تأكد أن Client ID صحيح
2. جرب استخراج Client ID جديد
3. تحقق من اتصال الإنترنت
4. جرب تأخير بين الطلبات
```

### المشكلة: لا يتم تشغيل الموسيقى
```
الحل:
1. تحقق من stream_url في الاستجابة
2. بعض التراكات محمية
3. استخدم preview_url إن وُجد
4. تأكد من أذونات الصوت في التطبيق
```

### المشكلة: خطأ 401 Unauthorized
```
الحل:
Client ID منتهي الصلاحية أو محظور
- احصل على Client ID جديد
```

### المشكلة: خطأ 429 Too Many Requests
```
الحل:
تجاوزت حد الطلبات
- أضف تأخير بين الطلبات
- استخدم التخزين المؤقت
- قلل عدد الطلبات
```

---

## 📈 **الأداء والتحسين**

### 1. تحميل مسبق للصور
```dart
// تحميل الصورة مسبقاً
Future<void> preloadImages(List<MusicTrack> tracks) async {
  for (var track in tracks) {
    precacheImage(
      CachedNetworkImageProvider(track.coverArtUrl),
      context,
    );
  }
}
```

### 2. Pagination للنتائج
```dart
Future<List<MusicTrack>> searchTracks(
  String query, {
  int offset = 0,
  int limit = 20,
}) async {
  final url = '$_baseUrl/search/tracks?q=$query'
      '&client_id=$_clientId'
      '&offset=$offset'
      '&limit=$limit';
  // ...
}
```

### 3. إلغاء الطلبات
```dart
// استخدم CancelToken من dio
final cancelToken = CancelToken();

try {
  final response = await dio.get(url, cancelToken: cancelToken);
} catch (e) {
  if (CancelToken.isCancel(e)) {
    print('تم إلغاء الطلب');
  }
}

// عند الخروج
@override
void dispose() {
  cancelToken.cancel();
  super.dispose();
}
```

---

## 🔄 **البدائل الموصى بها**

### 1. Spotify API (رسمي ومجاني)
```
✅ API رسمي ومستقر
✅ توثيق شامل
✅ مجاني للاستخدام الشخصي
✅ مكتبة ضخمة
❌ يتطلب تسجيل التطبيق
```

### 2. Free Music Archive
```
✅ موسيقى مجانية ومرخصة
✅ API بسيط
✅ بدون قيود
❌ مكتبة أصغر
```

### 3. Jamendo
```
✅ موسيقى مرخصة Creative Commons
✅ API رسمي
✅ مجاني للاستخدام غير التجاري
❌ يتطلب تسجيل
```

### 4. ccMixter
```
✅ موسيقى Creative Commons
✅ مجاني تماماً
❌ لا يوجد API رسمي
```

---

## 📚 **موارد إضافية**

### التوثيق
- [SoundCloud API (أرشيف)](https://developers.soundcloud.com/docs/api/guide)
- [Unofficial Documentation](https://github.com/soundcloud/api)

### أدوات
- [SoundCloud Downloader](https://github.com/flyingrub/scdl)
- [Client ID Extractor](https://github.com/zackradisic/soundcloud-dl)

### مشاريع مرجعية
```bash
# ابحث في GitHub
"soundcloud api flutter" site:github.com
"soundcloud client_id dart" site:github.com
```

---

## 📝 **الملخص**

### ✅ مميزات الحل
- دعم SoundCloud + مكتبة محلية
- تبديل سلس بين المصادر
- واجهة موحدة
- بحث وتشغيل

### ⚠️ القيود
- Client ID غير رسمي
- قد يتوقف في أي وقت
- محدود بشروط الخدمة
- جودة محدودة

### 🎯 التوصية
للإنتاج، استخدم:
1. **Spotify API** (الأفضل)
2. **Free Music Archive** (مجاني تماماً)
3. **مكتبة محلية مرخصة**

SoundCloud للاختبار فقط! ⚠️

---

**تم إنشاؤه لـ Zoli Chat 🎵**
