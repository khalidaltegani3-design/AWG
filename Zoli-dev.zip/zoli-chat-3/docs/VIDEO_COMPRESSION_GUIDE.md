# 🎥 دليل الضغط ورفع الفيديوهات (Blinks)

## نظرة عامة
تم دمج خوارزمية الضغط الموجودة (70% تقليل الحجم) مع عملية رفع الفيديوهات في Blinks.

## البنية المتكاملة

### 1. خوارزمية الضغط (video_processing_service.dart)
```dart
VideoProcessingService()
  ├─ compressVideo()           // الضغط الأساسي
  │  ├─ light_compressor        // المحرك (70% تقليل)
  │  ├─ VideoQuality presets    // 720p/1080p/1440p
  │  └─ Auto-quality selection  // حسب الحجم
  │
  └─ CompressResult             // النتيجة
     ├─ success                 // نجح/فشل
     ├─ outputPath              // مسار الملف المضغوط
     ├─ originalSize            // الحجم الأصلي
     ├─ compressedSize          // الحجم بعد الضغط
     └─ compressionRatio        // نسبة التقليل %
```

### 2. خدمة الرفع المدمجة (storage_service.dart)
```dart
StorageService()
  └─ uploadBlinkVideo()         // رفع مع ضغط تلقائي
     ├─ المرحلة 1: الضغط (0%-50%)
     │  ├─ استدعاء compressVideo()
     │  ├─ تقليل 70% من الحجم
     │  └─ إنشاء ملف مؤقت
     │
     ├─ المرحلة 2: الرفع (50%-100%)
     │  ├─ رفع الملف المضغوط
     │  ├─ إضافة metadata (الحجم الأصلي/المضغوط)
     │  └─ تتبع التقدم
     │
     └─ التنظيف
        └─ حذف الملف المضغوط المؤقت
```

---

## 🚀 الاستخدام

### مثال 1: رفع Blink مع الضغط التلقائي
```dart
import 'package:zoli/services/storage_service.dart';
import 'package:firebase_auth/firebase_auth.dart';

final storageService = StorageService();
final uid = FirebaseAuth.instance.currentUser!.uid;
final blinkId = 'unique-blink-id';

// رفع مع ضغط تلقائي (افتراضي)
final gsUrl = await storageService.uploadBlinkVideo(
  file: File('/path/to/video.mp4'),
  uid: uid,
  blinkId: blinkId,
  onProgress: (progress) {
    if (progress <= 0.5) {
      print('Compressing: ${(progress * 200).toInt()}%');
    } else {
      print('Uploading: ${((progress - 0.5) * 200).toInt()}%');
    }
  },
);

print('Video uploaded: $gsUrl');
```

### مثال 2: رفع بدون ضغط (اختياري)
```dart
// في حالات خاصة (مثلاً الفيديو مضغوط مسبقاً)
final gsUrl = await storageService.uploadBlinkVideo(
  file: File('/path/to/video.mp4'),
  uid: uid,
  blinkId: blinkId,
  compress: false,  // تعطيل الضغط
  onProgress: (progress) {
    print('Uploading: ${(progress * 100).toInt()}%');
  },
);
```

### مثال 3: مثال كامل مع Blink Service
```dart
import 'package:zoli/models/blink_model.dart';
import 'package:zoli/services/blink_service.dart';
import 'package:zoli/services/storage_service.dart';

Future<void> createAndUploadBlink(File videoFile) async {
  final uid = FirebaseAuth.instance.currentUser!.uid;
  final blinkId = DateTime.now().millisecondsSinceEpoch.toString();
  
  double uploadProgress = 0.0;
  
  try {
    // 1. رفع الفيديو مع الضغط (70% تقليل)
    print('Starting upload with compression...');
    final videoUrl = await StorageService().uploadBlinkVideo(
      file: videoFile,
      uid: uid,
      blinkId: blinkId,
      onProgress: (progress) {
        uploadProgress = progress;
        if (progress <= 0.5) {
          print('⚙️ Compressing: ${(progress * 200).toInt()}%');
        } else {
          print('☁️ Uploading: ${((progress - 0.5) * 200).toInt()}%');
        }
      },
    );
    
    // 2. إنشاء Blink في Firestore
    final blink = BlinkModel(
      id: blinkId,
      uid: uid,
      videoUrl: videoUrl,
      description: 'My new blink!',
      hashtags: ['trending', 'viral'],
      createdAt: DateTime.now(),
    );
    
    await BlinkService().createBlink(blink);
    print('✅ Blink created successfully!');
    
  } catch (e) {
    print('❌ Error: $e');
  }
}
```

---

## 📊 معلومات الضغط في Metadata

بعد الرفع، يتم حفظ معلومات الضغط في Firebase Storage metadata:

```dart
// الحصول على معلومات الضغط
final metadata = await storageService.getMetadata(gsUrl);
print('Compressed: ${metadata.customMetadata?['compressed']}');
print('Original Size: ${metadata.customMetadata?['originalSizeMB']} MB');
print('Compressed Size: ${metadata.customMetadata?['compressedSizeMB']} MB');
print('Compression Ratio: ${metadata.customMetadata?['compressionRatio']}%');
```

مثال output:
```
Compressed: true
Original Size: 45.23 MB
Compressed Size: 13.57 MB
Compression Ratio: 70.0%
```

---

## ⚙️ إعدادات الضغط

### جودة الضغط التلقائية
يختار النظام الجودة تلقائياً حسب حجم الملف:

| حجم الملف | الجودة المستخدمة |
|-----------|------------------|
| > 200 MB  | `VideoQuality.low` (ضغط عالي) |
| > 140 MB  | `VideoQuality.medium` (ضغط متوسط) |
| < 140 MB  | الجودة المطلوبة (افتراضي medium) |

### الحد الأقصى للحجم
- **قبل الضغط**: 200 MB (Storage Rules)
- **بعد الضغط**: ~60 MB (70% تقليل)

---

## 🔄 Pipeline الكامل

```
1. اختيار الفيديو من المستخدم
   ↓
2. بدء رفع Blink
   ↓
3. الضغط التلقائي (0%-50%)
   ├─ قراءة الملف الأصلي
   ├─ تطبيق light_compressor
   ├─ تقليل 70% من الحجم
   └─ حفظ في مجلد مؤقت
   ↓
4. الرفع إلى Storage (50%-100%)
   ├─ رفع الملف المضغوط
   ├─ المسار: uploads/{uid}/{blinkId}.mp4
   └─ إضافة metadata
   ↓
5. حذف الملف المضغوط المؤقت
   ↓
6. حفظ Blink في Firestore
   ├─ Collection: reels
   ├─ videoUrl: gs://bucket/uploads/...
   └─ معلومات أخرى (description, hashtags, etc.)
   ↓
7. ظهور Blink للجميع ✅
```

---

## 🐛 معالجة الأخطاء

### سيناريو 1: فشل الضغط
```dart
// في حالة فشل الضغط، يتم رفع الملف الأصلي تلقائياً
try {
  final gsUrl = await storageService.uploadBlinkVideo(...);
  // نجح الرفع (مع أو بدون ضغط)
} catch (e) {
  // فشل الرفع نهائياً
  print('Upload failed completely: $e');
}
```

### سيناريو 2: فحص نجاح الضغط
```dart
// من خلال metadata
final metadata = await storageService.getMetadata(gsUrl);
if (metadata.customMetadata?['compressed'] == 'true') {
  print('Video was compressed successfully');
} else {
  print('Original video was uploaded (compression failed/disabled)');
}
```

---

## 📱 تكامل مع UI

### Progress Bar مع مرحلتين
```dart
class UploadProgressWidget extends StatefulWidget {
  @override
  State<UploadProgressWidget> createState() => _UploadProgressWidgetState();
}

class _UploadProgressWidgetState extends State<UploadProgressWidget> {
  double _progress = 0.0;
  String _status = 'Preparing...';

  Future<void> _uploadVideo(File file) async {
    setState(() => _status = 'Starting...');
    
    final gsUrl = await StorageService().uploadBlinkVideo(
      file: file,
      uid: FirebaseAuth.instance.currentUser!.uid,
      blinkId: DateTime.now().millisecondsSinceEpoch.toString(),
      onProgress: (progress) {
        setState(() {
          _progress = progress;
          if (progress <= 0.5) {
            _status = 'Compressing: ${(progress * 200).toInt()}%';
          } else {
            _status = 'Uploading: ${((progress - 0.5) * 200).toInt()}%';
          }
        });
      },
    );
    
    setState(() => _status = 'Done!');
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        LinearProgressIndicator(value: _progress),
        SizedBox(height: 8),
        Text(_status),
      ],
    );
  }
}
```

---

## ✅ الفوائد

1. **تقليل التكاليف**: 70% أقل storage وbandwidth
2. **سرعة الرفع**: ملفات أصغر = رفع أسرع
3. **تجربة أفضل**: تحميل أسرع للمستخدمين
4. **شفافية**: metadata كامل عن الضغط
5. **مرونة**: يمكن تعطيل الضغط عند الحاجة
6. **موثوقية**: fallback للملف الأصلي عند فشل الضغط

---

## 🔗 الملفات ذات الصلة

- `lib/services/video_processing_service.dart` - خوارزمية الضغط (70%)
- `lib/services/storage_service.dart` - رفع مع ضغط مدمج
- `lib/services/blink_service.dart` - إدارة Blinks
- `lib/models/blink_model.dart` - نموذج البيانات
- `storage.rules` - قواعد الأمان

---

## 📈 إحصائيات متوقعة

### مثال واقعي:
- **فيديو 1080p مدة 30 ثانية**
  - قبل: ~45 MB
  - بعد: ~13.5 MB
  - توفير: 70%
  - وقت الضغط: ~10 ثوان
  - وقت الرفع: ~5 ثوان (بدلاً من ~15)
  - **إجمالي الوقت**: 15 ثانية (بدلاً من 15 للرفع فقط)

---

## 🎯 الخلاصة

تم دمج خوارزمية الضغط الموجودة (70% تقليل) بنجاح مع خدمة رفع Blinks. الآن:
- ✅ كل فيديو يتم ضغطه تلقائياً قبل الرفع
- ✅ تتبع دقيق للتقدم (ضغط + رفع)
- ✅ معلومات كاملة في metadata
- ✅ معالجة ذكية للأخطاء
- ✅ لا حاجة لخدمة ضغط منفصلة
