# نظام ضغط ورفع الفيديو - دليل الإعداد

## 📋 نظرة عامة

تم تطبيق نظام متقدم لضغط ورفع الفيديوهات في تطبيق Zoli Chat مع المميزات التالية:

### ✨ المميزات الرئيسية

- **ضغط محلي**: ضغط الفيديو على جهاز المستخدم قبل الرفع باستخدام FFmpeg
- **ضغط سحابي**: معالجة متقدمة على السيرفر لإنشاء 3 جودات (360p, 480p, 720p)
- **تشغيل تكيفي**: اختيار تلقائي للجودة حسب سرعة الإنترنت (WiFi/Mobile)
- **توفير التخزين**: تقليل استهلاك المساحة بنسبة 70-80%
- **تحسينات الفيديو**: تطبيق فلاتر لتحسين الوضوح والألوان وإزالة الضوضاء

## 📁 الملفات المضافة

### Flutter (التطبيق)

1. **lib/services/video_upload_service.dart**
   - خدمة رفع وضغط الفيديو
   - ضغط محلي باستخدام FFmpeg
   - مراقبة حالة الرفع والمعالجة

2. **lib/widgets/adaptive_video_player.dart**
   - مشغل فيديو ذكي
   - اختيار تلقائي للجودة
   - عرض الجودة الحالية

3. **lib/screens/upload_video_screen.dart**
   - واجهة رفع الفيديو
   - شريط تقدم الرفع
   - معاينة الفيديو المرفوع

### Firebase Functions

1. **functions/package.json**
   - تبعيات Node.js
   - FFmpeg للمعالجة السحابية

2. **functions/index.js**
   - معالجة الفيديو السحابية
   - إنشاء جودات متعددة
   - تطبيق فلاتر التحسين

3. **storage.rules**
   - قواعد أمان Firebase Storage

## 🔧 خطوات الإعداد

### 1. تثبيت المكتبات (تم ✅)

```bash
flutter pub get
```

### 2. إعداد Firebase Functions

```bash
cd functions
npm install
```

### 3. نشر Firebase Functions

```bash
# تسجيل الدخول
firebase login

# تهيئة المشروع (إذا لم يتم من قبل)
firebase init

# نشر القواعد والوظائف
firebase deploy --only storage:rules
firebase deploy --only functions
```

### 4. إعداد Firebase Storage

قواعد الأمان موجودة في `storage.rules` - يجب نشرها:

```bash
firebase deploy --only storage:rules
```

## 🎯 كيفية الاستخدام

### في كود التطبيق

```dart
import 'package:zoli_chat/screens/upload_video_screen.dart';

// للانتقال لشاشة رفع الفيديو
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => const UploadVideoScreen(),
  ),
);
```

### للتشغيل

```dart
import 'package:zoli_chat/widgets/adaptive_video_player.dart';

// لتشغيل فيديو
AdaptiveVideoPlayer(videoId: 'video_id_here')
```

## 🎨 فلاتر تحسين الفيديو

النظام يطبق الفلاتر التالية:

1. **unsharp**: تحسين الوضوح
2. **eq**: تحسين التباين والتشبع (+10% تباين، +20% تشبع)
3. **hqdn3d**: إزالة الضوضاء
4. **scale**: تغيير الحجم للجودات المختلفة

## 📊 الجودات المتوفرة

| الجودة | الارتفاع | CRF | الاستخدام |
|--------|---------|-----|-----------|
| 360p   | 360px   | 30  | بيانات محدودة |
| 480p   | 480px   | 28  | بيانات موبايل |
| 720p   | 720px   | 26  | WiFi |

## 💰 توفير التكاليف

- **التخزين**: توفير 70-80% من المساحة
- **Cloud Functions**: مجاني حتى 2 مليون استدعاء شهرياً
- **Firebase Storage**: مجاني حتى 5GB

## 🔐 الأمان

- المستخدمون يمكنهم رفع الفيديوهات فقط إلى مجلداتهم
- القراءة متاحة للجميع (يمكن تعديلها حسب الحاجة)
- حذف تلقائي للملف الأصلي بعد المعالجة

## 📝 ملاحظات مهمة

1. **FFmpeg على Web**: 
   - `ffmpeg_kit_flutter` لا يعمل على الويب
   - يجب اختبار الميزة على Android/iOS

2. **حد الفيديو**:
   - الحد الحالي: 60 ثانية
   - يمكن تعديله في `upload_video_screen.dart`

3. **الترجمة**:
   - تم إضافة الترجمة العربية للواجهة

## 🚀 الخطوات التالية

1. ✅ تم تثبيت المكتبات
2. ⏳ يجب نشر Firebase Functions
3. ⏳ يجب نشر قواعد Storage
4. ⏳ اختبار على جهاز Android/iOS حقيقي

## 🐛 استكشاف الأخطاء

### خطأ "FFmpeg not found"
```bash
# تأكد من تثبيت المكتبة
flutter pub get
```

### خطأ في Functions
```bash
# تحقق من السجلات
firebase functions:log
```

### مشاكل التشغيل على Web
- النظام مصمم للموبايل
- استخدم جهاز Android/iOS للاختبار الكامل

## 📞 الدعم

للمساعدة أو الأسئلة، راجع:
- [توثيق FFmpeg Kit](https://github.com/arthenica/ffmpeg-kit)
- [توثيق Firebase Functions](https://firebase.google.com/docs/functions)
