# PowerShell Script to Install Flutter

# 1. Create Flutter directory in C:\
Write-Host "Creating C:\flutter directory..."
New-Item -ItemType Directory -Force -Path "C:\flutter"

# 2. Download Flutter SDK
Write-Host "Downloading Flutter SDK... (This may take a few minutes)"
$flutterZipPath = "$env:TEMP\flutter.zip"
Invoke-WebRequest -Uri "https://storage.googleapis.com/flutter_infra_release/releases/stable/windows/flutter_windows_3.24.4-stable.zip" -OutFile $flutterZipPath

# 3. Unzip Flutter SDK
Write-Host "Extracting Flutter SDK..."
Expand-Archive -Path $flutterZipPath -DestinationPath "C:\" -Force

# 4. Add Flutter to the user's PATH environment variable
Write-Host "Adding Flutter to your PATH..."
$currentPath = [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::User)
$flutterPath = "C:\flutter\bin"
if (-not ($currentPath -like "*$flutterPath*")) {
    $newPath = $currentPath + ";" + $flutterPath
    [Environment]::SetEnvironmentVariable("Path", $newPath, [EnvironmentVariableTarget]::User)
    Write-Host "Flutter has been added to your PATH. Please restart VS Code."
} else {
    Write-Host "Flutter is already in your PATH."
}

# 5. Clean up the downloaded zip file
Remove-Item -Path $flutterZipPath -Force

Write-Host "Flutter installation script finished."
Write-Host "IMPORTANT: Please close and reopen Visual Studio Code to apply the changes."
