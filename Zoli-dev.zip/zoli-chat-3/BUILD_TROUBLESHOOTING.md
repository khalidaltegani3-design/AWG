# 🔧 حل مشاكل البناء - Zoli Chat

> **التاريخ**: 4 أكتوبر 2025  
> **الهدف**: حلول سريعة لأخطاء البناء الشائعة

---

## ❌ المشكلة: Build Failed - File Being Used

### الخطأ:
```
java.nio.file.FileSystemException: The process cannot access 
the file because it is being used by another process
```

### السبب:
- عمليات Java/Gradle ما زالت تعمل في الخلفية
- ملفات مقفلة في مجلد `build`

### ✅ الحل:

```powershell
# 1. إيقاف جميع عمليات Java
taskkill /F /IM java.exe 2>$null
taskkill /F /IM javaw.exe 2>$null

# 2. حذف مجلد build
Remove-Item -Path ".\build" -Recurse -Force

# 3. إعادة البناء
flutter build apk --release
```

---

## ❌ المشكلة: Namespace Not Specified

### الخطأ:
```
Namespace not specified. Specify a namespace in the module's build file
```

### السبب:
- حزمة قديمة لا تدعم Android Gradle 8+

### ✅ الحل:
احذف الحزمة من `pubspec.yaml`:
```yaml
# light_compressor: ^2.1.0  # ← احذف هذا السطر
```

ثم:
```bash
flutter pub get
flutter clean
flutter build apk --release
```

---

## ❌ المشكلة: video_editor API Breaking Changes

### الخطأ:
```
Type 'ExportSettings' not found
The getter 'crop' isn't defined
```

### السبب:
- `video_editor: ^3.0.0` غيّر الـ API بشكل كامل

### ✅ الحل:
استخدم النظام الجديد (Native APIs):
```yaml
dependencies:
  video_player: ^2.9.0
  video_thumbnail: ^0.5.3
  # video_editor: ^3.0.0  # ← احذف
```

---

## ❌ المشكلة: FFmpeg NDK Errors

### الخطأ:
```
No version of NDK matched the requested version
ffmpeg not found
```

### السبب:
- `ffmpeg_kit_flutter` يحتاج NDK معين
- حجم كبير (+50 MB)

### ✅ الحل:
استخدم Native Platform Channels بدلاً من FFmpeg:
```dart
// بدلاً من FFmpeg
await NativeShorts.trim(input, output, startMs, endMs);
```

---

## 🛠️ أوامر تنظيف شاملة

### تنظيف كامل للمشروع:

```powershell
# إيقاف العمليات
taskkill /F /IM dart.exe 2>$null
taskkill /F /IM java.exe 2>$null
taskkill /F /IM adb.exe 2>$null

# حذف الملفات المؤقتة
Remove-Item .\pubspec.lock -ErrorAction Ignore
Remove-Item .\build -Recurse -Force -ErrorAction Ignore
Remove-Item .\.dart_tool -Recurse -Force -ErrorAction Ignore

# تنظيف Flutter
flutter clean

# تثبيت الحزم
flutter pub get

# البناء
flutter build apk --release
```

---

## 📊 تحقق من الحالة

### تأكد من أن كل شيء جاهز:

```bash
# 1. تحقق من Flutter
flutter doctor

# 2. تحقق من الأجهزة المتصلة
flutter devices

# 3. تحقق من الحزم
flutter pub outdated

# 4. اختبار سريع
flutter run -d windows
```

---

## 🎯 النصائح الذهبية

1. **استخدم `flutter clean` دائماً** عند تغيير dependencies
2. **أغلق Android Studio/VS Code** أثناء البناء لتجنب قفل الملفات
3. **لا تستخدم حزم قديمة** مع Android Gradle 8+
4. **اختبر على المحاكي أولاً** قبل الجهاز الحقيقي
5. **راجع `pubspec.yaml`** بعد كل تغيير

---

## ✅ البناء الناجح

عندما ينجح البناء، ستجد:

```
✅ build/app/outputs/flutter-apk/app-release.apk

حجم: ~50-60 MB (بدون FFmpeg)
الوقت: 2-3 دقائق
```

---

**🎉 النجاح قريب! استمر في المحاولة!**
