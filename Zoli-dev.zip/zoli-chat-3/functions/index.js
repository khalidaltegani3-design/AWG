const functions = require('firebase-functions');
const admin = require('firebase-admin');
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const ffmpeg = require('fluent-ffmpeg');
const tmp = require('tmp');
const fs = require('fs');
const path = require('path');

ffmpeg.setFfmpegPath(ffmpegPath);
admin.initializeApp();

const storage = admin.storage();
const firestore = admin.firestore();

exports.processVideo = functions
  .runWith({
    timeoutSeconds: 540,
    memory: '2GB',
  })
  .storage.object()
  .onFinalize(async (object) => {
    const filePath = object.name;
    
    if (!filePath.includes('original.mp4')) {
      return null;
    }

    const pathParts = filePath.split('/');
    const userId = pathParts[1];
    const videoId = pathParts[2];

    try {
      await firestore.collection('videos').doc(videoId).update({
        status: 'processing',
      });

      const bucket = storage.bucket();
      const tempInputPath = tmp.tmpNameSync({ postfix: '.mp4' });
      await bucket.file(filePath).download({ destination: tempInputPath });

      const qualities = [
        { name: '360p', height: 360, crf: 30 },
        { name: '480p', height: 480, crf: 28 },
        { name: '720p', height: 720, crf: 26 },
      ];

      const processedUrls = {};

      for (const quality of qualities) {
        const outputUrl = await processVideoQuality(
          tempInputPath,
          userId,
          videoId,
          quality
        );
        processedUrls[quality.name] = outputUrl;
      }

      await firestore.collection('videos').doc(videoId).update({
        status: 'ready',
        qualities: processedUrls,
        processedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      await bucket.file(filePath).delete();
      fs.unlinkSync(tempInputPath);

      return null;
    } catch (error) {
      console.error('Error:', error);
      
      await firestore.collection('videos').doc(videoId).update({
        status: 'error',
        error: error.message,
      });

      return null;
    }
  });

async function processVideoQuality(inputPath, userId, videoId, quality) {
  return new Promise((resolve, reject) => {
    const tempOutputPath = tmp.tmpNameSync({ postfix: '.mp4' });
    const outputPath = 'videos/' + userId + '/' + videoId + '/' + quality.name + '.mp4';

    ffmpeg(inputPath)
      .videoFilters([
        'scale=-2:' + quality.height,
        'unsharp=5:5:1.0:5:5:0.5',
        'eq=contrast=1.1:saturation=1.2',
        'hqdn3d=4:3:6:4.5',
      ])
      .videoCodec('libx264')
      .outputOptions([
        '-crf ' + quality.crf,
        '-preset medium',
        '-movflags +faststart',
      ])
      .audioCodec('aac')
      .audioBitrate('96k')
      .output(tempOutputPath)
      .on('end', async () => {
        try {
          const bucket = storage.bucket();
          await bucket.upload(tempOutputPath, {
            destination: outputPath,
            metadata: {
              contentType: 'video/mp4',
            },
          });

          const file = bucket.file(outputPath);
          const signedUrls = await file.getSignedUrl({
            action: 'read',
            expires: '03-01-2500',
          });

          fs.unlinkSync(tempOutputPath);
          resolve(signedUrls[0]);
        } catch (error) {
          reject(error);
        }
      })
      .on('error', (error) => {
        reject(error);
      })
      .run();
  });
}
