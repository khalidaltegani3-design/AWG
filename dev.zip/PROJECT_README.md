# 📱 مشروع Zoli Chat

> تطبيق دردشة وفيديوهات قصيرة (Ramshat) مع تكامل كامل مع Firebase

[![Flutter](https://img.shields.io/badge/Flutter-3.22+-blue.svg)](https://flutter.dev/)
[![Dart](https://img.shields.io/badge/Dart-3.0+-blue.svg)](https://dart.dev/)
[![Firebase](https://img.shields.io/badge/Firebase-Enabled-orange.svg)](https://firebase.google.com/)

---

## 📋 المحتويات

- [نظرة عامة](#نظرة-عامة)
- [المميزات](#المميزات)
- [البنية التقنية](#البنية-التقنية)
- [البدء السريع](#البدء-السريع)
- [Firebase Services](#firebase-services)
- [Remote Config](#remote-config)
- [FCM Topics](#fcm-topics)
- [التوثيق](#التوثيق)
- [المساهمة](#المساهمة)

---

## 🎯 نظرة عامة

**Zoli** هو تطبيق شامل يجمع بين:
- 💬 **دردشة فورية** مع دعم الرسائل النصية والصوتية
- 🎥 **Ramshat** (فيديوهات قصيرة) مشابهة لـ TikTok/Instagram Reels
- 🎵 **مكتبة موسيقى** مع تكامل Spotify
- 📞 **مكالمات صوتية ومرئية**
- 📝 **حالات** (Stories)

---

## ✨ المميزات

### 1. نظام الرمشات (Ramshat)
- ✅ تسجيل ورفع فيديوهات قصيرة
- ✅ ضغط الفيديو تلقائياً (720p، 2.5 Mbps)
- ✅ معالجة على الخادم (Cloud Functions)
- ✅ Feed عام مع pagination
- ✅ إعجابات ومشاهدات
- ✅ حالات: Draft → Processing → Published
- ✅ Storage منضبط: `ramshat/{uid}/{ramshaId}/`

### 2. الدردشة
- ✅ رسائل نصية فورية
- ✅ رسائل صوتية
- ✅ مشاركة الصور والملفات
- ✅ حالة الاتصال (Online/Offline)
- ✅ تشفير وأمان

### 3. الموسيقى
- ✅ مكتبة محلية (10 tracks)
- ✅ تكامل Spotify (100M+ tracks)
- ✅ معاينة 30 ثانية
- ✅ بحث وتصنيف حسب النوع

### 4. الإشعارات (FCM)
- ✅ Push notifications
- ✅ Topics (ramshat-new, trending, etc.)
- ✅ Deep linking
- ✅ قنوات متعددة (high/default/low)

### 5. الأمان والمراقبة
- ✅ Firebase App Check (Play Integrity / DeviceCheck)
- ✅ Crashlytics (تتبع الأخطاء)
- ✅ Performance Monitoring
- ✅ Remote Config (إدارة الميزات)
- ✅ Security Rules محكمة

---

## 🏗️ البنية التقنية

### Frontend
```
Flutter 3.22+
Dart 3.0+
```

### State Management
```
Provider
```

### Backend & Database
```
Firebase:
  - Authentication (Phone)
  - Firestore (Database)
  - Storage (Files)
  - Cloud Functions (Backend logic)
  - Messaging (Push notifications)
  - Crashlytics (Error tracking)
  - Performance (Monitoring)
  - Remote Config (Feature flags)
  - App Check (Security)
```

### Media
```
- camerawesome: Video recording
- video_editor: Video editing
- video_compress: Video compression
- just_audio: Audio playback
- spotify: Music integration
```

---

## 🚀 البدء السريع

### المتطلبات

- Flutter 3.22+
- Dart 3.0+
- Android Studio / Xcode
- Firebase Account
- Node.js 18+ (للـ Functions)

### التثبيت

```bash
# 1. Clone المشروع
git clone https://github.com/your-org/zoli-chat.git
cd zoli-chat

# 2. تثبيت Dependencies
flutter pub get

# 3. تهيئة Firebase (استخدم المشروع الموجود)
dart pub global activate flutterfire_cli
flutterfire configure --project=<YOUR_PROJECT_ID> --platforms=android,ios,web

# 4. تشغيل التطبيق
flutter run
```

### الإعداد الكامل

راجع **[FIREBASE_SETUP.md](FIREBASE_SETUP.md)** للتفاصيل الكاملة.

---

## 🔥 Firebase Services

### 1. Firestore Collections

```
users/
  {uid}/
    - displayName, phoneNumber, photoURL, etc.
    tokens/
      {token}/ - FCM tokens

ramshat/
  {ramshaId}/
    - uid, title, videoUrl, thumbUrl, status, visibility
    - likes, views, createdAt, etc.

chats/
  {chatId}/
    - participants[], lastMessage, updatedAt
    messages/
      {messageId}/
        - senderId, text, timestamp, type

stories/
  {storyId}/
    - uid, imageUrl, createdAt, expiresAt
```

### 2. Storage Structure

```
ramshat/
  {uid}/
    {ramshaId}/
      source.mp4        # الفيديو الأصلي
      thumb.jpg         # الصورة المصغرة

users/
  {uid}/
    profile.jpg         # صورة الملف الشخصي

stories/
  {uid}/
    {storyId}.jpg       # صورة الحالة
```

### 3. Security Rules

#### Firestore
- ✅ Users: القراءة للجميع، الكتابة للمالك فقط
- ✅ Ramshat: القراءة للجميع (public+published)، الكتابة للمالك
- ✅ Chats: القراءة والكتابة للمشاركين فقط

#### Storage
- ✅ Ramshat: القراءة للجميع، الكتابة للمالك (حد أقصى 100MB)
- ✅ Profiles: القراءة للجميع، الكتابة للمالك (حد أقصى 5MB)

---

## ⚙️ Remote Config

### مفاتيح متاحة

| المفتاح | النوع | القيمة الافتراضية | الوصف |
|---------|-------|-------------------|--------|
| `feed_page_size` | Int | `10` | عدد الرمشات في كل صفحة |
| `upload_max_duration_ms` | Int | `60000` | الحد الأقصى لمدة الفيديو (60s) |
| `upload_max_size_mb` | Int | `100` | الحد الأقصى لحجم الفيديو |
| `bitrate_target` | Int | `2500000` | معدل البت المستهدف (2.5 Mbps) |
| `video_quality` | String | `"720p"` | جودة الفيديو |
| `enable_compression` | Bool | `true` | تفعيل الضغط |
| `enable_notifications` | Bool | `true` | تفعيل الإشعارات |
| `min_app_version` | String | `"1.0.0"` | أقل إصدار مطلوب |
| `force_update` | Bool | `false` | فرض التحديث |
| `maintenance_mode` | Bool | `false` | وضع الصيانة |

### الاستخدام

```dart
import 'package:zoli_chat/services/remote_config_service.dart';

final config = RemoteConfigService();

// الحصول على القيم
int pageSize = config.feedPageSize;
bool shouldCompress = config.enableCompression;
String videoQuality = config.videoQuality;

// تحديث القيم
await config.fetchAndActivate();
```

---

## 📲 FCM Topics

### Topics المتاحة

| Topic | الوصف |
|-------|--------|
| `ramshat-new` | رمشات جديدة منشورة |
| `ramshat-trending` | رمشات رائجة |
| `system-announcements` | إعلانات النظام |
| `maintenance` | صيانة التطبيق |

### الاشتراك

```dart
import 'package:zoli_chat/services/fcm_service.dart';

final fcm = FCMService();

// الاشتراك
await fcm.subscribeToTopic('ramshat-new');

// إلغاء الاشتراك
await fcm.unsubscribeFromTopic('ramshat-new');
```

### أنواع الإشعارات

```dart
class NotificationType {
  static const ramshaPublished = 'ramsha_published';
  static const ramshaLiked = 'ramsha_liked';
  static const ramshaCommented = 'ramsha_commented';
  static const newFollower = 'new_follower';
  static const newMessage = 'new_message';
  static const systemAlert = 'system_alert';
}
```

---

## 📚 التوثيق

### ملفات التوثيق المتاحة

- **[FIREBASE_SETUP.md](FIREBASE_SETUP.md)** - دليل إعداد Firebase الشامل
- **[DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)** - دليل النشر للمتاجر
- **[SPOTIFY_SETUP_GUIDE.md](SPOTIFY_SETUP_GUIDE.md)** - دليل تكامل Spotify
- **[VIDEO_EDITOR_README.md](VIDEO_EDITOR_README.md)** - دليل محرر الفيديو
- **[VIDEO_COMPRESSION_GUIDE.md](VIDEO_COMPRESSION_GUIDE.md)** - دليل ضغط الفيديو

### معمارية المشروع

```
lib/
├── main.dart                 # نقطة البداية + تهيئة Firebase
├── firebase_options.dart     # تكوين Firebase (auto-generated)
├── models/                   # نماذج البيانات
│   ├── ramshat_model.dart
│   ├── user_model.dart
│   └── message_model.dart
├── services/                 # الخدمات
│   ├── auth_service.dart
│   ├── ramshat_service.dart
│   ├── storage_service.dart
│   ├── fcm_service.dart
│   └── remote_config_service.dart
├── screens/                  # الشاشات
│   ├── home_screen.dart
│   ├── login_screen.dart
│   ├── ramshat_feed_screen.dart
│   ├── upload_ramshat_screen.dart
│   └── ...
├── providers/                # State Management
│   ├── language_provider.dart
│   ├── theme_provider.dart
│   └── profile_provider.dart
└── themes.dart              # الثيمات
```

---

## 🔒 الأمان والخصوصية

### App Check
```dart
// تم تفعيله في main.dart
await FirebaseAppCheck.instance.activate(
  androidProvider: AndroidProvider.playIntegrity,
  appleProvider: AppleProvider.deviceCheck,
  webProvider: ReCaptchaV3Provider('key'),
);
```

### Security Rules
- جميع الاستعلامات محمية
- قراءة الرمشات: `visibility == 'public' && status == 'published'`
- الكتابة: المالك فقط
- Indexes محسّنة للأداء

---

## 📊 المراقبة والتحليل

### Crashlytics
```dart
// تسجيل الأخطاء تلقائياً
FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
```

### Performance Monitoring
```dart
// تتبع الأداء
final trace = FirebasePerformance.instance.newTrace('ramsha_upload');
await trace.start();
// ... عملية الرفع
await trace.stop();
```

### Analytics (اختياري)
يمكن إضافة Firebase Analytics لتتبع سلوك المستخدمين.

---

## 🛠️ تطوير التطبيق

### تشغيل التطبيق

```bash
# تشغيل على جهاز Android
flutter run -d android

# تشغيل على جهاز iOS
flutter run -d ios

# تشغيل على Web
flutter run -d chrome
```

### البناء للإنتاج

```bash
# Android AAB
flutter build appbundle --release

# Android APK
flutter build apk --release

# iOS
flutter build ios --release
```

### الاختبار

```bash
# تشغيل الاختبارات
flutter test

# تحليل الكود
flutter analyze

# تنسيق الكود
dart format .
```

---

## 🌍 التعريب (Localization)

التطبيق يدعم:
- ✅ العربية (ar)
- ✅ الإنجليزية (en)

ملفات الترجمة:
```
lib/l10n/
  app_ar.arb
  app_en.arb
```

---

## 📦 Dependencies الرئيسية

```yaml
# Firebase
firebase_core
firebase_auth
cloud_firestore
firebase_storage
firebase_messaging
firebase_crashlytics
firebase_performance
firebase_remote_config
firebase_app_check

# Media
camerawesome
video_editor
video_compress
just_audio
spotify

# UI/State
provider
cached_network_image
ionicons

# Utils
path_provider
connectivity_plus
uuid
```

---

## 🤝 المساهمة

نرحب بالمساهمات! يرجى:

1. Fork المشروع
2. إنشاء branch للميزة (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push إلى Branch (`git push origin feature/amazing-feature`)
5. فتح Pull Request

---

## 📝 الترخيص

هذا المشروع مملوك لـ **AWG - Qatar**

---

## 📞 الدعم

للدعم أو الاستفسارات:
- **Email**: support@awg-zoli.com
- **Website**: https://zoli.awg.qa

---

## 🎯 Roadmap

### الإصدار 1.1
- [ ] Social features (متابعة، تعليقات)
- [ ] Live streaming
- [ ] Playlists للرمشات
- [ ] تحسينات الأداء

### الإصدار 1.2
- [ ] تحرير الفيديو المتقدم
- [ ] فلاتر وتأثيرات
- [ ] Duet mode
- [ ] Gifts and rewards

---

## ⭐ شكر خاص

- فريق Flutter
- فريق Firebase
- مجتمع المطورين

---

**بُني بـ ❤️ في قطر**

**© 2025 AWG - جميع الحقوق محفوظة**
