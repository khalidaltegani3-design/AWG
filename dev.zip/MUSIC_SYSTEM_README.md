# نظام إضافة الموسيقى للفيديو 🎵

## نظرة عامة
نظام متكامل لإضافة مقاطع صوتية من مكتبة موسيقى محلية مع إمكانية الاستماع قبل الاختيار.

---

## المميزات ✨

### 1. مكتبة موسيقى شاملة
- 🎼 **10 تراكات** موسيقية متنوعة
- 🎨 **9 أنواع** موسيقية (Electronic, Hip-Hop, Pop, Rock, Jazz, Classical, Ambient, Dance, R&B)
- 🖼️ صور غلاف عالية الجودة
- ⏱️ معلومات كاملة (العنوان، الفنان، المدة)

### 2. واجهة اختيار موسيقى احترافية
- 🔍 **بحث ذكي** بالعنوان أو اسم الفنان
- 🏷️ **تصفية حسب النوع** مع Chips تفاعلية
- ▶️ **مشغل مدمج** للاستماع قبل الاختيار
- 📊 **شريط تقدم** يوضح موضع التشغيل
- ⏸️ **إيقاف/تشغيل** سهل بنقرة واحدة

### 3. تكامل مع محرر الفيديو
- 🎵 **زر Audio** في شريط الأدوات
- ✅ **مؤشر أخضر** عند اختيار موسيقى
- 🏷️ **بطاقة معلومات** تعرض التراك المختار
- ❌ **إزالة سريعة** للموسيقى المختارة
- 💾 **حفظ metadata** للمعالجة السحابية

---

## البنية التقنية 🏗️

### الملفات المُنشأة

#### 1. `lib/models/music_track.dart`
نموذج بيانات لتراك الموسيقى:
```dart
class MusicTrack {
  final String id;
  final String title;
  final String artist;
  final String genre;
  final Duration duration;
  final String audioUrl;
  final String coverArtUrl;
  final String waveformUrl;
  
  String get formattedDuration; // تنسيق MM:SS
}
```

#### 2. `lib/services/music_service.dart`
خدمة الوصول للموسيقى:
```dart
class MusicService {
  // البحث عن تراكات
  Future<List<MusicTrack>> searchTracks(String query, {String genre = 'All'});
  
  // الحصول على التراكات الشائعة
  Future<List<MusicTrack>> getTrendingTracks();
  
  // الحصول حسب النوع
  Future<List<MusicTrack>> getTracksByGenre(String genre);
  
  // تحميل التراك
  Future<String> downloadTrack(MusicTrack track);
}
```

**الأنواع المتاحة:**
- All (الكل)
- Electronic
- Hip-Hop
- Pop
- Rock
- Jazz
- Classical
- Ambient
- Dance
- R&B

#### 3. `lib/screens/music_picker_screen.dart`
شاشة اختيار الموسيقى:

**المكونات:**
- 🔍 شريط بحث تفاعلي
- 🏷️ Chips للتصفية حسب النوع
- 📜 قائمة التراكات مع صور الغلاف
- 🎵 مشغل موسيقى في الأسفل
- 📊 Slider للتحكم في التقدم

**الحالات:**
- `_tracks`: جميع التراكات
- `_filteredTracks`: التراكات المصفاة
- `_currentPlayingTrack`: التراك الحالي
- `_isPlaying`: حالة التشغيل
- `_currentPosition`: موضع التشغيل
- `_totalDuration`: مدة التراك

#### 4. تحديثات `lib/screens/video_editor_screen.dart`
- ✅ متغير `_selectedMusicTrack` لحفظ التراك
- ✅ دالة `_openMusicPicker()` لفتح شاشة الاختيار
- ✅ مؤشر أخضر على زر Audio
- ✅ بطاقة معلومات التراك المختار
- ✅ تضمين metadata في الرفع

#### 5. تحديثات `lib/services/video_processing_service.dart`
دوال جديدة:
```dart
// دمج الموسيقى مع الفيديو (للمعالجة السحابية)
Future<File?> mergeAudioWithVideo({
  required File videoFile,
  required String audioUrl,
  Function(String)? onStatusChange,
});

// إعداد metadata للرفع
Future<Map<String, dynamic>> prepareEditMetadata({
  required String videoPath,
  String? audioUrl,
  String? audioTitle,
});
```

---

## سير العمل (Workflow) 📋

### 1. اختيار الموسيقى
```
المستخدم يفتح VideoEditorScreen
  ↓
ينقر على زر "Audio" (صوت)
  ↓
تفتح MusicPickerScreen
  ↓
يبحث أو يصفي حسب النوع
  ↓
ينقر على ▶️ للاستماع
  ↓
يختار التراك بالنقر على البطاقة
  ↓
يعود للمحرر مع ظهور مؤشر أخضر
```

### 2. المعالجة والرفع
```
المستخدم ينقر "نشر"
  ↓
تصدير الفيديو المُحرر
  ↓
ضغط الفيديو
  ↓
إعداد metadata (يتضمن audioUrl, audioTitle)
  ↓
رفع الفيديو + metadata
  ↓
المعالجة السحابية تدمج الصوت (اختياري)
```

---

## استخدام API 💻

### فتح شاشة اختيار الموسيقى
```dart
final selectedTrack = await Navigator.push<MusicTrack>(
  context,
  MaterialPageRoute(
    builder: (context) => const MusicPickerScreen(),
  ),
);

if (selectedTrack != null) {
  print('Selected: ${selectedTrack.title} by ${selectedTrack.artist}');
}
```

### البحث عن موسيقى
```dart
final musicService = MusicService();

// بحث عام
final results = await musicService.searchTracks('summer');

// بحث بنوع محدد
final jazzTracks = await musicService.searchTracks('', genre: 'Jazz');

// التراكات الشائعة
final trending = await musicService.getTrendingTracks();
```

### دمج موسيقى مع فيديو
```dart
final processingService = VideoProcessingService();

// إعداد metadata
final metadata = await processingService.prepareEditMetadata(
  videoPath: '/path/to/video.mp4',
  audioUrl: 'https://example.com/audio.mp3',
  audioTitle: 'My Song',
);

// الرفع مع metadata
await uploadService.uploadVideo(
  videoFile,
  metadata: metadata,
);
```

---

## التخصيص 🎨

### إضافة تراكات جديدة
في `music_service.dart`، أضف إلى `_localTracks`:

```dart
MusicTrack(
  id: '11',
  title: 'Your Song Title',
  artist: 'Artist Name',
  genre: 'Pop',
  duration: const Duration(minutes: 3, seconds: 30),
  audioUrl: 'https://your-audio-url.mp3',
  coverArtUrl: 'https://your-cover-image.jpg',
  waveformUrl: '',
),
```

### إضافة أنواع موسيقية جديدة
في `MusicService.genres`:

```dart
static const List<String> genres = [
  'All',
  'Electronic',
  // ... الأنواع الموجودة
  'Country', // نوع جديد
  'Reggae',  // نوع جديد
];
```

---

## التكامل السحابي ☁️

### Firebase Cloud Functions (مقترح)
لدمج الصوت بشكل حقيقي، يمكن استخدام Firebase Functions مع FFmpeg:

```javascript
// functions/index.js
const functions = require('firebase-functions');
const ffmpeg = require('fluent-ffmpeg');
const admin = require('firebase-admin');

exports.mergeAudioWithVideo = functions.https.onCall(async (data, context) => {
  const { videoUrl, audioUrl } = data;
  
  // تحميل الملفات
  const videoPath = await downloadFile(videoUrl);
  const audioPath = await downloadFile(audioUrl);
  
  // دمج باستخدام FFmpeg
  return new Promise((resolve, reject) => {
    ffmpeg(videoPath)
      .input(audioPath)
      .audioCodec('aac')
      .videoCodec('copy')
      .on('end', () => {
        // رفع الملف النهائي
        resolve({ mergedUrl: '...' });
      })
      .on('error', reject)
      .save(outputPath);
  });
});
```

---

## اللغات المدعومة 🌍
- 🇸🇦 **العربية** (كامل)
- 🇬🇧 **الإنجليزية** (كامل)

**النصوص المترجمة:**
- "اختر موسيقى" / "Choose Music"
- "ابحث عن أغنية..." / "Search for a song..."
- "لم يتم العثور على أغاني" / "No songs found"
- "تم اختيار: (اسم)" / "Selected: (name)"
- "صوت" / "Audio"
- "معالجة الموسيقى..." / "Processing music..."

---

## الأداء والتحسينات ⚡

### التخزين المؤقت
- استخدام `cached_network_image` لصور الغلاف
- تخزين التراكات المحملة في الذاكرة

### المعالجة
- تحميل الصوت بشكل غير متزامن
- معالجة الدمج في خيط منفصل (background)
- إظهار progress indicators طوال العملية

### الذاكرة
- تنظيف `AudioPlayer` عند الخروج
- إيقاف التشغيل قبل اختيار تراك جديد

---

## الاختبار 🧪

### سيناريوهات الاختبار

1. **البحث**
   - ✅ البحث بالعنوان
   - ✅ البحث باسم الفنان
   - ✅ البحث بكلمات جزئية
   - ✅ البحث الفارغ (عرض الكل)

2. **التصفية**
   - ✅ تصفية حسب كل نوع
   - ✅ الجمع بين البحث والتصفية
   - ✅ العودة لـ "All"

3. **التشغيل**
   - ✅ تشغيل تراك
   - ✅ إيقاف تراك
   - ✅ التبديل بين تراكات
   - ✅ استخدام Slider
   - ✅ تحديث المدة والموضع

4. **الاختيار**
   - ✅ اختيار تراك
   - ✅ إلغاء الاختيار
   - ✅ عرض المعلومات في المحرر
   - ✅ إزالة التراك

---

## المتطلبات 📦

```yaml
dependencies:
  just_audio: ^0.9.46          # تشغيل الصوت
  cached_network_image: ^3.3.1 # تخزين الصور
  ionicons: ^0.2.2             # الأيقونات
  http: ^1.5.0                 # تحميل الملفات
```

---

## الأخطاء الشائعة ❗

### 1. فشل تحميل الصوت
```dart
// الحل: التحقق من الاتصال بالإنترنت
if (await Connectivity().checkConnectivity() == ConnectivityResult.none) {
  showSnackBar('لا يوجد اتصال بالإنترنت');
  return;
}
```

### 2. خطأ في التشغيل
```dart
// الحل: إعادة تهيئة AudioPlayer
try {
  await _audioPlayer.setUrl(track.audioUrl);
  await _audioPlayer.play();
} catch (e) {
  print('خطأ في التشغيل: $e');
  // إنشاء player جديد
  _audioPlayer = AudioPlayer();
}
```

### 3. تسرب الذاكرة (Memory Leak)
```dart
// الحل: التنظيف الصحيح
@override
void dispose() {
  _audioPlayer.dispose(); // ✅ دائماً dispose
  _searchController.dispose();
  super.dispose();
}
```

---

## الخطوات القادمة 🚀

### قصيرة المدى
- [ ] إضافة مكتبة أكبر (100+ تراك)
- [ ] دعم الموسيقى المحلية من الجهاز
- [ ] قص الموسيقى حسب طول الفيديو
- [ ] التحكم في مستوى الصوت

### طويلة المدى
- [ ] تكامل مع SoundCloud API الرسمي
- [ ] دمج فعلي باستخدام FFmpeg
- [ ] معاينة الموسيقى على الفيديو قبل التصدير
- [ ] Crossfade بين الموسيقى والصوت الأصلي
- [ ] مكتبة مفضلات للمستخدم
- [ ] توصيات ذكية بناءً على محتوى الفيديو

---

## الدعم والمساعدة 📧

للأسئلة والمشاكل:
- 📖 راجع هذا الملف أولاً
- 🐛 أبلغ عن المشاكل في GitHub Issues
- 💬 تواصل مع الفريق

---

**تم بناؤه بـ ❤️ لتطبيق Zoli Chat**
