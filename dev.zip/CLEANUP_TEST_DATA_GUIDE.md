# 🧹 دليل تنظيف البيانات التجريبية - Zoli Chat

> **الهدف**: حذف جميع البيانات التجريبية من Firestore  
> **المجموعات المتأثرة**: Status, Ramshat, Users (test accounts)

---

## ⚠️ تحذير مهم

**هذا الدليل يحتوي على خطوات حذف دائمة!**

يرجى:
1. ✅ عمل نسخة احتياطية من البيانات المهمة
2. ✅ التأكد من أنك تريد حذف البيانات
3. ✅ تشغيل الأوامر في بيئة آمنة

---

## 📋 الطريقة 1: الحذف من Firebase Console (موصى بها)

###  🗑️ حذف بيانات الحالة (Status/Stories)

#### 1. افتح Firebase Console:
```
https://console.firebase.google.com/
```

#### 2. اختر المشروع: **zoliapp-prod**

#### 3. اذهب إلى Firestore Database:
```
Build → Firestore Database
```

#### 4. ابحث عن collection اسمها `statuses` أو `stories`

#### 5. احذف جميع المستندات:
- اضغط على كل مستند
- اختر "Delete document"
- أو احذف الـ collection كاملة إذا كنت متأكداً

**✅ البديل: حذف الـ collection بالكامل**
```
في Firestore Console:
  ↓
اضغط على القائمة الثلاث نقاط بجانب collection name
  ↓
اختر "Delete collection"
  ↓
أدخل اسم الـ collection للتأكيد
  ↓
اضغط "Delete"
```

---

### 🎥 حذف فيديوهات الرمشات التجريبية

#### 1. في Firestore Database → ابحث عن collection `ramshat`:

#### 2. احذف جميع المستندات:
- يمكنك حذف المستندات واحدة تلو الأخرى
- أو حذف الـ collection كاملة

#### 3. احذف الملفات من Storage:
```
Firebase Console → Storage
  ↓
ابحث عن مجلد `ramshat/`
  ↓
احذف جميع المجلدات/الملفات داخله
```

**⚠️ ملاحظة**: تأكد من حذف الملفات من Storage أيضاً لتوفير المساحة!

---

## 📋 الطريقة 2: باستخدام Firebase Admin SDK (للمطورين)

### 🔧 إنشاء Script للحذف التلقائي

إذا كنت تريد script يقوم بالحذف تلقائياً، يمكنك استخدام Firebase Admin SDK:

```javascript
// cleanup-script.js (Node.js)

const admin = require('firebase-admin');

// Initialize Firebase Admin
const serviceAccount = require('./serviceAccountKey.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

async function deleteCollection(collectionPath, batchSize = 100) {
  const collectionRef = db.collection(collectionPath);
  const query = collectionRef.limit(batchSize);

  return new Promise((resolve, reject) => {
    deleteQueryBatch(db, query, resolve).catch(reject);
  });
}

async function deleteQueryBatch(db, query, resolve) {
  const snapshot = await query.get();

  const batchSize = snapshot.size;
  if (batchSize === 0) {
    resolve();
    return;
  }

  const batch = db.batch();
  snapshot.docs.forEach((doc) => {
    batch.delete(doc.ref);
  });
  await batch.commit();

  process.nextTick(() => {
    deleteQueryBatch(db, query, resolve);
  });
}

// حذف Status
async function deleteAllStatuses() {
  console.log('Deleting all statuses...');
  await deleteCollection('statuses');
  console.log('✅ All statuses deleted');
}

// حذف Ramshat
async function deleteAllRamshat() {
  console.log('Deleting all ramshat...');
  await deleteCollection('ramshat');
  console.log('✅ All ramshat deleted');
}

// تشغيل الحذف
async function main() {
  try {
    await deleteAllStatuses();
    await deleteAllRamshat();
    console.log('\n🎉 All test data cleaned successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

main();
```

### 📦 تثبيت Firebase Admin:
```bash
npm install firebase-admin
```

### 🔑 الحصول على Service Account Key:
```
Firebase Console → Project Settings → Service accounts
  ↓
اضغط "Generate new private key"
  ↓
احفظ الملف كـ `serviceAccountKey.json`
```

### ▶️ تشغيل Script:
```bash
node cleanup-script.js
```

---

## 📋 الطريقة 3: من داخل التطبيق (Admin Panel)

يمكنك إنشاء صفحة admin في التطبيق لحذف البيانات:

```dart
// lib/screens/admin_cleanup_screen.dart

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class AdminCleanupScreen extends StatefulWidget {
  const AdminCleanupScreen({Key? key}) : super(key: key);

  @override
  State<AdminCleanupScreen> createState() => _AdminCleanupScreenState();
}

class _AdminCleanupScreenState extends State<AdminCleanupScreen> {
  bool _isDeleting = false;
  String _statusMessage = '';

  Future<void> _deleteAllStatuses() async {
    setState(() {
      _isDeleting = true;
      _statusMessage = 'Deleting statuses...';
    });

    try {
      final QuerySnapshot statusSnapshot = 
          await FirebaseFirestore.instance.collection('statuses').get();
      
      for (var doc in statusSnapshot.docs) {
        await doc.reference.delete();
      }

      setState(() {
        _statusMessage = '✅ All statuses deleted (${statusSnapshot.docs.length} items)';
      });
    } catch (e) {
      setState(() {
        _statusMessage = '❌ Error deleting statuses: $e';
      });
    } finally {
      setState(() {
        _isDeleting = false;
      });
    }
  }

  Future<void> _deleteAllRamshat() async {
    setState(() {
      _isDeleting = true;
      _statusMessage = 'Deleting ramshat videos...';
    });

    try {
      final QuerySnapshot ramshatSnapshot = 
          await FirebaseFirestore.instance.collection('ramshat').get();
      
      for (var doc in ramshatSnapshot.docs) {
        // Delete from Firestore
        await doc.reference.delete();
        
        // Delete from Storage (if videoUrl exists)
        final data = doc.data() as Map<String, dynamic>?;
        if (data != null && data['videoUrl'] != null) {
          try {
            await FirebaseStorage.instance.refFromURL(data['videoUrl']).delete();
          } catch (e) {
            print('Error deleting video file: $e');
          }
        }
      }

      setState(() {
        _statusMessage = '✅ All ramshat deleted (${ramshatSnapshot.docs.length} items)';
      });
    } catch (e) {
      setState(() {
        _statusMessage = '❌ Error deleting ramshat: $e';
      });
    } finally {
      setState(() {
        _isDeleting = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Cleanup'),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(
              Icons.warning_amber_rounded,
              size: 80,
              color: Colors.orange,
            ),
            const SizedBox(height: 24),
            const Text(
              '⚠️ WARNING',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            const Text(
              'This will permanently delete all test data.\nThis action cannot be undone!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              onPressed: _isDeleting ? null : _deleteAllStatuses,
              icon: const Icon(Icons.delete_forever),
              label: const Text('Delete All Statuses'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _isDeleting ? null : _deleteAllRamshat,
              icon: const Icon(Icons.delete_sweep),
              label: const Text('Delete All Ramshat Videos'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            const SizedBox(height: 24),
            if (_isDeleting)
              const Center(child: CircularProgressIndicator()),
            if (_statusMessage.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _statusMessage,
                  style: const TextStyle(fontSize: 14),
                  textAlign: TextAlign.center,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
```

---

## ✅ التحقق من النجاح

بعد الحذف:

### في Firestore:
```
Firestore Database:
  ✅ statuses collection: فارغة
  ✅ ramshat collection: فارغة
```

### في Storage:
```
Storage:
  ✅ ramshat/ folder: فارغ
```

### في التطبيق:
```
Status Screen: ✅ "No statuses available"
Ramshat Screen: ✅ "No videos available"
```

---

## 🎯 ملخص سريع

### الخيار الأسرع (Firebase Console):
1. افتح Firebase Console
2. Firestore Database
3. احذف collection `statuses`
4. احذف collection `ramshat`
5. Storage → احذف مجلد `ramshat/`

**✅ تم! البيانات التجريبية محذوفة**

---

## 📞 الدعم

إذا واجهت مشاكل:
1. تأكد من صلاحياتك في Firebase
2. تحقق من Firebase Console → Firestore Rules
3. راجع Storage Rules

---

**تم إنشاؤه**: 4 أكتوبر 2025  
**المشروع**: Zoli Chat  
**الهدف**: تنظيف البيانات التجريبية من Firestore و Storage
