# 🚀 دليل نشر التطبيق - Zoli Chat

## 📋 المحتويات

1. [قبل النشر](#قبل-النشر)
2. [إعداد Google Play Console](#إعداد-google-play-console)
3. [إعداد App Store Connect](#إعداد-app-store-connect)
4. [بناء التطبيق](#بناء-التطبيق)
5. [الاختبار](#الاختبار)
6. [النشر](#النشر)

---

## ✅ قبل النشر

### قائمة التحقق

#### 1. معلومات التطبيق
- [x] اسم التطبيق: **Zoli**
- [x] Bundle ID: **com.awg.zoli**
- [x] الإصدار: **1.0.0** (versionCode: 1)

#### 2. Firebase
- [ ] جميع خدمات Firebase تعمل
- [ ] SHA-1 للـ Release مضاف
- [ ] App Check مفعّل للإنتاج
- [ ] Security Rules محدّثة
- [ ] Indexes جاهزة

#### 3. الكود
- [ ] لا توجد أخطاء (0 errors)
- [ ] إزالة جميع debug prints
- [ ] إزالة test code
- [ ] تفعيل المصادقة (إلغاء bypass)

#### 4. الأذونات
- [ ] مراجعة جميع الأذونات المطلوبة
- [ ] إزالة الأذونات غير المستخدمة
- [ ] إضافة نصوص توضيحية للأذونات

#### 5. الأصول
- [ ] أيقونة التطبيق (1024x1024)
- [ ] Splash screens
- [ ] Screenshots للمتاجر
- [ ] Feature graphic (للبلاي ستور)

---

## 🤖 إعداد Google Play Console

### 1. إنشاء حساب Play Console

```
https://play.google.com/console
```

رسوم تسجيل لمرة واحدة: **$25**

### 2. إنشاء تطبيق جديد

1. اضغط **Create app**
2. املأ التفاصيل:
   - App name: **Zoli**
   - Default language: **العربية** (أو English)
   - App or game: **App**
   - Free or paid: **Free**

3. اقبل إقرارات المطوّر

### 3. إعداد Signing Key

#### أ. إنشاء Keystore (إن لم يكن موجوداً)

```bash
keytool -genkey -v -keystore ~/zoli-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias zoli
```

املأ البيانات:
```
Enter keystore password: [كلمة مرور قوية]
Re-enter new password: [نفس كلمة المرور]
What is your first and last name?: AWG Team
What is the name of your organizational unit?: Development
What is the name of your organization?: AWG
What is the name of your City or Locality?: Doha
What is the name of your State or Province?: Qatar
What is the two-letter country code for this unit?: QA
```

**احفظ هذه المعلومات بشكل آمن!**

#### ب. تحديث key.properties

أنشئ `android/key.properties`:

```properties
storePassword=YOUR_KEYSTORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=zoli
storeFile=/path/to/zoli-release-key.jks
```

**لا ترفع هذا الملف إلى Git!**

أضف إلى `.gitignore`:
```
android/key.properties
*.jks
```

#### ج. تحديث build.gradle.kts

في `android/app/build.gradle.kts`:

```kotlin
// قبل android {
val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    // ... existing config
    
    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = file(keystoreProperties["storeFile"] as String)
            storePassword = keystoreProperties["storePassword"] as String
        }
    }
    
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
```

#### د. الحصول على SHA-1 للـ Release

```bash
keytool -list -v -keystore ~/zoli-release-key.jks -alias zoli
```

**أضف هذا SHA-1 إلى Firebase Console!**

### 4. Play App Signing

اختر **Google Play App Signing** لأمان أفضل.

```
Release → Setup → App signing
```

---

## 🍎 إعداد App Store Connect

### 1. Apple Developer Account

```
https://developer.apple.com/
```

رسوم سنوية: **$99**

### 2. إنشاء App ID

```
Certificates, Identifiers & Profiles → Identifiers
```

1. اضغط **+**
2. App IDs
3. Bundle ID: **com.awg.zoli**
4. فعّل:
   - Push Notifications
   - App Groups (إن لزم)

### 3. إنشاء Provisioning Profile

```
Certificates, Identifiers & Profiles → Profiles
```

1. اضغط **+**
2. App Store Distribution
3. اختر App ID: **com.awg.zoli**
4. اختر Certificate
5. احفظ الملف

### 4. إنشاء التطبيق في App Store Connect

```
https://appstoreconnect.apple.com/
```

1. My Apps → **+** → New App
2. املأ:
   - Platform: **iOS**
   - Name: **Zoli**
   - Primary Language: **Arabic**
   - Bundle ID: **com.awg.zoli**
   - SKU: **zoli-001**

---

## 🏗️ بناء التطبيق

### Android APK/AAB

#### 1. تنظيف Build

```bash
flutter clean
flutter pub get
```

#### 2. بناء AAB (للبلاي ستور)

```bash
flutter build appbundle --release
```

الملف سيكون في:
```
build/app/outputs/bundle/release/app-release.aab
```

#### 3. بناء APK (للاختبار)

```bash
flutter build apk --release
```

الملف سيكون في:
```
build/app/outputs/flutter-apk/app-release.apk
```

#### 4. بناء Split APKs (حجم أصغر)

```bash
flutter build apk --split-per-abi --release
```

سيُنشئ 3 ملفات:
- `app-armeabi-v7a-release.apk` (32-bit ARM)
- `app-arm64-v8a-release.apk` (64-bit ARM)
- `app-x86_64-release.apk` (64-bit Intel)

### iOS IPA

#### 1. فتح Xcode

```bash
open ios/Runner.xcworkspace
```

#### 2. إعداد Signing

في Xcode:
```
Runner → Signing & Capabilities
```

- Team: [اختر فريقك]
- Bundle Identifier: **com.awg.zoli**

#### 3. بناء Archive

```
Product → Archive
```

انتظر حتى يكتمل البناء.

#### 4. رفع إلى App Store Connect

في Organizer:
```
Window → Organizer → Archives
```

1. اختر Archive
2. **Distribute App**
3. اختر **App Store Connect**
4. **Upload**

---

## 🧪 الاختبار

### Android Testing

#### 1. Internal Testing

```
Play Console → Testing → Internal testing
```

1. أنشئ release جديد
2. ارفع AAB
3. أضف testers
4. احفظ ونشر

#### 2. Closed Testing (Beta)

```
Play Console → Testing → Closed testing
```

مشابه للـ Internal، لكن لمجموعة أكبر.

#### 3. Open Testing (Public Beta)

متاح للجميع للتسجيل.

### iOS Testing

#### 1. TestFlight

بعد رفع البناء إلى App Store Connect:

```
TestFlight → Internal Testing
```

1. أضف Internal Testers
2. سيصلهم دعوة عبر Email

#### 2. External Testing

```
TestFlight → External Testing
```

يتطلب مراجعة من Apple (1-2 يوم).

---

## 🌟 النشر

### Android - Play Store

#### 1. إكمال متطلبات Store Listing

```
Play Console → Store presence → Main store listing
```

املأ:
- **App name**: Zoli
- **Short description** (80 حرف)
- **Full description** (4000 حرف)
- **Screenshots**: على الأقل 2 لكل حجم شاشة
- **Feature graphic**: 1024 x 500
- **App icon**: 512 x 512

#### 2. Content rating

```
Play Console → Policy → App content
```

أكمل الاستبيان.

#### 3. Target audience

حدد الفئة العمرية المستهدفة.

#### 4. إنشاء Production Release

```
Play Console → Production → Create new release
```

1. ارفع AAB
2. أضف Release notes
3. **Save**
4. **Review release**
5. **Start rollout to Production**

⏱️ قد يستغرق من ساعات إلى أيام للمراجعة.

### iOS - App Store

#### 1. إكمال معلومات التطبيق

```
App Store Connect → My Apps → Zoli
```

املأ جميع الحقول المطلوبة:
- Screenshots (iPhone, iPad)
- Description
- Keywords
- Support URL
- Privacy Policy URL

#### 2. تحديد السعر

```
Pricing and Availability
```

اختر:
- **Free**
- Countries: **Select All** (أو حدد)

#### 3. إرسال للمراجعة

```
1.0 Prepare for Submission
```

1. اختر Build من TestFlight
2. املأ جميع البيانات
3. **Submit for Review**

⏱️ عادةً 24-48 ساعة للمراجعة.

---

## 📊 بعد النشر

### المتابعة والتحليل

#### 1. Firebase Analytics

راقب:
- عدد المستخدمين النشطين
- معدل الاحتفاظ
- الأخطاء (Crashlytics)
- الأداء (Performance)

#### 2. Play Console/App Store Connect

تابع:
- التنزيلات
- التقييمات
- المراجعات
- الأخطاء

#### 3. التحديثات

```bash
# زيادة الإصدار
# في pubspec.yaml
version: 1.0.1+2

# بناء ورفع
flutter build appbundle --release
```

---

## 🔄 CI/CD (اختياري)

### GitHub Actions

أنشئ `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Stores

on:
  push:
    tags:
      - 'v*'

jobs:
  android:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
      - uses: subosito/flutter-action@v2
      
      - run: flutter pub get
      - run: flutter build appbundle --release
      
      # Upload to Play Store
      # يحتاج إلى Play Console API key
      
  ios:
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v3
      - uses: subosito/flutter-action@v2
      
      - run: flutter pub get
      - run: flutter build ios --release --no-codesign
      
      # Archive and upload using Fastlane
```

---

## 📞 الدعم

إذا واجهت مشاكل أثناء النشر:

### Android
- [Play Console Help](https://support.google.com/googleplay/android-developer/)
- [Flutter Android Deployment](https://docs.flutter.dev/deployment/android)

### iOS
- [App Store Connect Help](https://developer.apple.com/support/app-store-connect/)
- [Flutter iOS Deployment](https://docs.flutter.dev/deployment/ios)

---

## ✅ قائمة مراجعة نهائية

قبل الضغط على "Publish":

- [ ] اختبرت التطبيق بالكامل
- [ ] جميع Firebase services تعمل في الإنتاج
- [ ] لا توجد test data
- [ ] Privacy Policy منشورة
- [ ] Terms of Service منشورة
- [ ] Support email جاهز
- [ ] Screenshots محدّثة
- [ ] Description محسّنة لـ SEO
- [ ] Content rating مكتمل
- [ ] App icon نهائي
- [ ] Release notes جاهزة

---

## 🎉 تهانينا!

تطبيقك الآن على المتاجر! 🚀

**التطبيق**: Zoli  
**Bundle ID**: com.awg.zoli  
**الإصدار**: 1.0.0

---

**آخر تحديث**: أكتوبر 2025
