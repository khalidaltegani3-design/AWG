# Alternative Flutter Installation Script

Write-Host "Trying alternative Flutter installation..."

# Clear the existing flutter directory first
if (Test-Path "C:\flutter") {
    Remove-Item -Path "C:\flutter" -Recurse -Force
}

# Try using curl (Windows 10 version 1803 and later)
Write-Host "Downloading Flutter using curl..."
curl -L -o "$env:TEMP\flutter.zip" "https://storage.googleapis.com/flutter_infra_release/releases/stable/windows/flutter_windows_3.24.4-stable.zip"

if (Test-Path "$env:TEMP\flutter.zip") {
    Write-Host "Download successful. Extracting..."
    
    # Create flutter directory
    New-Item -ItemType Directory -Force -Path "C:\flutter"
    
    # Extract using PowerShell's built-in extraction
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [System.IO.Compression.ZipFile]::ExtractToDirectory("$env:TEMP\flutter.zip", "C:\")
        Write-Host "Extraction completed successfully!"
        
        # Verify installation
        if (Test-Path "C:\flutter\bin\flutter.bat") {
            Write-Host "Flutter installation verified!"
            
            # Add to PATH
            $currentPath = [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::User)
            if (-not ($currentPath -like "*C:\flutter\bin*")) {
                $newPath = $currentPath + ";C:\flutter\bin"
                [Environment]::SetEnvironmentVariable("Path", $newPath, [EnvironmentVariableTarget]::User)
                Write-Host "Flutter added to PATH successfully!"
            }
        } else {
            Write-Host "Installation verification failed."
        }
    } catch {
        Write-Host "Extraction failed: $($_.Exception.Message)"
    }
    
    # Clean up
    Remove-Item -Path "$env:TEMP\flutter.zip" -Force
} else {
    Write-Host "Download failed. Please check your internet connection."
}

Write-Host "Script completed."