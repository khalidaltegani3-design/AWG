# دليل تثبيت Flutter السريع لتشغيل التطبيق

## ✅ ما تم تحضيره بالفعل:
- تم تحضير ملفات الويب للعرض المحمول
- تم إعداد CSS للتصميم المحمول (375x812 بكسل)
- تم تحديث manifest.json للتطبيق المحمول

## 📱 لتشغيل التطبيق بعرض الهاتف المحمول:

### الطريقة 1: تثبيت Flutter (مُوصى به)

1. **افتح PowerShell كمسؤول**
2. **قم بتشغيل هذا الأمر:**
```powershell
# إنشاء مجلد flutter
New-Item -ItemType Directory -Force -Path "C:\flutter"

# تحميل Flutter
Invoke-WebRequest -Uri "https://storage.googleapis.com/flutter_infra_release/releases/stable/windows/flutter_windows_3.24.4-stable.zip" -OutFile "$env:TEMP\flutter.zip"

# استخراج الملفات
Expand-Archive -Path "$env:TEMP\flutter.zip" -DestinationPath "C:\" -Force

# إضافة Flutter للـ PATH
$env:PATH += ";C:\flutter\bin"
[Environment]::SetEnvironmentVariable("Path", $env:PATH, [EnvironmentVariableTarget]::User)
```

3. **تأكد من التثبيت:**
```powershell
flutter doctor
```

4. **في مجلد المشروع، شغّل:**
```powershell
cd "c:\Users\khali\zoli-chat"
flutter pub get
flutter run -d chrome --web-renderer html
```

### الطريقة 2: تثبيت يدوي سريع

1. **اذهب إلى:** https://docs.flutter.dev/get-started/install/windows
2. **حمّل** النسخة المستقرة من Flutter
3. **استخرج** في `C:\flutter`
4. **أضف** `C:\flutter\bin` إلى PATH
5. **شغّل** `run_web_mobile.bat`

## 📱 بعد التثبيت:

عند تشغيل `flutter run -d chrome`، ستفتح نافذة متصفح مع:
- **عرض محمول**: 375×812 بكسل (حجم iPhone)
- **خلفية متدرجة**: للشعور بالتطبيق الحقيقي
- **حواف مدورة**: تحاكي شاشة الهاتف
- **تصميم responsive**: يتكيف مع أحجام الشاشات

## 🔧 نصائح للاختبار:
- اضغط **F12** لفتح Developer Tools
- اختر **Device Toolbar** لمحاكاة أجهزة مختلفة
- جرب أحجام شاشات مختلفة (iPhone, Pixel, etc.)

## 🎯 ميزات التطبيق للاختبار:
- 🔐 تسجيل الدخول/إنشاء حساب
- 💬 شاشة الدردشة التفاعلية
- 🎥 عرض الفيديوهات (Reels)
- 🔄 التنقل بين الأقسام

---
**ملاحظة:** التطبيق يستخدم Firebase demo للعرض، لذا قد تظهر رسائل خطأ في Console، لكن الواجهة ستعمل بشكل طبيعي.