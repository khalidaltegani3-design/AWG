# 📤 رفع Firebase Rules يدوياً من Console

## نظرة عامة
دليل خطوة بخطوة لرفع Firestore Rules و Storage Rules مباشرة من Firebase Console (بدون CLI).

---

## 🔥 الطريقة 1: رفع Firestore Rules

### الخطوة 1: فتح Firestore Rules

1. اذهب إلى Firebase Console:
   ```
   https://console.firebase.google.com/
   ```

2. اختر مشروعك: **zoliapp-prod** (أو اسم مشروعك)

3. من القائمة اليسرى:
   - **Build** → **Firestore Database** → **Rules**

### الخطوة 2: نسخ القواعد الجديدة

افتح ملف `firestore.rules` من المشروع وانسخ المحتوى كاملاً:

```
📁 c:\Users\khali\zoli-chat\firestore.rules
```

### الخطوة 3: لصق ونشر

1. في Firebase Console، **احذف** القواعد القديمة كاملة
2. **الصق** القواعد الجديدة من `firestore.rules`
3. اضغط **Publish** (أو **نشر**)

### ✅ التحقق من النجاح

يجب أن ترى رسالة:
```
✅ Rules published successfully
```

---

## 📦 الطريقة 2: رفع Storage Rules

### الخطوة 1: فتح Storage Rules

1. من Firebase Console
2. من القائمة اليسرى:
   - **Build** → **Storage** → **Rules**

### الخطوة 2: نسخ القواعد الجديدة

افتح ملف `storage.rules` من المشروع وانسخ المحتوى كاملاً:

```
📁 c:\Users\khali\zoli-chat\storage.rules
```

### الخطوة 3: لصق ونشر

1. في Firebase Console، **احذف** القواعد القديمة كاملة
2. **الصق** القواعد الجديدة من `storage.rules`
3. اضغط **Publish** (أو **نشر**)

### ✅ التحقق من النجاح

يجب أن ترى رسالة:
```
✅ Rules published successfully
```

---

## 📋 محتوى firestore.rules (للنسخ)

```plaintext
rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    // ====================
    // Users Collection
    // ====================
    match /users/{userId} {
      // القراءة: أي مستخدم مسجل يمكنه قراءة بيانات أي مستخدم
      allow read: if request.auth != null;
      
      // الكتابة: فقط المستخدم نفسه يمكنه تحديث بياناته
      allow write: if request.auth != null && request.auth.uid == userId;
      
      // Tokens sub-collection (FCM)
      match /tokens/{tokenId} {
        // فقط المستخدم نفسه يمكنه إدارة tokens الخاصة به
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }

    // ====================
    // Reels (Blinks) Collection
    // ====================
    match /reels/{reelId} {
      // القراءة: جميع المستخدمين المسجلين (عامة)
      allow read: if request.auth != null;
      
      // الإنشاء: أي مستخدم مسجل يمكنه إنشاء blink
      allow create: if request.auth != null
        && request.resource.data.keys().hasAll(['uid', 'videoUrl', 'createdAt'])
        && request.resource.data.uid == request.auth.uid;
      
      // التحديث: فقط صاحب الـ blink أو لزيادة views/likes
      allow update: if request.auth != null && (
        // صاحب الـ blink يمكنه التحديث الكامل
        resource.data.uid == request.auth.uid
        // أو أي مستخدم يمكنه زيادة views/likes فقط
        || (request.resource.data.diff(resource.data).affectedKeys().hasOnly(['views', 'likes', 'updatedAt']))
      );
      
      // الحذف: فقط صاحب الـ blink
      allow delete: if request.auth != null && resource.data.uid == request.auth.uid;
    }

    // ====================
    // Posts Collection (إن وجدت)
    // ====================
    match /posts/{postId} {
      // القراءة: جميع المستخدمين المسجلين
      allow read: if request.auth != null;
      
      // الإنشاء: أي مستخدم مسجل
      allow create: if request.auth != null
        && request.resource.data.authorId == request.auth.uid;
      
      // التحديث والحذف: فقط صاحب المنشور
      allow update, delete: if request.auth != null 
        && resource.data.authorId == request.auth.uid;
    }

    // ====================
    // Comments Collection (إن وجدت)
    // ====================
    match /comments/{commentId} {
      // القراءة: جميع المستخدمين المسجلين
      allow read: if request.auth != null;
      
      // الإنشاء: أي مستخدم مسجل
      allow create: if request.auth != null
        && request.resource.data.authorId == request.auth.uid;
      
      // التحديث والحذف: فقط صاحب التعليق
      allow update, delete: if request.auth != null 
        && resource.data.authorId == request.auth.uid;
    }

    // ====================
    // Likes Collection (إن وجدت)
    // ====================
    match /likes/{likeId} {
      // القراءة: جميع المستخدمين المسجلين
      allow read: if request.auth != null;
      
      // الكتابة: فقط المستخدم نفسه لـ likes الخاصة به
      allow write: if request.auth != null
        && request.resource.data.userId == request.auth.uid;
    }

    // ====================
    // Stories Collection (إن وجدت)
    // ====================
    match /stories/{storyId} {
      // القراءة: جميع المستخدمين المسجلين
      allow read: if request.auth != null;
      
      // الإنشاء: أي مستخدم مسجل
      allow create: if request.auth != null
        && request.resource.data.userId == request.auth.uid;
      
      // التحديث والحذف: فقط صاحب الستوري
      allow update, delete: if request.auth != null 
        && resource.data.userId == request.auth.uid;
    }

    // ====================
    // Default: رفض كل شيء آخر
    // ====================
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

---

## 📋 محتوى storage.rules (للنسخ)

```plaintext
rules_version = '2';

service firebase.storage {
  match /b/{bucket}/o {
    // ====================
    // Helper Functions
    // ====================
    
    // التحقق من أن المستخدم مسجل
    function isAuthenticated() {
      return request.auth != null;
    }
    
    // التحقق من أن المستخدم هو صاحب الملف
    function isOwner(uid) {
      return request.auth != null && request.auth.uid == uid;
    }
    
    // التحقق من نوع الملف (فيديو)
    function isVideo() {
      return request.resource.contentType.matches('video/.*');
    }
    
    // التحقق من نوع الملف (صورة)
    function isImage() {
      return request.resource.contentType.matches('image/.*');
    }
    
    // التحقق من حجم الملف (أقل من 200 ميجا)
    function isValidVideoSize() {
      return request.resource.size < 200 * 1024 * 1024; // 200MB
    }
    
    // التحقق من حجم الصورة (أقل من 10 ميجا)
    function isValidImageSize() {
      return request.resource.size < 10 * 1024 * 1024; // 10MB
    }

    // ====================
    // Uploads: Blinks Videos
    // Path: uploads/{uid}/{blinkId}.mp4
    // ====================
    match /uploads/{uid}/{blinkId} {
      // القراءة: جميع المستخدمين المسجلين (الفيديوهات عامة)
      allow read: if isAuthenticated();
      
      // الكتابة: فقط صاحب الـ uid يمكنه رفع فيديوهات
      allow create, update: if isOwner(uid)
        && isVideo()
        && isValidVideoSize();
      
      // الحذف: فقط صاحب الـ uid
      allow delete: if isOwner(uid);
    }

    // ====================
    // Thumbnails: Blinks Thumbnails
    // Path: thumbs/{blinkId}/thumb.jpg
    // ====================
    match /thumbs/{blinkId}/{thumbnail} {
      // القراءة: جميع المستخدمين المسجلين (الصور عامة)
      allow read: if isAuthenticated();
      
      // الكتابة: أي مستخدم مسجل يمكنه رفع thumbnail
      // (لأننا لا نستطيع التحقق من uid من المسار)
      allow create, update: if isAuthenticated()
        && isImage()
        && isValidImageSize();
      
      // الحذف: أي مستخدم مسجل
      allow delete: if isAuthenticated();
    }

    // ====================
    // Profile Images
    // Path: avatars/{uid}/profile.jpg
    // ====================
    match /avatars/{uid}/{imageFile} {
      // القراءة: جميع المستخدمين المسجلين
      allow read: if isAuthenticated();
      
      // الكتابة: فقط صاحب الـ uid
      allow create, update: if isOwner(uid)
        && isImage()
        && isValidImageSize();
      
      // الحذف: فقط صاحب الـ uid
      allow delete: if isOwner(uid);
    }

    // ====================
    // Stories
    // Path: stories/{uid}/{storyFile}
    // ====================
    match /stories/{uid}/{storyFile} {
      // القراءة: جميع المستخدمين المسجلين
      allow read: if isAuthenticated();
      
      // الكتابة: فقط صاحب الـ uid
      allow create, update: if isOwner(uid)
        && isImage()
        && isValidImageSize();
      
      // الحذف: فقط صاحب الـ uid
      allow delete: if isOwner(uid);
    }

    // ====================
    // Default: رفض كل شيء آخر
    // ====================
    match /{allPaths=**} {
      allow read, write: if false;
    }
  }
}
```

---

## 🎯 خطوات سريعة

### 1️⃣ Firestore Rules
```
1. Firebase Console → Firestore Database → Rules
2. Copy from: c:\Users\khali\zoli-chat\firestore.rules
3. Paste in Console
4. Click "Publish"
```

### 2️⃣ Storage Rules
```
1. Firebase Console → Storage → Rules
2. Copy from: c:\Users\khali\zoli-chat\storage.rules
3. Paste in Console
4. Click "Publish"
```

---

## ✅ التحقق من النشر

### Firestore Rules
في Firebase Console → Firestore → Rules:
- ✅ يجب أن ترى `rules_version = '2';`
- ✅ يجب أن ترى `match /reels/{reelId}`
- ✅ يجب أن ترى `match /users/{userId}`
- ✅ يجب أن ترى تاريخ النشر محدّث

### Storage Rules
في Firebase Console → Storage → Rules:
- ✅ يجب أن ترى `rules_version = '2';`
- ✅ يجب أن ترى `match /uploads/{uid}/{blinkId}`
- ✅ يجب أن ترى `match /thumbs/{blinkId}/{thumbnail}`
- ✅ يجب أن ترى helper functions
- ✅ يجب أن ترى تاريخ النشر محدّث

---

## 🧪 اختبار القواعد

### من التطبيق Flutter

```dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:zoli/services/blink_service.dart';
import 'package:zoli/services/storage_service.dart';

// اختبار Firestore Rules
final uid = FirebaseAuth.instance.currentUser!.uid;

// 1. إنشاء blink (يجب أن ينجح)
try {
  await BlinkService().createBlink(BlinkModel(
    id: 'test-blink',
    uid: uid,
    videoUrl: 'gs://test/video.mp4',
    description: 'Test',
    createdAt: DateTime.now(),
  ));
  print('✅ Firestore Rules working!');
} catch (e) {
  print('❌ Firestore Rules error: $e');
}

// 2. رفع فيديو (يجب أن ينجح)
try {
  final gsUrl = await StorageService().uploadBlinkVideo(
    file: File('test.mp4'),
    uid: uid,
    blinkId: 'test-blink',
  );
  print('✅ Storage Rules working!');
} catch (e) {
  print('❌ Storage Rules error: $e');
}
```

---

## 🔍 حل المشاكل

### مشكلة: Permission Denied بعد النشر

**السبب**: المستخدم غير مسجل

**الحل**:
```dart
// تسجيل الدخول أولاً
if (FirebaseAuth.instance.currentUser == null) {
  await FirebaseAuth.instance.signInAnonymously();
}
```

### مشكلة: Rules لم تتحدث

**الحل**:
1. انتظر 1-2 دقيقة
2. أعد تحميل الصفحة في Firebase Console
3. تحقق من تاريخ آخر نشر

### مشكلة: Syntax Error في Rules

**الحل**:
- تأكد من نسخ الملف **كاملاً** بدون تعديل
- تحقق من عدم وجود أحرف غريبة
- Firebase Console سيظهر لك الخطأ بالضبط

---

## 📊 الفرق بين القديم والجديد

### Firestore Rules

**القديم**:
```javascript
// قواعد عامة بسيطة
allow read, write: if request.auth != null;
```

**الجديد**:
```javascript
// قواعد مخصصة لكل collection
match /reels/{reelId} {
  allow read: if request.auth != null;
  allow create: if request.auth != null 
    && request.resource.data.uid == request.auth.uid;
  // ... قواعد محددة للـ update/delete
}
```

### Storage Rules

**القديم**:
```javascript
match /videos/{userId}/{videoId}/{file} {
  allow read: if true;
  allow write: if request.auth != null;
}
```

**الجديد**:
```javascript
match /uploads/{uid}/{blinkId} {
  allow read: if isAuthenticated();
  allow create, update: if isOwner(uid) 
    && isVideo() 
    && isValidVideoSize();
}
// + مسارات جديدة: thumbs/, avatars/, stories/
```

---

## ✨ المميزات الجديدة

### Firestore
- ✅ Collection `reels` عامة (Blinks visible to all)
- ✅ Views و Likes يمكن تحديثها من أي مستخدم
- ✅ FCM tokens محمية (sub-collection)
- ✅ Posts, Comments, Likes, Stories محمية

### Storage
- ✅ 4 مسارات مخصصة (uploads, thumbs, avatars, stories)
- ✅ Helper functions للتحقق
- ✅ حدود حجم صارمة (200MB فيديو، 10MB صورة)
- ✅ التحقق من نوع الملف (video/image)

---

## 🎉 الخلاصة

بعد رفع القواعد يدوياً من Firebase Console:

- ✅ Blinks تظهر لجميع المستخدمين
- ✅ رفع الفيديو مع ضغط 70% يعمل
- ✅ المسارات الجديدة محمية
- ✅ Views و Likes يعملون
- ✅ جاهز للإنتاج 100%

---

**الطريقة اليدوية أبسط وأسرع من Firebase CLI!** 🚀
