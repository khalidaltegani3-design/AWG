# 🚀 دليل نشر Firebase Rules

## نظرة عامة
دليل شامل لنشر Firestore Rules و Storage Rules إلى Firebase Console.

---

## 📋 المتطلبات الأساسية

### 1. تثبيت Firebase CLI
```powershell
# تثبيت Firebase CLI
npm install -g firebase-tools

# التحقق من التثبيت
firebase --version
```

### 2. تسجيل الدخول
```powershell
# تسجيل الدخول إلى Firebase
firebase login

# التحقق من الحساب
firebase projects:list
```

### 3. تهيئة المشروع (إذا لم يتم من قبل)
```powershell
# في مجلد المشروع
cd c:\Users\khali\zoli-chat

# تهيئة Firebase
firebase init

# اختر:
# - Firestore
# - Storage
# - Project: zoliapp-prod
```

---

## 📁 الملفات الموجودة

```
zoli-chat/
├── firestore.rules       ← Firestore Security Rules
├── storage.rules         ← Storage Security Rules
└── firebase.json         ← تكوين Firebase
```

---

## 🔍 مراجعة القواعد قبل النشر

### 1. فحص Firestore Rules
```powershell
# عرض محتوى firestore.rules
Get-Content firestore.rules

# التحقق من الـ syntax
firebase firestore:rules:check
```

**النقاط المهمة في firestore.rules:**
- ✅ Collection `reels` عامة للقراءة (جميع المستخدمين)
- ✅ Create: أي مستخدم مسجل
- ✅ Update: صاحب الـ blink أو لزيادة views/likes
- ✅ Delete: صاحب الـ blink فقط
- ✅ Sub-collection `users/{uid}/tokens` للـ FCM

### 2. فحص Storage Rules
```powershell
# عرض محتوى storage.rules
Get-Content storage.rules

# التحقق من الـ syntax
firebase storage:rules:check
```

**النقاط المهمة في storage.rules:**
- ✅ Path: `uploads/{uid}/{blinkId}.mp4` (الفيديوهات)
- ✅ Path: `thumbs/{blinkId}/thumb.jpg` (الصور المصغرة)
- ✅ Path: `avatars/{uid}/profile.jpg` (صور البروفايل)
- ✅ Path: `stories/{uid}/{storyFile}` (الستوريات)
- ✅ حجم الفيديو: أقل من 200 MB
- ✅ حجم الصورة: أقل من 10 MB

---

## 🚀 النشر

### الطريقة 1: نشر كل شيء
```powershell
# نشر Firestore و Storage Rules معاً
firebase deploy --only firestore:rules,storage:rules

# أو ببساطة
firebase deploy
```

### الطريقة 2: نشر Firestore Rules فقط
```powershell
firebase deploy --only firestore:rules
```

### الطريقة 3: نشر Storage Rules فقط
```powershell
firebase deploy --only storage:rules
```

---

## 📊 التحقق من النشر

### 1. من خلال Firebase Console

**Firestore Rules:**
1. اذهب إلى: https://console.firebase.google.com/project/zoliapp-prod/firestore/rules
2. تحقق من:
   - Rules version: `rules_version = '2';`
   - Collection `reels` موجودة
   - Collection `users` مع sub-collection `tokens`

**Storage Rules:**
1. اذهب إلى: https://console.firebase.google.com/project/zoliapp-prod/storage/rules
2. تحقق من:
   - Rules version: `rules_version = '2';`
   - المسارات الصحيحة: `uploads/`, `thumbs/`, `avatars/`, `stories/`
   - Helper functions موجودة

### 2. من خلال Firebase CLI
```powershell
# الحصول على Firestore Rules الحالية
firebase firestore:rules:get > current_firestore.rules

# مقارنة مع الملف المحلي
diff firestore.rules current_firestore.rules

# الحصول على Storage Rules الحالية
firebase storage:rules:get > current_storage.rules

# مقارنة
diff storage.rules current_storage.rules
```

---

## ✅ اختبار القواعد

### 1. اختبار Firestore Rules (من الكود)

```dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:zoli/services/blink_service.dart';
import 'package:zoli/models/blink_model.dart';

Future<void> testFirestoreRules() async {
  final blinkService = BlinkService();
  final uid = FirebaseAuth.instance.currentUser!.uid;
  
  try {
    // اختبار 1: إنشاء blink (يجب أن ينجح)
    print('Test 1: Create blink...');
    final blink = BlinkModel(
      id: 'test-${DateTime.now().millisecondsSinceEpoch}',
      uid: uid,
      videoUrl: 'gs://test/video.mp4',
      description: 'Test blink',
      createdAt: DateTime.now(),
    );
    await blinkService.createBlink(blink);
    print('✅ Create succeeded');
    
    // اختبار 2: قراءة blink (يجب أن ينجح)
    print('Test 2: Read blink...');
    final readBlink = await blinkService.getBlink(blink.id);
    print('✅ Read succeeded: ${readBlink?.description}');
    
    // اختبار 3: تحديث blink (صاحبه فقط)
    print('Test 3: Update blink...');
    await blinkService.updateBlink(
      blink.id,
      {'description': 'Updated description'},
    );
    print('✅ Update succeeded');
    
    // اختبار 4: زيادة views (أي مستخدم)
    print('Test 4: Increment views...');
    await blinkService.incrementViews(blink.id);
    print('✅ Increment views succeeded');
    
    // اختبار 5: حذف blink (صاحبه فقط)
    print('Test 5: Delete blink...');
    await blinkService.deleteBlink(blink.id);
    print('✅ Delete succeeded');
    
    print('\n🎉 All Firestore tests passed!');
    
  } catch (e) {
    print('❌ Test failed: $e');
  }
}
```

### 2. اختبار Storage Rules (من الكود)

```dart
import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:zoli/services/storage_service.dart';

Future<void> testStorageRules() async {
  final storageService = StorageService();
  final uid = FirebaseAuth.instance.currentUser!.uid;
  
  try {
    // اختبار 1: رفع فيديو (صاحب uid فقط)
    print('Test 1: Upload blink video...');
    final testVideo = File('test_video.mp4'); // ملف تجريبي
    final gsUrl = await storageService.uploadBlinkVideo(
      file: testVideo,
      uid: uid,
      blinkId: 'test-blink',
    );
    print('✅ Upload succeeded: $gsUrl');
    
    // اختبار 2: قراءة الفيديو (أي مستخدم مسجل)
    print('Test 2: Get download URL...');
    final downloadUrl = await storageService.getDownloadUrl(gsUrl);
    print('✅ Read succeeded: $downloadUrl');
    
    // اختبار 3: حذف الفيديو (صاحب uid فقط)
    print('Test 3: Delete video...');
    await storageService.deleteFile(gsUrl);
    print('✅ Delete succeeded');
    
    print('\n🎉 All Storage tests passed!');
    
  } catch (e) {
    print('❌ Test failed: $e');
  }
}
```

---

## 🐛 حل المشاكل الشائعة

### مشكلة 1: Permission Denied في Firestore
```
Error: PERMISSION_DENIED: Missing or insufficient permissions
```

**الحل:**
1. تأكد من أن المستخدم مسجل:
   ```dart
   if (FirebaseAuth.instance.currentUser == null) {
     await FirebaseAuth.instance.signInAnonymously();
   }
   ```

2. تأكد من أن `uid` في الـ document يطابق `request.auth.uid`:
   ```dart
   final blink = BlinkModel(
     uid: FirebaseAuth.instance.currentUser!.uid, // ✅ صحيح
     // uid: 'some-other-uid', // ❌ خطأ
   );
   ```

### مشكلة 2: Permission Denied في Storage
```
Error: [firebase_storage/unauthorized] User is not authorized
```

**الحل:**
1. تأكد من المسار صحيح:
   ```dart
   // ✅ صحيح
   'uploads/${uid}/${blinkId}.mp4'
   
   // ❌ خطأ
   'videos/${uid}/${blinkId}.mp4'
   ```

2. تأكد من نوع الملف صحيح:
   ```dart
   // للفيديو: video/mp4
   // للصورة: image/jpeg
   ```

### مشكلة 3: File Too Large
```
Error: File size exceeds the maximum allowed size
```

**الحل:**
- Firestore: لا يوجد حد للـ document (1 MB max)
- Storage Videos: 200 MB max (مع الضغط ~60 MB)
- Storage Images: 10 MB max

إذا كان الفيديو أكبر، فعّل الضغط:
```dart
await storageService.uploadBlinkVideo(
  file: file,
  uid: uid,
  blinkId: blinkId,
  compress: true, // ✅ تفعيل الضغط (70% تقليل)
);
```

---

## 📝 ملاحظات مهمة

### Firestore Rules
- ✅ Collection `reels` عامة للقراءة (visible to all)
- ✅ `uid` و `authorId` مدعومان للتوافق
- ✅ Views و Likes يمكن تحديثهما من أي مستخدم
- ✅ Sub-collection `tokens` محمية (FCM)

### Storage Rules
- ✅ جميع القراءات عامة (للمستخدمين المسجلين)
- ✅ الكتابة فقط لصاحب الـ uid
- ✅ Thumbnails يمكن لأي مستخدم رفعها (لا uid في المسار)
- ✅ حدود حجم صارمة (200MB للفيديو، 10MB للصورة)

### أمان إضافي
- 🔒 App Check (اختياري لمنع الوصول من خارج التطبيق)
- 🔒 Rate Limiting (في Firebase Console)
- 🔒 Monitoring (Cloud Functions للتنبيهات)

---

## 📚 موارد إضافية

### Documentation
- [Firestore Security Rules](https://firebase.google.com/docs/firestore/security/get-started)
- [Storage Security Rules](https://firebase.google.com/docs/storage/security/start)
- [Firebase CLI Reference](https://firebase.google.com/docs/cli)

### Best Practices
- [Security Rules Best Practices](https://firebase.google.com/docs/rules/manage-deploy#best-practices)
- [Testing Rules](https://firebase.google.com/docs/rules/unit-tests)

---

## ✅ Checklist قبل النشر

- [ ] مراجعة `firestore.rules`
- [ ] مراجعة `storage.rules`
- [ ] تسجيل الدخول إلى Firebase CLI
- [ ] التحقق من اسم المشروع: `zoliapp-prod`
- [ ] تشغيل `firebase firestore:rules:check`
- [ ] تشغيل `firebase storage:rules:check`
- [ ] نشر القواعد: `firebase deploy --only firestore:rules,storage:rules`
- [ ] التحقق من Firebase Console
- [ ] اختبار القواعد من التطبيق
- [ ] مراقبة الـ logs للأخطاء

---

## 🎯 الأوامر السريعة

```powershell
# تسجيل الدخول
firebase login

# التحقق من المشروع
firebase use zoliapp-prod

# فحص Firestore Rules
firebase firestore:rules:check

# فحص Storage Rules
firebase storage:rules:check

# نشر كل شيء
firebase deploy --only firestore:rules,storage:rules

# التحقق بعد النشر
firebase firestore:rules:get
firebase storage:rules:get
```

---

## 🎉 النشر الناجح

بعد تشغيل:
```powershell
firebase deploy --only firestore:rules,storage:rules
```

يجب أن ترى:
```
✔  Deploy complete!

Project Console: https://console.firebase.google.com/project/zoliapp-prod/overview
```

**الآن:**
- ✅ Firestore Rules منشورة ومفعّلة
- ✅ Storage Rules منشورة ومفعّلة
- ✅ Collection `reels` (Blinks) عامة للجميع
- ✅ رفع الفيديوهات مع الضغط (70%) يعمل
- ✅ جميع المسارات محمية ومتوافقة
