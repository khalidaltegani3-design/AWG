import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:zoli_chat/providers/language_provider.dart';

class TextEditorScreen extends StatefulWidget {
  const TextEditorScreen({super.key});

  @override
  State<TextEditorScreen> createState() => _TextEditorScreenState();
}

class _TextEditorScreenState extends State<TextEditorScreen> {
  final TextEditingController _textController = TextEditingController();
  Color _selectedColor = Colors.white;
  final List<Color> _colors = [
    Colors.white,
    Colors.black,
    Colors.red,
    Colors.blue,
    Colors.green,
    Colors.yellow,
    Colors.purple,
    Colors.orange,
  ];

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    return Scaffold(
      backgroundColor: Colors.black.withOpacity(0.8),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          TextButton(
            onPressed: () {
              if (_textController.text.isNotEmpty) {
                Navigator.pop(context, {
                  'text': _textController.text,
                  'color': _selectedColor,
                });
              }
            },
            child: Text(
              isArabic ? 'تم' : 'Done',
              style: const TextStyle(color: Colors.white, fontSize: 18),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: TextField(
                  controller: _textController,
                  autofocus: true,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _selectedColor,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: isArabic ? 'اكتب شيئاً...' : 'Type something...',
                    hintStyle: TextStyle(
                      color: _selectedColor.withOpacity(0.5),
                      fontSize: 32,
                    ),
                  ),
                ),
              ),
            ),
            _buildColorPalette(),
          ],
        ),
      ),
    );
  }

  Widget _buildColorPalette() {
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: _colors.map((color) {
          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedColor = color;
              });
            },
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 8),
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
                border: Border.all(
                  color: _selectedColor == color ? Colors.blue : Colors.white,
                  width: 2,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
