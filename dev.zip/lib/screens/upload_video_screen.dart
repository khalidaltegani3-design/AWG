import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../providers/language_provider.dart';
import 'video_editor_screen.dart';

class UploadVideoScreen extends StatefulWidget {
  const UploadVideoScreen({Key? key}) : super(key: key);

  @override
  State<UploadVideoScreen> createState() => _UploadVideoScreenState();
}

class _UploadVideoScreenState extends State<UploadVideoScreen> {
  final ImagePicker picker = ImagePicker();

  Future<void> _pickVideoFromGallery() async {
    final XFile? video = await picker.pickVideo(
      source: ImageSource.gallery,
      maxDuration: const Duration(seconds: 180), // 3 minutes max
    );

    if (video == null) return;

    // Navigate to editor screen
    if (!mounted) return;
    
    final result = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (context) => VideoEditorScreen(
          videoFile: File(video.path),
        ),
      ),
    );

    // If video was uploaded successfully, show success and go back
    if (result != null && mounted) {
      Navigator.of(context).pop();
    }
  }

  Future<void> _pickVideoFromCamera() async {
    final XFile? video = await picker.pickVideo(
      source: ImageSource.camera,
      maxDuration: const Duration(seconds: 180), // 3 minutes max
    );

    if (video == null) return;

    // Navigate to editor screen
    if (!mounted) return;
    
    final result = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (context) => VideoEditorScreen(
          videoFile: File(video.path),
        ),
      ),
    );

    // If video was uploaded successfully, show success and go back
    if (result != null && mounted) {
      Navigator.of(context).pop();
    }
  }

  void _showVideoSourceOptions() {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext bc) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                ListTile(
                  leading: const Icon(Icons.videocam, size: 28),
                  title: Text(
                    isArabic ? 'تصوير فيديو' : 'Record Video',
                    style: const TextStyle(fontSize: 18),
                  ),
                  onTap: () {
                    Navigator.of(context).pop();
                    _pickVideoFromCamera();
                  },
                ),
                const Divider(),
                ListTile(
                  leading: const Icon(Icons.video_library, size: 28),
                  title: Text(
                    isArabic ? 'اختيار من المعرض' : 'Choose from Gallery',
                    style: const TextStyle(fontSize: 18),
                  ),
                  onTap: () {
                    Navigator.of(context).pop();
                    _pickVideoFromGallery();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'إنشاء رمشة' : 'Create Ramsha'),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.video_library,
                size: 100,
                color: Theme.of(context).primaryColor,
              ),
              const SizedBox(height: 32),
              Text(
                isArabic
                    ? 'اختر فيديو لإنشاء رمشة جديدة'
                    : 'Choose a video to create a new Ramsha',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 40),
              ElevatedButton.icon(
                onPressed: _showVideoSourceOptions,
                icon: const Icon(Icons.add_circle_outline, size: 28),
                label: Text(
                  isArabic ? 'إضافة فيديو' : 'Add Video',
                  style: const TextStyle(fontSize: 18),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 48,
                    vertical: 20,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  OutlinedButton.icon(
                    onPressed: _pickVideoFromCamera,
                    icon: const Icon(Icons.videocam),
                    label: Text(isArabic ? 'تصوير' : 'Record'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  OutlinedButton.icon(
                    onPressed: _pickVideoFromGallery,
                    icon: const Icon(Icons.video_library),
                    label: Text(isArabic ? 'المعرض' : 'Gallery'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
