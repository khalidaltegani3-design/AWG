import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:animations/animations.dart';
import 'package:provider/provider.dart';
import 'package:zoli_chat/screens/blinks_screen.dart';
import 'package:zoli_chat/screens/calls_screen.dart';
import 'package:zoli_chat/screens/new_chat_screen.dart';
import 'package:zoli_chat/screens/on_call_screen.dart';
import 'package:zoli_chat/screens/settings_screen.dart';
import 'package:zoli_chat/screens/status_screen.dart';
import 'package:zoli_chat/providers/language_provider.dart';

import 'chat_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const ChatsList(),
    const CallsScreen(),
    const StatusScreen(),
    const BlinksScreen(),
    const SettingsScreen(),
  ];

  List<String> _getTitles(bool isArabic) {
    return [
      'Zoli Chat',
      isArabic ? 'المكالمات' : 'Calls',
      isArabic ? 'الحالة' : 'Status',
      isArabic ? 'رمشات' : 'Blinks',
      isArabic ? 'الإعدادات' : 'Settings',
    ];
  }

  List<BottomNavigationBarItem> _getNavItems(bool isArabic) {
    return [
      BottomNavigationBarItem(
        icon: const Icon(Ionicons.chatbubbles_outline),
        activeIcon: const Icon(Ionicons.chatbubbles),
        label: isArabic ? 'المحادثات' : 'Chats',
      ),
      BottomNavigationBarItem(
        icon: const Icon(Ionicons.call_outline),
        activeIcon: const Icon(Ionicons.call),
        label: isArabic ? 'المكالمات' : 'Calls',
      ),
      BottomNavigationBarItem(
        icon: const Icon(Ionicons.pulse_outline),
        activeIcon: const Icon(Ionicons.pulse),
        label: isArabic ? 'الحالة' : 'Status',
      ),
      BottomNavigationBarItem(
        icon: const Icon(Ionicons.videocam_outline),
        activeIcon: const Icon(Ionicons.videocam),
        label: isArabic ? 'رمشات' : 'Blinks',
      ),
      BottomNavigationBarItem(
        icon: const Icon(Ionicons.settings_outline),
        activeIcon: const Icon(Ionicons.settings),
        label: isArabic ? 'الإعدادات' : 'Settings',
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';
    final titles = _getTitles(isArabic);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          titles[_currentIndex],
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: theme.primaryColor,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Ionicons.search),
            onPressed: () {
              // TODO: Implement search functionality
            },
          ),
          IconButton(
            icon: const Icon(Ionicons.ellipsis_vertical),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: PageTransitionSwitcher(
        duration: const Duration(milliseconds: 300),
        transitionBuilder: (child, primaryAnimation, secondaryAnimation) {
          return FadeThroughTransition(
            animation: primaryAnimation,
            secondaryAnimation: secondaryAnimation,
            child: child,
          );
        },
        child: _screens[_currentIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: theme.primaryColor,
        unselectedItemColor: Colors.grey,
        items: _getNavItems(isArabic),
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const NewChatScreen()),
                );
              },
              backgroundColor: theme.primaryColor,
              child: const Icon(
                Ionicons.chatbubble_ellipses_outline,
                color: Colors.white,
              ),
            )
          : null,
    );
  }
}

class ChatsList extends StatelessWidget {
  const ChatsList({super.key});

  @override
  Widget build(BuildContext context) {
    // قائمة وهمية لتجربة التصميم
    final List<Map<String, dynamic>> mockChats = [
      // The list is now empty
    ];

    if (mockChats.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Ionicons.chatbubbles_outline,
              size: 80,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 20),
            Text(
              'No Chats Yet',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Tap the chat bubble icon below to start a new conversation.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.grey.shade500),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      itemCount: mockChats.length,
      itemBuilder: (context, index) {
        final chat = mockChats[index];
        return OpenContainer(
          transitionDuration: const Duration(milliseconds: 400),
          closedBuilder: (context, action) {
            return ListTile(
              leading: Hero(
                tag: 'avatar_${chat['uid']}',
                child: CircleAvatar(
                  backgroundImage: NetworkImage(chat['avatarUrl']),
                  backgroundColor: Theme.of(context).primaryColor,
                ),
              ),
              title: Text(chat['email']),
              subtitle: Text(chat['lastMessage']),
              trailing: Text(chat['timestamp']),
              onTap: action,
            );
          },
          openBuilder: (context, action) {
            return ChatScreen(
              peerId: chat['uid'],
              peerName: chat['email'],
              peerAvatar: chat['avatarUrl'],
            );
          },
        );
      },
    );

    /*
    // الكود الأصلي لجلب المستخدمين من Firebase
    final authService = Provider.of<AuthService>(context, listen: false);
    final userService = UserService();

    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: userService.getUsers(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(
            child: Text('Something went wrong'),
          );
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        final users = snapshot.data!;
        final currentUser = FirebaseAuth.instance.currentUser;

        return ListView.builder(
          itemCount: users.length,
          itemBuilder: (context, index) {
            final user = users[index];
            if (user['uid'] == currentUser?.uid) {
              return const SizedBox.shrink(); // Don't show current user
            }
            return ListTile(
              leading: CircleAvatar(
                backgroundColor: Theme.of(context).primaryColor,
                child: Text(
                  user['email'][0].toUpperCase(),
                  style: const TextStyle(color: Colors.white),
                ),
              ),
              title: Text(user['email']),
              subtitle: const Text("Last message..."),
              trailing: const Text("10:30 AM"),
              onTap: () {
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(
                //     builder: (context) => ChatScreen(
                //       otherUserId: user['uid'],
                //       otherUserEmail: user['email'],
                //     ),
                //   ),
                // );
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Chat feature temporarily disabled')),
                );
              },
            );
          },
        );
      },
    );
    */
  }
}
