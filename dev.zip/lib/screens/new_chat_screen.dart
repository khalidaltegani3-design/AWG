import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:provider/provider.dart';
import 'package:zoli_chat/services/user_service.dart';
import 'package:zoli_chat/screens/chat_screen.dart';
import 'package:zoli_chat/models/user_model.dart';

class NewChatScreen extends StatefulWidget {
  const NewChatScreen({super.key});

  @override
  State<NewChatScreen> createState() => _NewChatScreenState();
}

class _NewChatScreenState extends State<NewChatScreen> {
  final _searchController = TextEditingController();
  Stream<List<AppUser>>? _usersStream;
  List<Contact> _deviceContacts = [];
  bool _isLoadingContacts = true;

  @override
  void initState() {
    super.initState();
    _loadDeviceContacts();
    final userService = Provider.of<UserService>(context, listen: false);
    _usersStream = userService.getUsersStream();
    _searchController.addListener(() {
      setState(() {});
    });
  }

  Future<void> _loadDeviceContacts() async {
    try {
      if (await FlutterContacts.requestPermission()) {
        final contacts = await FlutterContacts.getContacts(withProperties: true);
        setState(() {
          _deviceContacts = contacts;
          _isLoadingContacts = false;
        });
      } else {
        setState(() {
          _isLoadingContacts = false;
        });
      }
    } catch (e) {
      print('Error loading contacts: $e');
      setState(() {
        _isLoadingContacts = false;
      });
    }
  }

  bool _isUserInContacts(AppUser user) {
    if (_deviceContacts.isEmpty) return false;
    
    final userPhone = user.phoneNumber.replaceAll(RegExp(r'[^\d+]'), '');
    
    for (var contact in _deviceContacts) {
      if (contact.phones.isNotEmpty) {
        for (var phone in contact.phones) {
          final contactPhone = phone.number.replaceAll(RegExp(r'[^\d+]'), '');
          
          if (contactPhone.length >= 9 && userPhone.length >= 9) {
            final contactLast9 = contactPhone.substring(contactPhone.length - 9);
            final userLast9 = userPhone.substring(userPhone.length - 9);
            
            if (contactLast9 == userLast9) return true;
          }
          
          if (contactPhone == userPhone) return true;
        }
      }
    }
    
    return false;
  }

  String _getContactName(AppUser user) {
    if (_deviceContacts.isEmpty) return user.displayName;
    
    final userPhone = user.phoneNumber.replaceAll(RegExp(r'[^\d+]'), '');
    
    for (var contact in _deviceContacts) {
      if (contact.phones.isNotEmpty) {
        for (var phone in contact.phones) {
          final contactPhone = phone.number.replaceAll(RegExp(r'[^\d+]'), '');
          
          if (contactPhone.length >= 9 && userPhone.length >= 9) {
            final contactLast9 = contactPhone.substring(contactPhone.length - 9);
            final userLast9 = userPhone.substring(userPhone.length - 9);
            
            if (contactLast9 == userLast9) {
              return contact.displayName;
            }
          }
          
          if (contactPhone == userPhone) {
            return contact.displayName;
          }
        }
      }
    }
    
    return user.displayName;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Chat'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(kToolbarHeight),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search for friends...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide.none,
                ),
                filled: true,
              ),
            ),
          ),
        ),
      ),
      body: _isLoadingContacts
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Loading contacts...'),
                ],
              ),
            )
          : StreamBuilder<List<AppUser>>(
              stream: _usersStream,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text('No users found.'));
                }

                final allUsers = snapshot.data!;
                
                // ✅ Only show users who are in device contacts AND have the app
                final contactUsers = allUsers.where((user) => _isUserInContacts(user)).toList();

                if (contactUsers.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24.0),
                      child: Text(
                        'No contacts using Zoli Chat found.\n\nInvite your friends to join!',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  );
                }

                final filteredUsers = _searchController.text.isEmpty
                    ? contactUsers
                    : contactUsers.where((user) {
                        final contactName = _getContactName(user).toLowerCase();
                        final searchQuery = _searchController.text.toLowerCase();
                        
                        return contactName.contains(searchQuery) ||
                               user.phoneNumber.contains(searchQuery);
                      }).toList();

                if (filteredUsers.isEmpty) {
                  return const Center(
                    child: Text('No matching contacts found.'),
                  );
                }

                return ListView.builder(
                  itemCount: filteredUsers.length,
                  itemBuilder: (context, index) {
                    final user = filteredUsers[index];
                    final contactName = _getContactName(user);

                    return ListTile(
                      leading: CircleAvatar(
                        child: Text(
                          contactName.isNotEmpty ? contactName[0].toUpperCase() : '?',
                        ),
                      ),
                      title: Text(contactName),
                      subtitle: Text(user.phoneNumber),
                      trailing: const Icon(Icons.chat_bubble_outline, size: 20),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ChatScreen(
                              peerId: user.uid,
                              peerAvatar: '',
                              peerName: contactName,
                            ),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
    );
  }
}
