import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:path_provider/path_provider.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/native_shorts.dart';
import '../services/video_processing_service.dart';
import '../services/ramshat_service.dart';
import '../providers/language_provider.dart';

class VideoEditorScreen extends StatefulWidget {
  final File videoFile;

  const VideoEditorScreen({Key? key, required this.videoFile}) : super(key: key);

  @override
  State<VideoEditorScreen> createState() => _VideoEditorScreenState();
}

class _VideoEditorScreenState extends State<VideoEditorScreen> {
  VideoPlayerController? _controller;
  final RamshatService _ramshatService = RamshatService();
  final VideoProcessingService _processingService = VideoProcessingService();

  // Video properties
  int _videoDurationMs = 0;
  int _trimStartMs = 0;
  int _trimEndMs = 0;

  // UI state
  bool _isLoading = false;
  bool _isUploading = false;
  double _uploadProgress = 0.0;
  String _statusMessage = '';

  // Controllers
  final TextEditingController _titleController = TextEditingController();
  String _visibility = 'public';

  @override
  void initState() {
    super.initState();
    _initializeVideo();
  }

  Future<void> _initializeVideo() async {
    _controller = VideoPlayerController.file(widget.videoFile);
    await _controller!.initialize();

    setState(() {
      _videoDurationMs = _controller!.value.duration.inMilliseconds;
      _trimEndMs = _videoDurationMs;
    });

    _controller!.setLooping(true);
    _controller!.play();
  }

  @override
  void dispose() {
    _controller?.dispose();
    _titleController.dispose();
    super.dispose();
  }

  Future<void> _processAndUpload() async {
    if (_titleController.text.trim().isEmpty) {
      _showError('يرجى إدخال عنوان للرمشة');
      return;
    }

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      _showError('يجب تسجيل الدخول أولاً');
      return;
    }

    setState(() {
      _isLoading = true;
      _statusMessage = 'جارٍ المعالجة...';
    });

    try {
      // 1. Trim video if needed
      String processedVideoPath = widget.videoFile.path;
      
      if (_trimStartMs > 0 || _trimEndMs < _videoDurationMs) {
        setState(() => _statusMessage = 'جارٍ قص الفيديو...');
        
        final tempDir = await getTemporaryDirectory();
        final timestamp = DateTime.now().millisecondsSinceEpoch;
        final trimmedPath = '${tempDir.path}/trimmed_$timestamp.mp4';
        
        try {
          await NativeShorts.trim(
            widget.videoFile.path,
            trimmedPath,
            _trimStartMs,
            _trimEndMs,
          );
          processedVideoPath = trimmedPath;
        } catch (e) {
          debugPrint('Trim failed, using original video: $e');
          // Continue with original video if trim fails
        }
      }

      // 2. Generate thumbnail
      setState(() => _statusMessage = 'جارٍ إنشاء الصورة المصغرة...');
      String? thumbnailPath;
      
      try {
        thumbnailPath = await _processingService.generateThumbnail(
          videoPath: processedVideoPath,
          timeMs: _trimStartMs + 1000, // 1 second after start
        );
      } catch (e) {
        debugPrint('Thumbnail generation failed: $e');
        // Continue without thumbnail
      }

      // 3. Upload video to Firebase Storage
      setState(() {
        _isUploading = true;
        _statusMessage = 'جارٍ رفع الفيديو...';
        _uploadProgress = 0.0;
      });

      final videoUrl = await _uploadVideoToStorage(
        File(processedVideoPath),
        user.uid,
      );

      // 4. Upload thumbnail if exists
      String? thumbUrl;
      if (thumbnailPath != null) {
        setState(() => _statusMessage = 'جارٍ رفع الصورة المصغرة...');
        thumbUrl = await _uploadThumbnailToStorage(
          File(thumbnailPath),
          user.uid,
        );
      }

      // 5. Create Ramsha document in Firestore
      setState(() => _statusMessage = 'جارٍ حفظ البيانات...');

      final ramshaId = await _ramshatService.createRamsha(
        uid: user.uid,
        title: _titleController.text.trim(),
        durationMs: _trimEndMs - _trimStartMs,
        videoUrl: videoUrl,
        thumbUrl: thumbUrl,
        visibility: _visibility,
        transcodeProfile: 'feed-720p',
        region: 'QA',
        metadata: {
          'originalFileName': widget.videoFile.path.split('/').last,
          'trimmed': _trimStartMs > 0 || _trimEndMs < _videoDurationMs,
        },
      );

      // Clean up temp files
      if (processedVideoPath != widget.videoFile.path) {
        try {
          await File(processedVideoPath).delete();
        } catch (e) {
          debugPrint('Failed to delete temp video: $e');
        }
      }
      
      if (thumbnailPath != null) {
        try {
          await File(thumbnailPath).delete();
        } catch (e) {
          debugPrint('Failed to delete temp thumbnail: $e');
        }
      }

      setState(() {
        _isLoading = false;
        _isUploading = false;
      });

      if (!mounted) return;

      // Show success and return
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ تم رفع الرمشة بنجاح!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );

      Navigator.of(context).pop(ramshaId);
    } catch (e) {
      setState(() {
        _isLoading = false;
        _isUploading = false;
      });
      _showError('فشل رفع الرمشة: $e');
    }
  }

  Future<String> _uploadVideoToStorage(File videoFile, String uid) async {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final fileName = 'ramsha_$timestamp.mp4';
    final storageRef = FirebaseStorage.instance
        .ref()
        .child('ramshat/$uid/$fileName');

    final uploadTask = storageRef.putFile(videoFile);

    uploadTask.snapshotEvents.listen((snapshot) {
      final progress = snapshot.bytesTransferred / snapshot.totalBytes;
      setState(() => _uploadProgress = progress);
    });

    await uploadTask;
    return await storageRef.getDownloadURL();
  }

  Future<String> _uploadThumbnailToStorage(File thumbFile, String uid) async {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final fileName = 'thumb_$timestamp.png';
    final storageRef = FirebaseStorage.instance
        .ref()
        .child('ramshat/$uid/thumbnails/$fileName');

    await storageRef.putFile(thumbFile);
    return await storageRef.getDownloadURL();
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  String _formatDuration(int milliseconds) {
    final duration = Duration(milliseconds: milliseconds);
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '$minutes:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'تحرير الرمشة' : 'Edit Ramsha'),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
      ),
      body: _controller == null || !_controller!.value.isInitialized
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Video preview
                  AspectRatio(
                    aspectRatio: _controller!.value.aspectRatio,
                    child: VideoPlayer(_controller!),
                  ),
                  const SizedBox(height: 20),

                  // Title input
                  TextField(
                    controller: _titleController,
                    decoration: InputDecoration(
                      labelText: isArabic ? 'عنوان الرمشة' : 'Ramsha Title',
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.title),
                    ),
                    maxLength: 100,
                  ),
                  const SizedBox(height: 16),

                  // Visibility selector
                  DropdownButtonFormField<String>(
                    value: _visibility,
                    decoration: InputDecoration(
                      labelText: isArabic ? 'الخصوصية' : 'Visibility',
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.visibility),
                    ),
                    items: [
                      DropdownMenuItem(
                        value: 'public',
                        child: Text(isArabic ? 'عام' : 'Public'),
                      ),
                      DropdownMenuItem(
                        value: 'friends',
                        child: Text(isArabic ? 'الأصدقاء' : 'Friends'),
                      ),
                      DropdownMenuItem(
                        value: 'private',
                        child: Text(isArabic ? 'خاص' : 'Private'),
                      ),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => _visibility = value);
                      }
                    },
                  ),
                  const SizedBox(height: 20),

                  // Trim section
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isArabic ? 'قص الفيديو' : 'Trim Video',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      isArabic ? 'البداية' : 'Start',
                                      style: const TextStyle(fontSize: 12),
                                    ),
                                    Text(
                                      _formatDuration(_trimStartMs),
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(Icons.arrow_forward),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      isArabic ? 'النهاية' : 'End',
                                      style: const TextStyle(fontSize: 12),
                                    ),
                                    Text(
                                      _formatDuration(_trimEndMs),
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          // Start slider
                          Slider(
                            value: _trimStartMs.toDouble(),
                            min: 0,
                            max: _videoDurationMs.toDouble(),
                            divisions: _videoDurationMs ~/ 100,
                            label: _formatDuration(_trimStartMs),
                            onChanged: (value) {
                              setState(() {
                                _trimStartMs = value.toInt();
                                if (_trimStartMs >= _trimEndMs) {
                                  _trimStartMs = _trimEndMs - 1000;
                                }
                                _controller?.seekTo(
                                  Duration(milliseconds: _trimStartMs),
                                );
                              });
                            },
                          ),
                          // End slider
                          Slider(
                            value: _trimEndMs.toDouble(),
                            min: 0,
                            max: _videoDurationMs.toDouble(),
                            divisions: _videoDurationMs ~/ 100,
                            label: _formatDuration(_trimEndMs),
                            onChanged: (value) {
                              setState(() {
                                _trimEndMs = value.toInt();
                                if (_trimEndMs <= _trimStartMs) {
                                  _trimEndMs = _trimStartMs + 1000;
                                }
                                _controller?.seekTo(
                                  Duration(milliseconds: _trimEndMs),
                                );
                              });
                            },
                          ),
                          Text(
                            '${isArabic ? 'المدة' : 'Duration'}: ${_formatDuration(_trimEndMs - _trimStartMs)}',
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Status message
                  if (_isLoading || _isUploading) ...[
                    Text(
                      _statusMessage,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 12),
                    if (_isUploading)
                      Column(
                        children: [
                          LinearProgressIndicator(value: _uploadProgress),
                          const SizedBox(height: 8),
                          Text(
                            '${(_uploadProgress * 100).toInt()}%',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      )
                    else
                      const CircularProgressIndicator(),
                    const SizedBox(height: 20),
                  ],

                  // Upload button
                  ElevatedButton.icon(
                    onPressed: _isLoading ? null : _processAndUpload,
                    icon: _isLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                Colors.white,
                              ),
                            ),
                          )
                        : const Icon(Icons.cloud_upload),
                    label: Text(
                      _isLoading
                          ? (isArabic ? 'جارٍ الرفع...' : 'Uploading...')
                          : (isArabic ? 'رفع الرمشة' : 'Upload Ramsha'),
                      style: const TextStyle(fontSize: 16),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).primaryColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
