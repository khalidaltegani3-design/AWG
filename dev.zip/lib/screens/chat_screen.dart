import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:ionicons/ionicons.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:record/record.dart';
import 'package:provider/provider.dart';
import 'package:path_provider/path_provider.dart';
// import 'package:emoji_picker_flutter/emoji_picker_flutter.dart'; // معطل مؤقتاً
import 'package:zoli_chat/screens/contacts_screen.dart';
import 'package:zoli_chat/screens/profile_screen.dart';
import 'package:zoli_chat/screens/settings_screen.dart';
import 'package:zoli_chat/services/call_service.dart';
import 'package:zoli_chat/providers/language_provider.dart';
// import 'package:zoli_chat/screens/reels_screen.dart';

// import '../services/auth_service.dart';
// import '../services/chat_service.dart';

class ChatScreen extends StatefulWidget {
  final String peerId;
  final String peerAvatar;
  final String peerName;

  const ChatScreen({
    super.key,
    required this.peerId,
    required this.peerAvatar,
    required this.peerName,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _messageController = TextEditingController();
  // final _chatService = ChatService();
  final _picker = ImagePicker();
  late final AudioRecorder _audioRecorder;
  final CallService _callService = CallService(); // Instantiate the service
  bool _hasText = false;
  bool _isRecording = false;
  bool _showEmojiPicker = false; // للتحكم بظهور emoji picker
  String? _replyingTo; // للرد على رسالة

  // Mock user ID for development
  final String _mockCurrentUserId = "currentUser_mock_id";

  // Mock messages list
  final List<Map<String, dynamic>> _mockMessages = [
    // The list is now empty
  ];

  @override
  void initState() {
    super.initState();
    _audioRecorder = AudioRecorder();
    _messageController.addListener(() {
      setState(() {
        _hasText = _messageController.text.isNotEmpty;
      });
    });
  }

  void _sendMessage() async {
    if (_messageController.text.isNotEmpty) {
      // Temporarily add message to mock list for UI feedback
      setState(() {
        _mockMessages.insert(0, {
          'senderId': _mockCurrentUserId,
          'message': _messageController.text,
          'timestamp': DateTime.now(),
          'type': 'text',
          'status': 'sent',
          'replyTo': _replyingTo, // إضافة الرسالة المُردود عليها
        });
      });
      print("Sending message (mock): ${_messageController.text}");
      _messageController.clear();
      setState(() {
        _replyingTo = null; // إلغاء الرد
      });
    }
  }

  void _showMessageOptions(
    BuildContext context,
    Map<String, dynamic> message,
    bool isArabic,
  ) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (BuildContext bc) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).scaffoldBackgroundColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: const Icon(Ionicons.arrow_undo_outline),
                  title: Text(isArabic ? 'رد' : 'Reply'),
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _replyingTo = message['message'];
                    });
                  },
                ),
                ListTile(
                  leading: const Icon(Ionicons.arrow_redo_outline),
                  title: Text(isArabic ? 'إعادة توجيه' : 'Forward'),
                  onTap: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          isArabic
                              ? 'سيتم إضافة ميزة إعادة التوجيه قريباً'
                              : 'Forward feature coming soon',
                        ),
                      ),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Ionicons.copy_outline),
                  title: Text(isArabic ? 'نسخ' : 'Copy'),
                  onTap: () {
                    Navigator.pop(context);
                    if (message['type'] == 'text') {
                      Clipboard.setData(
                        ClipboardData(text: message['message']),
                      );
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            isArabic ? 'تم النسخ' : 'Copied to clipboard',
                          ),
                          duration: const Duration(seconds: 1),
                        ),
                      );
                    }
                  },
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showChatMenu(BuildContext context, bool isArabic) {
    showMenu(
      context: context,
      position: RelativeRect.fromLTRB(
        MediaQuery.of(context).size.width,
        kToolbarHeight,
        0,
        0,
      ),
      items: [
        PopupMenuItem(
          child: Row(
            children: [
              const Icon(Ionicons.people_outline),
              const SizedBox(width: 12),
              Text(isArabic ? 'مجموعة جديدة' : 'New Group'),
            ],
          ),
          onTap: () {
            Future.delayed(Duration.zero, () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ContactsScreen()),
              );
            });
          },
        ),
        PopupMenuItem(
          child: Row(
            children: [
              const Icon(Ionicons.settings_outline),
              const SizedBox(width: 12),
              Text(isArabic ? 'الإعدادات' : 'Settings'),
            ],
          ),
          onTap: () {
            Future.delayed(Duration.zero, () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const SettingsScreen()),
              );
            });
          },
        ),
      ],
    );
  }

  void _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();

    if (result != null) {
      // For now, just print the path and add a mock message
      setState(() {
        _mockMessages.insert(0, {
          'senderId': _mockCurrentUserId,
          'message': 'File: ${result.files.single.name}',
          'timestamp': DateTime.now(),
          'type': 'text', // Or a new 'file' type
          'status': 'sent',
        });
      });
      print("File picked: ${result.files.single.path}");
    } else {
      // User canceled the picker
      print("User canceled file picking.");
    }
  }

  Future<void> _startRecording() async {
    try {
      if (await _audioRecorder.hasPermission()) {
        // Get temporary directory for the recording
        final directory = await getTemporaryDirectory();
        final path =
            '${directory.path}/audio_${DateTime.now().millisecondsSinceEpoch}.m4a';

        await _audioRecorder.start(const RecordConfig(), path: path);
        setState(() {
          _isRecording = true;
        });
        print("Recording started at: $path");
      } else {
        print("Microphone permission not granted");
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Microphone permission required')),
          );
        }
      }
    } catch (e) {
      print("Error starting recording: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to start recording: $e')),
        );
      }
    }
  }

  Future<void> _stopRecording() async {
    try {
      final path = await _audioRecorder.stop();
      setState(() {
        _isRecording = false;
      });

      if (path != null && path.isNotEmpty) {
        setState(() {
          _mockMessages.insert(0, {
            'senderId': _mockCurrentUserId,
            'message': 'Voice Message', // Placeholder
            'timestamp': DateTime.now(),
            'type': 'audio', // New message type
            'status': 'sent',
            'path': path, // Store path for potential playback
          });
        });
        print("Recording stopped, file saved at: $path");

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Voice message recorded'),
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        print("Recording path is null or empty");
      }
    } catch (e) {
      print("Error stopping recording: $e");
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Failed to stop recording: $e')));
      }
    }
  }

  void _sendImage() async {
    // Show a dialog to choose between camera and gallery
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Ionicons.camera_outline),
                title: const Text('Camera'),
                onTap: () async {
                  Navigator.of(context).pop();
                  final pickedFile = await _picker.pickImage(
                    source: ImageSource.camera,
                  );
                  if (pickedFile != null) {
                    // For now, just add a mock image. In a real app, you'd upload this.
                    setState(() {
                      _mockMessages.insert(0, {
                        'senderId': _mockCurrentUserId,
                        'message':
                            'https://picsum.photos/seed/new_camera_image/400/600',
                        'timestamp': DateTime.now(),
                        'type': 'image',
                        'status': 'sent',
                      });
                    });
                    print("Image picked from camera: ${pickedFile.path}");
                  }
                },
              ),
              ListTile(
                leading: const Icon(Ionicons.images_outline),
                title: const Text('Gallery'),
                onTap: () async {
                  Navigator.of(context).pop();
                  final pickedFile = await _picker.pickImage(
                    source: ImageSource.gallery,
                  );
                  if (pickedFile != null) {
                    // For now, just add a mock image.
                    setState(() {
                      _mockMessages.insert(0, {
                        'senderId': _mockCurrentUserId,
                        'message':
                            'https://picsum.photos/seed/new_gallery_image/400/600',
                        'timestamp': DateTime.now(),
                        'type': 'image',
                        'status': 'sent',
                      });
                    });
                    print("Image picked from gallery: ${pickedFile.path}");
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    _audioRecorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // final authService = Provider.of<AuthService>(context);
    final theme = Theme.of(context);
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    return Scaffold(
      appBar: AppBar(
        backgroundColor: theme.primaryColor,
        foregroundColor: Colors.white,
        elevation: 1,
        title: Row(
          children: [
            GestureDetector(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (context) => Dialog(
                    child: Stack(
                      alignment: Alignment.topRight,
                      children: [
                        Image.network(
                          'https://picsum.photos/seed/${widget.peerId}/800',
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.white),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
              child: Hero(
                tag: 'avatar_${widget.peerId}',
                child: CircleAvatar(
                  // Placeholder for profile picture
                  backgroundImage: NetworkImage(
                    'https://picsum.photos/seed/${widget.peerId}/200',
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        ProfileScreen(username: widget.peerName),
                  ),
                );
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.peerName,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    isArabic ? 'متصل' : 'Online',
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w300,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Ionicons.videocam_outline),
            onPressed: () {
              // Video call action
              print("Starting video call with ${widget.peerName}");
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    isArabic
                        ? 'ميزة مكالمات الفيديو معطلة مؤقتاً'
                        : 'Video call feature is temporarily disabled.',
                  ),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Ionicons.call_outline),
            onPressed: () {
              // Voice call action
              print("Starting voice call with ${widget.peerName}");
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    isArabic
                        ? 'ميزة المكالمات الصوتية معطلة مؤقتاً'
                        : 'Voice call feature is temporarily disabled.',
                  ),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Ionicons.ellipsis_vertical),
            onPressed: () => _showChatMenu(context, isArabic),
          ),
        ],
      ),
      body: Stack(
        children: [
          Center(
            child: Opacity(
              opacity: 0.1,
              child: Image.asset(
                'assets/images/auth_logo.png',
                width: MediaQuery.of(context).size.width * 0.7,
                fit: BoxFit.contain,
              ),
            ),
          ),
          Column(
            children: [
              Expanded(
                child: ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(8.0),
                  itemCount: _mockMessages.length,
                  itemBuilder: (context, index) {
                    final message = _mockMessages[index];
                    final isMe = message['senderId'] == _mockCurrentUserId;
                    final timestamp = message['timestamp'] as DateTime;

                    return Align(
                      alignment: isMe
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Column(
                        crossAxisAlignment: isMe
                            ? CrossAxisAlignment.end
                            : CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            onLongPress: () =>
                                _showMessageOptions(context, message, isArabic),
                            child: Container(
                              margin: const EdgeInsets.symmetric(
                                vertical: 4,
                                horizontal: 8,
                              ),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: isMe
                                    ? theme.primaryColor
                                    : theme.colorScheme.surface,
                                borderRadius: BorderRadius.circular(18),
                                border: isMe
                                    ? null
                                    : Border.all(
                                        color: theme.colorScheme.outline,
                                      ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // عرض الرسالة المُردود عليها إن وجدت
                                  if (message['replyTo'] != null) ...[
                                    Container(
                                      padding: const EdgeInsets.all(8),
                                      margin: const EdgeInsets.only(bottom: 8),
                                      decoration: BoxDecoration(
                                        color: Colors.black.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border(
                                          left: BorderSide(
                                            color: isMe
                                                ? Colors.white
                                                : theme.primaryColor,
                                            width: 3,
                                          ),
                                        ),
                                      ),
                                      child: Text(
                                        message['replyTo'],
                                        style: TextStyle(
                                          color: isMe
                                              ? Colors.white.withOpacity(0.8)
                                              : Colors.black.withOpacity(0.6),
                                          fontSize: 13,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                  // محتوى الرسالة
                                  message['type'] == 'text'
                                      ? Text(
                                          message['message'],
                                          style: TextStyle(
                                            color: isMe
                                                ? Colors.white
                                                : theme
                                                      .textTheme
                                                      .bodyLarge
                                                      ?.color,
                                          ),
                                        )
                                      : message['type'] == 'image'
                                      ? ClipRRect(
                                          borderRadius: BorderRadius.circular(
                                            12.0,
                                          ),
                                          child: TweenAnimationBuilder<double>(
                                            tween: Tween<double>(
                                              begin: 0.5,
                                              end: 1.0,
                                            ),
                                            duration: const Duration(
                                              milliseconds: 220,
                                            ),
                                            builder: (context, scale, child) {
                                              return Transform.scale(
                                                scale: scale,
                                                child: child,
                                              );
                                            },
                                            child: Image.network(
                                              message['message'],
                                            ),
                                          ),
                                        )
                                      : Row(
                                          // Basic UI for audio message
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Icon(
                                              Ionicons.play,
                                              color: isMe
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              'Voice Message',
                                              style: TextStyle(
                                                color: isMe
                                                    ? Colors.white
                                                    : Colors.black,
                                              ),
                                            ),
                                          ],
                                        ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12.0,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  "${timestamp.hour}:${timestamp.minute.toString().padLeft(2, '0')}",
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    fontSize: 12,
                                  ),
                                ),
                                if (isMe) ...[
                                  const SizedBox(width: 4),
                                  _buildStatusIcon(message['status']),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),

                /* StreamBuilder<QuerySnapshot>(
                  stream: _chatService.getMessages(
                      FirebaseAuth.instance.currentUser!.uid, widget.otherUserId),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return const Center(
                        child: Text('Something went wrong'),
                      );
                    }
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }

                    final messages = snapshot.data!.docs;

                    return ListView.builder(
                      reverse: true,
                      padding: const EdgeInsets.all(8.0),
                      itemCount: messages.length,
                      itemBuilder: (context, index) {
                        final message = messages[index];
                        final isMe =
                            message['senderId'] == FirebaseAuth.instance.currentUser!.uid;
                        final data = message.data() as Map<String, dynamic>;
                        final timestamp =
                            data.containsKey('timestamp') && data['timestamp'] != null
                                ? (data['timestamp'] as Timestamp).toDate()
                                : DateTime.now();

                        return Align(
                          alignment: isMe
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Column(
                            crossAxisAlignment: isMe
                                ? CrossAxisAlignment.end
                                : CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: const EdgeInsets.symmetric(
                                    vertical: 4, horizontal: 8),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: isMe
                                      ? theme.primaryColor
                                      : theme.colorScheme.surface,
                                  borderRadius: BorderRadius.circular(18),
                                  border: isMe
                                      ? null
                                      : Border.all(
                                          color: theme.colorScheme.outline),
                                ),
                                child: message['type'] == 'text'
                                    ? Text(
                                        message['message'],
                                        style: TextStyle(
                                          color: isMe
                                              ? Colors.white
                                              : theme.textTheme.bodyLarge?.color,
                                        ),
                                      )
                                    : Image.network(message['message']),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12.0),
                                child: Text(
                                  "${timestamp.hour}:${timestamp.minute.toString().padLeft(2, '0")}",
                                  style: theme.textTheme.bodyMedium
                                      ?.copyWith(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  },
                ), */
              ),
              // منطقة الرد على رسالة
              if (_replyingTo != null)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  color: theme.colorScheme.surface,
                  child: Row(
                    children: [
                      Container(
                        width: 4,
                        height: 40,
                        color: theme.primaryColor,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              isArabic ? 'الرد على' : 'Replying to',
                              style: TextStyle(
                                fontSize: 12,
                                color: theme.primaryColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _replyingTo!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 14,
                                color: theme.textTheme.bodyMedium?.color,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          setState(() {
                            _replyingTo = null;
                          });
                        },
                      ),
                    ],
                  ),
                ),
              _buildChatComposer(theme, isArabic),
              // Emoji Picker - معطل مؤقتاً بسبب مشاكل التوافق
              // if (_showEmojiPicker)
              //   SizedBox(
              //     height: 250,
              //     child: EmojiPicker(...),
              //   ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusIcon(String? status) {
    switch (status) {
      case 'sent':
        return const Icon(Ionicons.checkmark, size: 16, color: Colors.grey);
      case 'delivered':
        return const Icon(
          Ionicons.checkmark_done,
          size: 16,
          color: Colors.grey,
        );
      case 'read':
        return const Icon(
          Ionicons.checkmark_done,
          size: 16,
          color: Colors.blue,
        );
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildChatComposer(ThemeData theme, bool isArabic) {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
        color: Colors.white,
        child: Row(
          children: [
            // Clip (Attachment) Button
            IconButton(
              icon: Icon(Ionicons.attach, color: theme.iconTheme.color),
              onPressed: _pickFile,
            ),
            // Message Input Field
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14.0),
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _messageController,
                        decoration: InputDecoration(
                          hintText: isArabic
                              ? 'اكتب رسالة...'
                              : 'Type a message...',
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                    // Emoji Button - معطل مؤقتاً
                    // IconButton(
                    //   icon: Icon(
                    //     _showEmojiPicker ? Ionicons.close_outline : Ionicons.happy_outline,
                    //     color: theme.iconTheme.color,
                    //   ),
                    //   onPressed: () {
                    //     setState(() {
                    //       _showEmojiPicker = !_showEmojiPicker;
                    //     });
                    //     if (_showEmojiPicker) {
                    //       FocusScope.of(context).unfocus();
                    //     }
                    //   },
                    // ),
                    // Camera Button
                    IconButton(
                      icon: Icon(
                        Ionicons.camera_outline,
                        color: theme.iconTheme.color,
                      ),
                      onPressed: _sendImage,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Send / Mic Button
            AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeOut,
              child: GestureDetector(
                onLongPress: _startRecording,
                onLongPressUp: _stopRecording,
                child: CircleAvatar(
                  radius: 24,
                  backgroundColor: theme.primaryColor,
                  child: _isRecording
                      ? const Icon(Ionicons.stop, color: Colors.red)
                      : IconButton(
                          icon: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 150),
                            transitionBuilder: (child, animation) =>
                                ScaleTransition(scale: animation, child: child),
                            child: Icon(
                              _hasText ? Ionicons.send : Ionicons.mic,
                              key: ValueKey<bool>(_hasText),
                              color: Colors.white,
                            ),
                          ),
                          onPressed: _hasText ? _sendMessage : null,
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
