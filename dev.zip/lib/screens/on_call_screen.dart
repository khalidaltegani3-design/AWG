import 'dart:async';
import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

class OnCallScreen extends StatefulWidget {
  final String contactName;
  final String contactAvatarUrl;
  final bool isVideo;

  const OnCallScreen({
    super.key,
    required this.contactName,
    required this.contactAvatarUrl,
    this.isVideo = false,
  });

  @override
  State<OnCallScreen> createState() => _OnCallScreenState();
}

class _OnCallScreenState extends State<OnCallScreen> {
  late Timer _timer;
  int _callDurationInSeconds = 0;
  String _callStatus = 'Ringing...';
  bool _isMuted = false;
  bool _isSpeakerOn = false;

  @override
  void initState() {
    super.initState();
    // Simulate call connection after a few seconds
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _callStatus = '00:00';
          _startTimer();
        });
      }
    });
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _callDurationInSeconds++;
        _callStatus = _formatDuration(_callDurationInSeconds);
      });
    });
  }

  String _formatDuration(int seconds) {
    final minutes = (seconds / 60).floor().toString().padLeft(2, '0');
    final remainingSeconds = (seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$remainingSeconds';
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildContactInfo(),
            if (widget.isVideo) _buildVideoView(),
            _buildControls(),
          ],
        ),
      ),
    );
  }

  Widget _buildContactInfo() {
    return Padding(
      padding: const EdgeInsets.only(top: 60.0),
      child: Column(
        children: [
          CircleAvatar(
            radius: 60,
            backgroundImage: NetworkImage(widget.contactAvatarUrl),
          ),
          const SizedBox(height: 20),
          Text(
            widget.contactName,
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _callStatus,
            style: const TextStyle(fontSize: 18, color: Colors.white70),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoView() {
    // Placeholder for the local/remote video streams
    return Expanded(
      child: Container(
        margin: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.black26,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white30),
        ),
        child: const Center(
          child: Icon(
            Ionicons.videocam_off_outline,
            color: Colors.white70,
            size: 50,
          ),
        ),
      ),
    );
  }

  Widget _buildControls() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 40.0),
      child: AnimationLimiter(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: AnimationConfiguration.toStaggeredList(
            duration: const Duration(milliseconds: 375),
            childAnimationBuilder: (widget) => SlideAnimation(
              verticalOffset: 50.0,
              child: FadeInAnimation(child: widget),
            ),
            children: [
              _buildControlButton(
                icon: _isMuted
                    ? Ionicons.mic_off_outline
                    : Ionicons.mic_outline,
                label: 'Mute',
                onPressed: () => setState(() => _isMuted = !_isMuted),
                backgroundColor: _isMuted ? Colors.blue : Colors.white24,
              ),
              _buildControlButton(
                icon: Ionicons.call_outline,
                label: 'End Call',
                onPressed: () => Navigator.of(context).pop(),
                backgroundColor: Colors.red,
                iconColor: Colors.white,
                size: 70,
              ),
              _buildControlButton(
                icon: _isSpeakerOn
                    ? Ionicons.volume_high_outline
                    : Ionicons.volume_low_outline,
                label: 'Speaker',
                onPressed: () => setState(() => _isSpeakerOn = !_isSpeakerOn),
                backgroundColor: _isSpeakerOn ? Colors.blue : Colors.white24,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    Color backgroundColor = Colors.white24,
    Color iconColor = Colors.white,
    double size = 60,
  }) {
    return Column(
      children: [
        SizedBox(
          width: size,
          height: size,
          child: ElevatedButton(
            onPressed: onPressed,
            style: ElevatedButton.styleFrom(
              backgroundColor: backgroundColor,
              shape: const CircleBorder(),
              padding: EdgeInsets.zero,
            ),
            child: Icon(icon, color: iconColor, size: size * 0.5),
          ),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(color: Colors.white70)),
      ],
    );
  }
}
