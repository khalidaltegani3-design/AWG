import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../models/music_track.dart';
import '../providers/language_provider.dart';
import '../services/music_service.dart';
import '../services/spotify_service.dart';
import '../config/spotify_config.dart';
import 'package:cached_network_image/cached_network_image.dart';

/// شاشة اختيار موسيقى متقدمة مع دعم Spotify
class AdvancedMusicPickerScreen extends StatefulWidget {
  const AdvancedMusicPickerScreen({Key? key}) : super(key: key);

  @override
  State<AdvancedMusicPickerScreen> createState() =>
      _AdvancedMusicPickerScreenState();
}

class _AdvancedMusicPickerScreenState extends State<AdvancedMusicPickerScreen> {
  final MusicService _localMusicService = MusicService();
  final SpotifyService _spotifyService = SpotifyService();
  final AudioPlayer _audioPlayer = AudioPlayer();
  final TextEditingController _searchController = TextEditingController();

  List<MusicTrack> _tracks = [];
  List<MusicTrack> _filteredTracks = [];
  String _selectedGenre = 'All';
  bool _isLoading = true;
  MusicTrack? _currentPlayingTrack;
  bool _isPlaying = false;
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = Duration.zero;

  // مصدر الموسيقى
  MusicSource _musicSource = MusicSource.local;
  bool _spotifyAuthenticated = false;

  @override
  void initState() {
    super.initState();
    _initializeSpotify();
    _loadTracks();
    _setupAudioPlayer();
  }

  Future<void> _initializeSpotify() async {
    if (SpotifyConfig.isConfigured) {
      final success = await _spotifyService.authenticate();
      setState(() {
        _spotifyAuthenticated = success;
      });
    }
  }

  void _setupAudioPlayer() {
    _audioPlayer.positionStream.listen((position) {
      if (mounted) {
        setState(() {
          _currentPosition = position;
        });
      }
    });

    _audioPlayer.durationStream.listen((duration) {
      if (mounted && duration != null) {
        setState(() {
          _totalDuration = duration;
        });
      }
    });

    _audioPlayer.playerStateStream.listen((state) {
      if (mounted) {
        setState(() {
          _isPlaying = state.playing;
        });
      }
    });
  }

  Future<void> _loadTracks() async {
    setState(() => _isLoading = true);
    try {
      List<MusicTrack> tracks;

      if (_musicSource == MusicSource.local) {
        // مكتبة محلية
        tracks = await _localMusicService.searchTracks(
          _searchController.text,
          genre: _selectedGenre,
        );
      } else {
        // Spotify
        if (!_spotifyAuthenticated) {
          setState(() => _isLoading = false);
          _showError('الرجاء إعداد Spotify API أولاً');
          return;
        }

        if (_searchController.text.isNotEmpty) {
          tracks = await _spotifyService.searchTracks(_searchController.text);
        } else if (_selectedGenre == 'All') {
          tracks = await _spotifyService.getTrendingTracks();
        } else {
          tracks = await _spotifyService.searchByGenre(_selectedGenre);
        }
      }

      setState(() {
        _tracks = tracks;
        _filteredTracks = tracks;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      _showError('Error loading tracks: $e');
    }
  }

  void _searchTracks(String query) {
    _loadTracks();
  }

  Future<void> _playTrack(MusicTrack track) async {
    try {
      // Spotify يعطي preview 30 ثانية فقط
      if (track.audioUrl.isEmpty) {
        _showError('معاينة الصوت غير متاحة لهذا التراك');
        return;
      }

      if (_currentPlayingTrack?.id == track.id && _isPlaying) {
        await _audioPlayer.pause();
      } else {
        if (_currentPlayingTrack?.id != track.id) {
          await _audioPlayer.setUrl(track.audioUrl);
        }
        await _audioPlayer.play();
        setState(() {
          _currentPlayingTrack = track;
        });
      }
    } catch (e) {
      _showError('خطأ في التشغيل: $e');
    }
  }

  Future<void> _stopPlayback() async {
    await _audioPlayer.stop();
    setState(() {
      _currentPlayingTrack = null;
      _isPlaying = false;
      _currentPosition = Duration.zero;
    });
  }

  void _selectTrack(MusicTrack track) {
    _stopPlayback();
    Navigator.pop(context, track);
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _searchController.dispose();
    _spotifyService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          isArabic ? 'اختر موسيقى' : 'Choose Music',
          style: const TextStyle(color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () {
            _stopPlayback();
            Navigator.pop(context);
          },
        ),
        actions: [
          // زر تبديل المصدر
          PopupMenuButton<MusicSource>(
            icon: Icon(
              _musicSource == MusicSource.local
                  ? Ionicons.musical_notes
                  : Ionicons.musical_note,
              color: Colors.white,
            ),
            onSelected: (source) {
              if (source == MusicSource.spotify &&
                  !SpotifyConfig.isConfigured) {
                _showError(SpotifyConfig.configError);
                return;
              }

              if (source == MusicSource.spotify && !_spotifyAuthenticated) {
                _showError('فشل الاتصال بـ Spotify');
                return;
              }

              setState(() {
                _musicSource = source;
                _searchController.clear();
              });
              _loadTracks();
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: MusicSource.local,
                child: Row(
                  children: [
                    const Icon(Ionicons.musical_notes),
                    const SizedBox(width: 8),
                    Text(isArabic ? 'مكتبة محلية' : 'Local Library'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: MusicSource.spotify,
                enabled: SpotifyConfig.isConfigured && _spotifyAuthenticated,
                child: Row(
                  children: [
                    Icon(
                      Ionicons.musical_note,
                      color: _spotifyAuthenticated ? null : Colors.grey,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Spotify',
                      style: TextStyle(
                        color: _spotifyAuthenticated ? null : Colors.grey,
                      ),
                    ),
                    if (!_spotifyAuthenticated) ...[
                      const SizedBox(width: 8),
                      const Icon(Icons.warning, size: 16, color: Colors.orange),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // مؤشر المصدر
          Container(
            padding: const EdgeInsets.all(8),
            color: _musicSource == MusicSource.spotify
                ? const Color(0xFF1DB954).withOpacity(0.2) // Spotify Green
                : Colors.purple.withOpacity(0.2),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  _musicSource == MusicSource.local
                      ? Ionicons.musical_notes
                      : Ionicons.musical_note,
                  color: _musicSource == MusicSource.spotify
                      ? const Color(0xFF1DB954)
                      : Colors.purple,
                  size: 16,
                ),
                const SizedBox(width: 8),
                Text(
                  _musicSource == MusicSource.local
                      ? (isArabic
                            ? 'مكتبة محلية (10 تراكات)'
                            : 'Local Library (10 tracks)')
                      : 'Spotify ${isArabic ? '(ملايين التراكات)' : '(Millions of tracks)'}',
                  style: TextStyle(
                    color: _musicSource == MusicSource.spotify
                        ? const Color(0xFF1DB954)
                        : Colors.purple,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
                if (_musicSource == MusicSource.spotify) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      isArabic ? 'معاينة 30 ثانية' : '30s Preview',
                      style: const TextStyle(
                        color: Colors.orange,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),

          // شريط البحث
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: isArabic
                    ? (_musicSource == MusicSource.spotify
                          ? 'ابحث في Spotify...'
                          : 'ابحث في المكتبة...')
                    : (_musicSource == MusicSource.spotify
                          ? 'Search Spotify...'
                          : 'Search library...'),
                hintStyle: TextStyle(color: Colors.grey[600]),
                prefixIcon: Icon(Ionicons.search, color: Colors.grey[600]),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, color: Colors.grey),
                        onPressed: () {
                          _searchController.clear();
                          _loadTracks();
                        },
                      )
                    : null,
                filled: true,
                fillColor: Colors.grey[900],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: _searchTracks,
            ),
          ),

          // تصفية حسب النوع
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _musicSource == MusicSource.local
                  ? MusicService.genres.length
                  : _spotifyGenres.length,
              itemBuilder: (context, index) {
                final genre = _musicSource == MusicSource.local
                    ? MusicService.genres[index]
                    : _spotifyGenres[index];
                final isSelected = genre == _selectedGenre;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(genre),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        _selectedGenre = genre;
                      });
                      _loadTracks();
                    },
                    backgroundColor: Colors.grey[900],
                    selectedColor: _musicSource == MusicSource.spotify
                        ? const Color(0xFF1DB954)
                        : Colors.purple,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 16),

          // قائمة التراكات
          Expanded(
            child: _isLoading
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircularProgressIndicator(
                          color: _musicSource == MusicSource.spotify
                              ? const Color(0xFF1DB954)
                              : Colors.purple,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          isArabic
                              ? (_musicSource == MusicSource.spotify
                                    ? 'جاري البحث في Spotify...'
                                    : 'جاري التحميل...')
                              : (_musicSource == MusicSource.spotify
                                    ? 'Searching Spotify...'
                                    : 'Loading...'),
                          style: TextStyle(color: Colors.grey[500]),
                        ),
                      ],
                    ),
                  )
                : _filteredTracks.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _musicSource == MusicSource.spotify
                              ? Ionicons.musical_note
                              : Ionicons.musical_notes_outline,
                          size: 64,
                          color: Colors.grey[700],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          isArabic
                              ? 'لم يتم العثور على أغاني'
                              : 'No songs found',
                          style: TextStyle(
                            color: Colors.grey[500],
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _filteredTracks.length,
                    itemBuilder: (context, index) {
                      final track = _filteredTracks[index];
                      final isPlaying =
                          _currentPlayingTrack?.id == track.id && _isPlaying;
                      return _buildTrackItem(track, isPlaying, isArabic);
                    },
                  ),
          ),

          // مشغل الموسيقى
          if (_currentPlayingTrack != null) _buildMusicPlayer(isArabic),
        ],
      ),
    );
  }

  Widget _buildTrackItem(MusicTrack track, bool isPlaying, bool isArabic) {
    final themeColor = _musicSource == MusicSource.spotify
        ? const Color(0xFF1DB954)
        : Colors.purple;

    return InkWell(
      onTap: () => _selectTrack(track),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(12),
          border: isPlaying ? Border.all(color: themeColor, width: 2) : null,
        ),
        child: Row(
          children: [
            // صورة الغلاف
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: CachedNetworkImage(
                imageUrl: track.coverArtUrl,
                width: 60,
                height: 60,
                fit: BoxFit.cover,
                placeholder: (context, url) => Container(
                  color: Colors.grey[800],
                  child: const Center(
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
                errorWidget: (context, url, error) => Container(
                  color: Colors.grey[800],
                  child: Icon(
                    _musicSource == MusicSource.spotify
                        ? Ionicons.musical_note
                        : Ionicons.musical_note,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),

            // معلومات التراك
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    track.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    track.artist,
                    style: TextStyle(color: Colors.grey[400], fontSize: 14),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (_musicSource == MusicSource.spotify)
                        Icon(
                          Ionicons.musical_note,
                          size: 12,
                          color: themeColor,
                        ),
                      if (_musicSource == MusicSource.spotify)
                        const SizedBox(width: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: themeColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          track.genre,
                          style: TextStyle(color: themeColor, fontSize: 10),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        track.formattedDuration,
                        style: TextStyle(color: Colors.grey[500], fontSize: 12),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // زر التشغيل
            IconButton(
              icon: Icon(
                isPlaying ? Ionicons.pause_circle : Ionicons.play_circle,
                color: track.audioUrl.isEmpty ? Colors.grey : themeColor,
                size: 40,
              ),
              onPressed: track.audioUrl.isEmpty
                  ? null
                  : () => _playTrack(track),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMusicPlayer(bool isArabic) {
    final themeColor = _musicSource == MusicSource.spotify
        ? const Color(0xFF1DB954)
        : Colors.purple;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: CachedNetworkImage(
                    imageUrl: _currentPlayingTrack!.coverArtUrl,
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _currentPlayingTrack!.title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        _currentPlayingTrack!.artist,
                        style: TextStyle(color: Colors.grey[400], fontSize: 12),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(
                    _isPlaying ? Ionicons.pause : Ionicons.play,
                    color: Colors.white,
                  ),
                  onPressed: () => _playTrack(_currentPlayingTrack!),
                ),
                IconButton(
                  icon: const Icon(Ionicons.stop, color: Colors.white),
                  onPressed: _stopPlayback,
                ),
              ],
            ),
            const SizedBox(height: 8),
            Column(
              children: [
                SliderTheme(
                  data: SliderThemeData(
                    activeTrackColor: themeColor,
                    inactiveTrackColor: Colors.grey[800],
                    thumbColor: themeColor,
                    overlayColor: themeColor.withOpacity(0.2),
                    trackHeight: 3,
                  ),
                  child: Slider(
                    value: _currentPosition.inSeconds.toDouble(),
                    max: _totalDuration.inSeconds > 0
                        ? _totalDuration.inSeconds.toDouble()
                        : 1,
                    onChanged: (value) {
                      _audioPlayer.seek(Duration(seconds: value.toInt()));
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _formatDuration(_currentPosition),
                        style: TextStyle(color: Colors.grey[500], fontSize: 12),
                      ),
                      Text(
                        _formatDuration(_totalDuration),
                        style: TextStyle(color: Colors.grey[500], fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '$minutes:${seconds.toString().padLeft(2, '0')}';
  }

  // الأنواع لـ Spotify
  static const List<String> _spotifyGenres = [
    'All',
    'Pop',
    'Rock',
    'Hip-Hop',
    'Electronic',
    'Jazz',
    'Classical',
    'Country',
    'R&B',
    'Indie',
    'Latin',
    'Metal',
  ];
}

enum MusicSource { local, spotify }
