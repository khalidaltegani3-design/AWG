import 'package:animations/animations.dart';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/auth_service.dart';
import '../providers/language_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _countryCodeController = TextEditingController(text: '+');
  final _otpController = TextEditingController();

  String? _verificationId;
  bool _otpSent = false;
  bool _isLoading = false;

  void _sendOtp() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      
      // Show reCAPTCHA info dialog
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('يرجى إكمال التحقق الأمني... 🔒'),
            backgroundColor: Colors.blue,
            duration: Duration(seconds: 3),
          ),
        );
      }
      
      try {
        final authService = Provider.of<AuthService>(context, listen: false);
        final fullPhoneNumber =
            _countryCodeController.text + _phoneController.text;

        await authService.signInWithPhone(
          fullPhoneNumber,
          codeSent: (verificationId, forceResendingToken) {
            if (mounted) {
              setState(() {
                _verificationId = verificationId;
                _otpSent = true;
                _isLoading = false;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('تم إرسال الرمز بنجاح! ✅'),
                  backgroundColor: Colors.green,
                  duration: Duration(seconds: 2),
                ),
              );
            }
          },
          verificationFailed: (e) {
            if (mounted) {
              setState(() {
                _isLoading = false;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('فشل التحقق: ${e.message}'),
                  backgroundColor: Colors.red,
                  duration: const Duration(seconds: 4),
                ),
              );
            }
          },
        );
      } catch (e) {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('حدث خطأ: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }
  }

  void _verifyOtp() async {
    if (_formKey.currentState!.validate() && _verificationId != null) {
      setState(() {
        _isLoading = true;
      });
      
      try {
        final authService = Provider.of<AuthService>(context, listen: false);
        final user = await authService.verifyOtp(_verificationId!, _otpController.text);
        
        if (mounted) {
          if (user == null) {
            setState(() {
              _isLoading = false;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('الرمز غير صحيح! ❌'),
                backgroundColor: Colors.red,
              ),
            );
          } else {
            // On success, auth state listener will navigate.
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('تم تسجيل الدخول بنجاح! ✅'),
                backgroundColor: Colors.green,
              ),
            );
          }
        }
      } catch (e) {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('حدث خطأ: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _countryCodeController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.appLocale?.languageCode == 'ar';

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Image.asset('assets/images/auth_logo.png', height: 150),
                const SizedBox(height: 20),
                const Text(
                  'Zoli',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  isArabic ? 'أهلاً بك ...' : 'Welcome ...',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 22),
                ),
                const SizedBox(height: 16),
                Text(
                  _otpSent
                      ? (isArabic
                            ? 'أدخل رمز التحقق'
                            : 'Enter verification code')
                      : (isArabic
                            ? 'أدخل رقم هاتفك للمتابعة'
                            : 'Enter your phone number to continue'),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: theme.textTheme.bodyMedium?.color,
                  ),
                ),
                const SizedBox(height: 40),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  transitionBuilder: (child, animation) {
                    return SharedAxisTransition(
                      animation: animation,
                      secondaryAnimation: ReverseAnimation(animation),
                      transitionType: SharedAxisTransitionType.horizontal,
                      child: child,
                    );
                  },
                  child: _otpSent
                      ? _buildOtpInput(theme, isArabic)
                      : _buildPhoneInput(theme, isArabic),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _isLoading ? null : (_otpSent ? _verifyOtp : _sendOtp),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: theme.colorScheme.secondary,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          height: 24,
                          width: 24,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : Text(
                          _otpSent
                              ? (isArabic ? 'تحقق من الرمز' : 'Verify OTP')
                              : (isArabic ? 'إرسال الرمز' : 'Send OTP'),
                        ),
                ),
                if (_otpSent && !_isLoading)
                  TextButton(
                    onPressed: () => setState(() => _otpSent = false),
                    child: Text(isArabic ? 'تغيير الرقم؟' : 'Change number?'),
                  ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(
          'AWG Morgan',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.grey.shade400, fontSize: 12),
        ),
      ),
    );
  }

  Widget _buildPhoneInput(ThemeData theme, bool isArabic) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: theme.colorScheme.outline),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(
          children: [
            SizedBox(
              width: 80,
              child: TextFormField(
                controller: _countryCodeController,
                keyboardType: TextInputType.phone,
                textAlign: TextAlign.center,
                decoration: const InputDecoration(
                  hintText: '+1',
                  border: InputBorder.none,
                  counterText: '',
                ),
                maxLength: 4,
                validator: (value) {
                  if (value == null || !value.startsWith('+')) {
                    return isArabic
                        ? 'رمز دولة غير صالح'
                        : 'Invalid country code';
                  }
                  return null;
                },
              ),
            ),
            Container(width: 1, height: 30, color: theme.colorScheme.outline),
            Expanded(
              child: TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                textAlign: TextAlign.left,
                textDirection: TextDirection.ltr,
                decoration: InputDecoration(
                  hintText: isArabic ? 'رقم الهاتف' : 'Phone Number',
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return isArabic
                        ? 'الرجاء إدخال رقم الهاتف'
                        : 'Please enter a phone number';
                  }
                  return null;
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOtpInput(ThemeData theme, bool isArabic) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: TextFormField(
        controller: _otpController,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        style: const TextStyle(letterSpacing: 8),
        decoration: InputDecoration(
          labelText: isArabic ? 'رمز التحقق' : 'OTP Code',
          hintText: '------',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
        validator: (value) {
          if (value == null || value.length < 6) {
            return isArabic
                ? 'الرجاء إدخال رمز صالح'
                : 'Please enter a valid code';
          }
          return null;
        },
      ),
    );
  }
}
