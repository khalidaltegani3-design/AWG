/// إعدادات Spotify API
///
/// للحصول على Client ID و Client Secret:
/// 1. اذهب إلى: https://developer.spotify.com/dashboard
/// 2. سجل دخول أو أنشئ حساب
/// 3. اضغط "Create an App"
/// 4. أدخل اسم التطبيق ووصفه
/// 5. انسخ Client ID و Client Secret
/// 6. أضف Redirect URI: http://localhost:8888/callback
class SpotifyConfig {
  /// Client ID من Spotify Dashboard
  /// ⚠️ للإنتاج: استخدم Environment Variables
  static const String clientId = String.fromEnvironment(
    'SPOTIFY_CLIENT_ID',
    defaultValue: 'YOUR_SPOTIFY_CLIENT_ID',
  );

  /// Client Secret من Spotify Dashboard
  /// ⚠️ للإنتاج: استخدم Backend لإخفاء السر
  static const String clientSecret = String.fromEnvironment(
    'SPOTIFY_CLIENT_SECRET',
    defaultValue: 'YOUR_SPOTIFY_CLIENT_SECRET',
  );

  /// Redirect URI (يجب أن يكون مسجل في Spotify Dashboard)
  static const String redirectUri = 'http://localhost:8888/callback';

  /// Scopes المطلوبة
  static const List<String> scopes = [
    'user-read-email',
    'user-read-private',
    'playlist-read-private',
    'playlist-read-collaborative',
    'user-library-read',
    'user-top-read',
  ];

  /// التحقق من صحة الإعدادات
  static bool get isConfigured {
    return clientId != 'YOUR_SPOTIFY_CLIENT_ID' &&
        clientSecret != 'YOUR_SPOTIFY_CLIENT_SECRET' &&
        clientId.isNotEmpty &&
        clientSecret.isNotEmpty;
  }

  /// رسالة خطأ الإعداد
  static String get configError {
    if (!isConfigured) {
      return '''
⚠️ Spotify API غير مُعد!

الخطوات:
1. اذهب إلى: https://developer.spotify.com/dashboard
2. أنشئ تطبيق جديد
3. انسخ Client ID و Client Secret
4. أضفهما في lib/config/spotify_config.dart

أو استخدم Environment Variables:
flutter run --dart-define=SPOTIFY_CLIENT_ID=your_id --dart-define=SPOTIFY_CLIENT_SECRET=your_secret
''';
    }
    return '';
  }
}
