class AppUser {
  final String uid;
  final String displayName;
  final String phoneNumber;
  final String? photoURL;

  AppUser({
    required this.uid,
    required this.displayName,
    required this.phoneNumber,
    this.photoURL,
  });

  factory AppUser.fromMap(Map<String, dynamic> data, String uid) {
    return AppUser(
      uid: uid,
      displayName: data['displayName'] ?? '',
      phoneNumber: data['phoneNumber'] ?? '',
      photoURL: data['photoURL'],
    );
  }
}
