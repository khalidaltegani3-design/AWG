import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/music_track.dart';

/// خدمة SoundCloud API (غير رسمي)
/// ملاحظة: يستخدم Client ID عام - قد يتوقف في أي وقت
class SoundCloudService {
  // Client ID عام (قد يحتاج تحديث)
  // يمكن استخراجه من: https://soundcloud.com
  static const String _clientId = 'YOUR_CLIENT_ID_HERE';
  static const String _baseUrl = 'https://api-v2.soundcloud.com';

  /// البحث عن تراكات
  Future<List<MusicTrack>> searchTracks(String query, {int limit = 20}) async {
    try {
      final url = Uri.parse(
        '$_baseUrl/search/tracks?q=$query&client_id=$_clientId&limit=$limit',
      );

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final tracks = data['collection'] as List;

        return tracks.map((track) => _parseTrack(track)).toList();
      } else {
        throw Exception('فشل البحث: ${response.statusCode}');
      }
    } catch (e) {
      print('خطأ في البحث: $e');
      return [];
    }
  }

  /// الحصول على تراكات شائعة
  Future<List<MusicTrack>> getTrendingTracks({
    String genre = 'all-music',
  }) async {
    try {
      final url = Uri.parse(
        '$_baseUrl/charts?kind=trending&genre=$genre&client_id=$_clientId&limit=20',
      );

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final tracks = data['collection'] as List;

        return tracks
            .where((item) => item['track'] != null)
            .map((item) => _parseTrack(item['track']))
            .toList();
      } else {
        throw Exception('فشل الحصول على التراكات الشائعة');
      }
    } catch (e) {
      print('خطأ: $e');
      return [];
    }
  }

  /// الحصول على معلومات تراك
  Future<MusicTrack?> getTrack(int trackId) async {
    try {
      final url = Uri.parse('$_baseUrl/tracks/$trackId?client_id=$_clientId');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final track = json.decode(response.body);
        return _parseTrack(track);
      }
      return null;
    } catch (e) {
      print('خطأ: $e');
      return null;
    }
  }

  /// الحصول على رابط البث
  /// ملاحظة: قد يتطلب موافقة أو يكون محمي
  Future<String?> getStreamUrl(int trackId) async {
    try {
      // SoundCloud يستخدم HLS streaming
      final url = Uri.parse(
        '$_baseUrl/tracks/$trackId/streams?client_id=$_clientId',
      );

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['http_mp3_128_url'] ?? data['preview_url'];
      }
      return null;
    } catch (e) {
      print('خطأ: $e');
      return null;
    }
  }

  /// تحويل JSON إلى MusicTrack
  MusicTrack _parseTrack(Map<String, dynamic> json) {
    return MusicTrack(
      id: json['id'].toString(),
      title: json['title'] ?? 'Unknown',
      artist: json['user']?['username'] ?? 'Unknown Artist',
      genre: json['genre'] ?? 'Unknown',
      duration: Duration(milliseconds: json['duration'] ?? 0),
      audioUrl: json['stream_url'] ?? '',
      coverArtUrl: _getArtworkUrl(json['artwork_url']),
      waveformUrl: json['waveform_url'] ?? '',
    );
  }

  /// الحصول على صورة بجودة عالية
  String _getArtworkUrl(String? url) {
    if (url == null || url.isEmpty) {
      return 'https://via.placeholder.com/400x400?text=No+Image';
    }
    // استبدال large بـ t500x500 للجودة العالية
    return url.replaceAll('large', 't500x500');
  }

  /// الأنواع المتاحة
  static const List<String> genres = [
    'all-music',
    'all-audio',
    'alternativerock',
    'ambient',
    'classical',
    'country',
    'danceedm',
    'dancehall',
    'deephouse',
    'disco',
    'drumbass',
    'dubstep',
    'electronic',
    'folksingersongwriter',
    'hiphoprap',
    'house',
    'indie',
    'jazzblues',
    'latin',
    'metal',
    'piano',
    'pop',
    'rbsoul',
    'reggae',
    'reggaeton',
    'rock',
    'soundtrack',
    'techno',
    'trance',
    'trap',
    'triphop',
    'world',
  ];
}
