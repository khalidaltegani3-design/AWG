import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:zoli_chat/models/blink_model.dart';

/// خدمة إدارة Blinks (الفيديوهات القصيرة) في Firestore
/// تستخدم collection 'reels' للتوافق مع Security Rules الموجودة
/// تتعامل مع جميع عمليات CRUD مع مراعاة Security Rules
class BlinkService {
  static final BlinkService _instance = BlinkService._internal();
  factory BlinkService() => _instance;
  BlinkService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'reels'; // استخدام collection reels للتوافق

  /// إنشاء Blink جديد
  ///
  /// يتم إنشاء وثيقة بحالة "processing" في البداية
  /// الخادم سيقوم بتحديثها إلى "published" بعد المعالجة
  Future<String> createBlink({
    required String uid,
    required String title,
    required int durationMs,
    String? videoUrl,
    String? thumbUrl,
    String visibility = 'public',
    String? transcodeProfile,
    String? region,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      final docRef = _firestore.collection(_collection).doc();

      final blink = BlinkModel(
        id: docRef.id,
        uid: uid,
        title: title,
        durationMs: durationMs,
        visibility: visibility,
        status: 'processing', // البداية بحالة processing
        videoUrl: videoUrl,
        thumbUrl: thumbUrl,
        createdAt: DateTime.now(),
        transcodeProfile: transcodeProfile ?? 'feed-720p',
        region: region ?? 'QA',
        metadata: metadata,
      );

      await docRef.set(blink.toMap());

      debugPrint('Blink created successfully: ${docRef.id}');
      return docRef.id;
    } catch (e) {
      debugPrint('Error creating blink: $e');
      rethrow;
    }
  }

  /// تحديث Blink موجود
  Future<void> updateBlink(String blinkId, Map<String, dynamic> updates) async {
    try {
      // إضافة timestamp للتحديث
      updates['updatedAt'] = FieldValue.serverTimestamp();

      await _firestore.collection(_collection).doc(blinkId).update(updates);

      debugPrint('Blink updated successfully: $blinkId');
    } catch (e) {
      debugPrint('Error updating blink: $e');
      rethrow;
    }
  }

  /// تحديث حالة Blink (processing, published, blocked)
  Future<void> updateStatus(String blinkId, String status) async {
    await updateBlink(blinkId, {'status': status});
  }

  /// حذف Blink
  Future<void> deleteBlink(String blinkId) async {
    try {
      await _firestore.collection(_collection).doc(blinkId).delete();
      debugPrint('Blink deleted successfully: $blinkId');
    } catch (e) {
      debugPrint('Error deleting blink: $e');
      rethrow;
    }
  }

  /// جلب Blink بواسطة ID
  Future<BlinkModel?> getBlink(String blinkId) async {
    try {
      final doc = await _firestore.collection(_collection).doc(blinkId).get();

      if (!doc.exists) {
        debugPrint('Blink not found: $blinkId');
        return null;
      }

      return BlinkModel.fromFirestore(doc);
    } catch (e) {
      debugPrint('Error getting blink: $e');
      return null;
    }
  }

  /// جلب Feed عام (paginated)
  ///
  /// Security Rules: يجب أن تكون visibility='public' && status='published'
  Future<List<BlinkModel>> getFeed({
    int limit = 10,
    DocumentSnapshot? startAfter,
  }) async {
    try {
      Query query = _firestore
          .collection(_collection)
          .where('visibility', isEqualTo: 'public')
          .where('status', isEqualTo: 'published')
          .orderBy('createdAt', descending: true)
          .limit(limit);

      if (startAfter != null) {
        query = query.startAfterDocument(startAfter);
      }

      final snapshot = await query.get();

      return snapshot.docs.map((doc) => BlinkModel.fromFirestore(doc)).toList();
    } catch (e) {
      debugPrint('Error getting feed: $e');
      return [];
    }
  }

  /// جلب Blinks لمستخدم معين
  Future<List<BlinkModel>> getUserBlinks({
    required String uid,
    int limit = 20,
    DocumentSnapshot? startAfter,
  }) async {
    try {
      Query query = _firestore
          .collection(_collection)
          .where('authorId', isEqualTo: uid) // استخدام authorId للتوافق
          .orderBy('createdAt', descending: true)
          .limit(limit);

      if (startAfter != null) {
        query = query.startAfterDocument(startAfter);
      }

      final snapshot = await query.get();

      return snapshot.docs.map((doc) => BlinkModel.fromFirestore(doc)).toList();
    } catch (e) {
      debugPrint('Error getting user blinks: $e');
      return [];
    }
  }

  /// مراقبة Blink معين (Stream)
  Stream<BlinkModel?> watchBlink(String blinkId) {
    return _firestore.collection(_collection).doc(blinkId).snapshots().map((
      doc,
    ) {
      if (!doc.exists) return null;
      return BlinkModel.fromFirestore(doc);
    });
  }

  /// مراقبة Feed (Stream)
  Stream<List<BlinkModel>> watchFeed({int limit = 10}) {
    return _firestore
        .collection(_collection)
        .where('visibility', isEqualTo: 'public')
        .where('status', isEqualTo: 'published')
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => BlinkModel.fromFirestore(doc))
              .toList(),
        );
  }

  /// زيادة عدد المشاهدات
  Future<void> incrementViews(String blinkId) async {
    try {
      await _firestore.collection(_collection).doc(blinkId).update({
        'views': FieldValue.increment(1),
      });
    } catch (e) {
      debugPrint('Error incrementing views: $e');
    }
  }

  /// زيادة عدد الإعجابات
  Future<void> incrementLikes(String blinkId) async {
    try {
      await _firestore.collection(_collection).doc(blinkId).update({
        'likes': FieldValue.increment(1),
      });
    } catch (e) {
      debugPrint('Error incrementing likes: $e');
    }
  }

  /// تقليل عدد الإعجابات
  Future<void> decrementLikes(String blinkId) async {
    try {
      await _firestore.collection(_collection).doc(blinkId).update({
        'likes': FieldValue.increment(-1),
      });
    } catch (e) {
      debugPrint('Error decrementing likes: $e');
    }
  }

  /// البحث عن Blinks بالعنوان
  Future<List<BlinkModel>> searchBlinks({
    required String query,
    int limit = 20,
  }) async {
    try {
      // Firestore لا يدعم البحث النصي الكامل
      // هذه طريقة بسيطة للبحث بالبداية
      final snapshot = await _firestore
          .collection(_collection)
          .where('visibility', isEqualTo: 'public')
          .where('status', isEqualTo: 'published')
          .where('title', isGreaterThanOrEqualTo: query)
          .where('title', isLessThanOrEqualTo: '$query\uf8ff')
          .limit(limit)
          .get();

      return snapshot.docs.map((doc) => BlinkModel.fromFirestore(doc)).toList();
    } catch (e) {
      debugPrint('Error searching blinks: $e');
      return [];
    }
  }

  /// جلب Blinks الشائعة (trending)
  Future<List<BlinkModel>> getTrendingBlinks({
    int limit = 10,
    Duration within = const Duration(days: 7),
  }) async {
    try {
      final since = DateTime.now().subtract(within);

      final snapshot = await _firestore
          .collection(_collection)
          .where('visibility', isEqualTo: 'public')
          .where('status', isEqualTo: 'published')
          .where('createdAt', isGreaterThan: Timestamp.fromDate(since))
          .orderBy('createdAt', descending: false) // Required for where clause
          .orderBy('likes', descending: true)
          .limit(limit)
          .get();

      return snapshot.docs.map((doc) => BlinkModel.fromFirestore(doc)).toList();
    } catch (e) {
      debugPrint('Error getting trending blinks: $e');
      return [];
    }
  }

  /// جلب إحصائيات المستخدم
  Future<Map<String, int>> getUserStats(String uid) async {
    try {
      final snapshot = await _firestore
          .collection(_collection)
          .where('authorId', isEqualTo: uid)
          .get();

      int totalViews = 0;
      int totalLikes = 0;
      int publishedCount = 0;

      for (var doc in snapshot.docs) {
        final data = doc.data();
        totalViews += (data['views'] ?? 0) as int;
        totalLikes += (data['likes'] ?? 0) as int;
        if (data['status'] == 'published') {
          publishedCount++;
        }
      }

      return {
        'totalBlinks': snapshot.docs.length,
        'publishedBlinks': publishedCount,
        'totalViews': totalViews,
        'totalLikes': totalLikes,
      };
    } catch (e) {
      debugPrint('Error getting user stats: $e');
      return {
        'totalBlinks': 0,
        'publishedBlinks': 0,
        'totalViews': 0,
        'totalLikes': 0,
      };
    }
  }

  /// جلب آخر DocumentSnapshot (للـ pagination)
  DocumentSnapshot? _lastDocument;

  DocumentSnapshot? get lastDocument => _lastDocument;

  set lastDocument(DocumentSnapshot? doc) {
    _lastDocument = doc;
  }
}
