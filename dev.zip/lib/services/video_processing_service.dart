import 'dart:io';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:path_provider/path_provider.dart';

/// Service for video compression and thumbnail generation
class VideoProcessingService {
  /// Compress video before uploading using native platform channels
  /// For now, just copy the file - compression will be added later
  /// TODO: Implement native compression using MediaCodec (Android) and AVFoundation (iOS)
  Future<String?> compressVideo({
    required String inputPath,
    String quality = 'medium',
    int frameRate = 30,
  }) async {
    try {
      final tempDir = await getTemporaryDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final outputPath = '${tempDir.path}/compressed_$timestamp.mp4';

      // For now, just copy the file
      // In future, call native platform channel for compression
      final inputFile = File(inputPath);
      await inputFile.copy(outputPath);

      return outputPath;
    } catch (e) {
      throw Exception('Error processing video: $e');
    }
  }

  /// Generate thumbnail from video
  /// Returns the path to the thumbnail image
  Future<String?> generateThumbnail({
    required String videoPath,
    int quality = 90,
    int timeMs = 0,
  }) async {
    try {
      final thumbnail = await VideoThumbnail.thumbnailFile(
        video: videoPath,
        imageFormat: ImageFormat.PNG,
        quality: quality,
        timeMs: timeMs,
      );

      return thumbnail;
    } catch (e) {
      throw Exception('Error generating thumbnail: $e');
    }
  }

  /// Get video file size in MB
  Future<double> getFileSizeMB(String filePath) async {
    try {
      final file = File(filePath);
      final bytes = await file.length();
      return bytes / (1024 * 1024); // Convert to MB
    } catch (e) {
      return 0.0;
    }
  }

}
