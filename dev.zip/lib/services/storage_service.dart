import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';

/// خدمة رفع الملفات إلى Firebase Storage
/// تستخدم المسارات المتوافقة مع Security Rules الموجودة
/// تدير رفع الفيديوهات والصور المصغرة مع تتبع التقدم
class StorageService {
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  final FirebaseStorage _storage = FirebaseStorage.instance;

  /// رفع فيديو Blink
  ///
  /// [file] - ملف الفيديو
  /// [uid] - معرف المستخدم
  /// [blinkId] - معرف الـ Blink
  /// [onProgress] - callback لتتبع التقدم (0.0 إلى 1.0)
  ///
  /// Returns: رابط gs:// للفيديو المرفوع
  ///
  /// المسار المستخدم: uploads/{uid}/{blinkId}.mp4 (يتوافق مع Storage Rules)
  Future<String> uploadBlinkVideo({
    required File file,
    required String uid,
    required String blinkId,
    Function(double)? onProgress,
  }) async {
    try {
      final String path = 'uploads/$uid/$blinkId.mp4';
      final Reference ref = _storage.ref().child(path);

      // إعداد metadata
      final SettableMetadata metadata = SettableMetadata(
        contentType: 'video/mp4',
        customMetadata: {
          'uid': uid,
          'blinkId': blinkId,
          'uploadedAt': DateTime.now().toIso8601String(),
          'type': 'blink-video',
        },
      );

      // بدء الرفع
      final UploadTask uploadTask = ref.putFile(file, metadata);

      // تتبع التقدم
      if (onProgress != null) {
        uploadTask.snapshotEvents.listen((TaskSnapshot snapshot) {
          final progress = snapshot.bytesTransferred / snapshot.totalBytes;
          onProgress(progress);
        });
      }

      // انتظار اكتمال الرفع
      await uploadTask;

      // الحصول على رابط gs://
      final String gsUrl = 'gs://${ref.bucket}/${ref.fullPath}';

      debugPrint('Video uploaded successfully: $gsUrl');
      return gsUrl;
    } catch (e) {
      debugPrint('Failed to upload video: $e');
      rethrow;
    }
  }

  /// رفع صورة مصغرة للـ Blink
  ///
  /// [file] - ملف الصورة
  /// [uid] - معرف المستخدم
  /// [blinkId] - معرف الـ Blink
  /// [onProgress] - callback لتتبع التقدم
  ///
  /// Returns: رابط gs:// للصورة المرفوعة
  ///
  /// المسار المستخدم: thumbs/{blinkId}/thumb.jpg (يتوافق مع Storage Rules)
  Future<String> uploadBlinkThumbnail({
    required File file,
    required String uid,
    required String blinkId,
    Function(double)? onProgress,
  }) async {
    try {
      // المسار المنضبط: thumbs/{blinkId}/thumb.jpg
      final String path = 'thumbs/$blinkId/thumb.jpg';
      final Reference ref = _storage.ref().child(path);

      // إعداد metadata
      final SettableMetadata metadata = SettableMetadata(
        contentType: 'image/jpeg',
        customMetadata: {
          'uid': uid,
          'blinkId': blinkId,
          'uploadedAt': DateTime.now().toIso8601String(),
          'type': 'blink-thumbnail',
        },
      );

      // بدء الرفع
      final UploadTask uploadTask = ref.putFile(file, metadata);

      // تتبع التقدم
      if (onProgress != null) {
        uploadTask.snapshotEvents.listen((TaskSnapshot snapshot) {
          final progress = snapshot.bytesTransferred / snapshot.totalBytes;
          onProgress(progress);
        });
      }

      // انتظار اكتمال الرفع
      await uploadTask;

      // الحصول على رابط gs://
      final String gsUrl = 'gs://${ref.bucket}/${ref.fullPath}';

      debugPrint('Thumbnail uploaded successfully: $gsUrl');
      return gsUrl;
    } catch (e) {
      debugPrint('Failed to upload thumbnail: $e');
      rethrow;
    }
  }

  /// رفع صورة بروفايل المستخدم
  ///
  /// [file] - ملف الصورة
  /// [uid] - معرف المستخدم
  /// [onProgress] - callback لتتبع التقدم
  ///
  /// Returns: رابط gs:// للصورة المرفوعة
  ///
  /// المسار المستخدم: avatars/{uid}/profile.jpg (يتوافق مع Storage Rules)
  Future<String> uploadProfileImage({
    required File file,
    required String uid,
    Function(double)? onProgress,
  }) async {
    try {
      // المسار المنضبط: avatars/{uid}/profile.jpg
      final String path = 'avatars/$uid/profile.jpg';
      final Reference ref = _storage.ref().child(path);

      // إعداد metadata
      final SettableMetadata metadata = SettableMetadata(
        contentType: 'image/jpeg',
        customMetadata: {
          'uid': uid,
          'uploadedAt': DateTime.now().toIso8601String(),
          'type': 'profile-image',
        },
      );

      // بدء الرفع
      final UploadTask uploadTask = ref.putFile(file, metadata);

      // تتبع التقدم
      if (onProgress != null) {
        uploadTask.snapshotEvents.listen((TaskSnapshot snapshot) {
          final progress = snapshot.bytesTransferred / snapshot.totalBytes;
          onProgress(progress);
        });
      }

      // انتظار اكتمال الرفع
      await uploadTask;

      // الحصول على رابط gs://
      final String gsUrl = 'gs://${ref.bucket}/${ref.fullPath}';

      debugPrint('Profile image uploaded successfully: $gsUrl');
      return gsUrl;
    } catch (e) {
      debugPrint('Failed to upload profile image: $e');
      rethrow;
    }
  }

  /// رفع صورة Story
  ///
  /// [file] - ملف الصورة
  /// [uid] - معرف المستخدم
  /// [storyId] - معرف الستوري
  /// [onProgress] - callback لتتبع التقدم
  ///
  /// Returns: رابط gs:// للصورة المرفوعة
  ///
  /// المسار المستخدم: stories/{uid}/{storyId}.jpg (يتوافق مع Storage Rules)
  Future<String> uploadStoryImage({
    required File file,
    required String uid,
    required String storyId,
    Function(double)? onProgress,
  }) async {
    try {
      // المسار المنضبط: stories/{uid}/{storyId}.jpg
      final String path = 'stories/$uid/$storyId.jpg';
      final Reference ref = _storage.ref().child(path);

      // إعداد metadata
      final SettableMetadata metadata = SettableMetadata(
        contentType: 'image/jpeg',
        customMetadata: {
          'uid': uid,
          'storyId': storyId,
          'uploadedAt': DateTime.now().toIso8601String(),
          'type': 'story-image',
        },
      );

      // بدء الرفع
      final UploadTask uploadTask = ref.putFile(file, metadata);

      // تتبع التقدم
      if (onProgress != null) {
        uploadTask.snapshotEvents.listen((TaskSnapshot snapshot) {
          final progress = snapshot.bytesTransferred / snapshot.totalBytes;
          onProgress(progress);
        });
      }

      // انتظار اكتمال الرفع
      await uploadTask;

      // الحصول على رابط gs://
      final String gsUrl = 'gs://${ref.bucket}/${ref.fullPath}';

      debugPrint('Story image uploaded successfully: $gsUrl');
      return gsUrl;
    } catch (e) {
      debugPrint('Failed to upload story image: $e');
      rethrow;
    }
  }

  /// حذف ملف من Storage
  ///
  /// [gsUrl] - رابط gs:// للملف
  Future<void> deleteFile(String gsUrl) async {
    try {
      final Reference ref = _storage.refFromURL(gsUrl);
      await ref.delete();
      debugPrint('File deleted successfully: $gsUrl');
    } catch (e) {
      debugPrint('Failed to delete file: $e');
      rethrow;
    }
  }

  /// حذف جميع ملفات Blink (فيديو + صورة مصغرة)
  ///
  /// [uid] - معرف المستخدم
  /// [blinkId] - معرف الـ Blink
  Future<void> deleteBlinkFiles({
    required String uid,
    required String blinkId,
  }) async {
    try {
      // حذف الفيديو
      final String videoPath = 'uploads/$uid/$blinkId.mp4';
      await _storage.ref().child(videoPath).delete();

      // حذف الصورة المصغرة
      final String thumbPath = 'thumbs/$blinkId/thumb.jpg';
      await _storage.ref().child(thumbPath).delete();

      debugPrint('Blink files deleted successfully: $blinkId');
    } catch (e) {
      debugPrint('Failed to delete blink files: $e');
      // لا نرمي الخطأ لأن بعض الملفات قد لا تكون موجودة
    }
  }

  /// الحصول على رابط تحميل مباشر (HTTP URL)
  ///
  /// [gsUrl] - رابط gs:// للملف
  ///
  /// Returns: رابط HTTP للتحميل المباشر
  Future<String> getDownloadUrl(String gsUrl) async {
    try {
      final Reference ref = _storage.refFromURL(gsUrl);
      final String downloadUrl = await ref.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      debugPrint('Failed to get download URL: $e');
      rethrow;
    }
  }

  /// الحصول على metadata للملف
  ///
  /// [gsUrl] - رابط gs:// للملف
  ///
  /// Returns: metadata الملف
  Future<FullMetadata> getMetadata(String gsUrl) async {
    try {
      final Reference ref = _storage.refFromURL(gsUrl);
      final FullMetadata metadata = await ref.getMetadata();
      return metadata;
    } catch (e) {
      debugPrint('Failed to get metadata: $e');
      rethrow;
    }
  }

  /// الحصول على حجم الملف
  ///
  /// [gsUrl] - رابط gs:// للملف
  ///
  /// Returns: حجم الملف بالبايتات
  Future<int> getFileSize(String gsUrl) async {
    try {
      final FullMetadata metadata = await getMetadata(gsUrl);
      return metadata.size ?? 0;
    } catch (e) {
      debugPrint('Failed to get file size: $e');
      return 0;
    }
  }
}
