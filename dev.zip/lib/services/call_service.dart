import 'dart:async';

// Enum for call type
enum CallType { incoming, outgoing, missed }

// Data model for a call log entry
class CallLog {
  final String name;
  final String avatarUrl;
  final DateTime timestamp;
  final CallType type;
  final bool isVideo;

  CallLog({
    required this.name,
    required this.avatarUrl,
    required this.timestamp,
    required this.type,
    this.isVideo = false,
  });
}

class CallService {
  // Singleton pattern to ensure only one instance of the service
  static final CallService _instance = CallService._internal();
  factory CallService() {
    return _instance;
  }
  CallService._internal();

  // Mock data for call logs
  final List<CallLog> _callLogs = [
    CallLog(
      name: 'Alice',
      avatarUrl: 'https://picsum.photos/seed/alice/200',
      timestamp: DateTime.now().subtract(const Duration(hours: 1)),
      type: CallType.incoming,
    ),
    CallLog(
      name: 'Bob',
      avatarUrl: 'https://picsum.photos/seed/bob/200',
      timestamp: DateTime.now().subtract(const Duration(days: 1, hours: 2)),
      type: CallType.outgoing,
      isVideo: true,
    ),
    CallLog(
      name: 'Charlie',
      avatarUrl: 'https://picsum.photos/seed/charlie/200',
      timestamp: DateTime.now().subtract(const Duration(days: 1, hours: 5)),
      type: CallType.missed,
    ),
  ];

  // Stream controller to provide reactive updates
  final _callLogsStreamController = StreamController<List<CallLog>>.broadcast();

  Stream<List<CallLog>> get callLogsStream async* {
    // Initially send the current state
    _callLogs.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    yield _callLogs;
    // Then listen for future updates
    yield* _callLogsStreamController.stream;
  }

  // Get the current list of call logs
  void getCallLogs() {
    _callLogs.sort(
      (a, b) => b.timestamp.compareTo(a.timestamp),
    ); // Sort by most recent
    _callLogsStreamController.add(_callLogs);
  }

  // Add a new call to the log
  void addCall(CallLog call) {
    _callLogs.insert(0, call); // Add to the top of the list
    _callLogsStreamController.add(_callLogs);
    print("Call added to log: ${call.name}, Type: ${call.type}");
  }

  // Dispose the stream controller when no longer needed
  void dispose() {
    _callLogsStreamController.close();
  }
}
