import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:zoli_chat/models/ramshat_model.dart';

/// خدمة إدارة الرمشات في Firestore
/// تتعامل مع جميع عمليات CRUD للرمشات مع مراعاة Security Rules
class RamshatService {
  static final RamshatService _instance = RamshatService._internal();
  factory RamshatService() => _instance;
  RamshatService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'ramshat';

  /// إنشاء رمشة جديدة
  ///
  /// يتم إنشاء وثيقة بحالة "processing" في البداية
  /// الخادم سيقوم بتحديثها إلى "published" بعد المعالجة
  Future<String> createRamsha({
    required String uid,
    required String title,
    required int durationMs,
    String? videoUrl,
    String? thumbUrl,
    String visibility = 'public',
    String? transcodeProfile,
    String? region,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      final docRef = _firestore.collection(_collection).doc();

      final ramsha = RamshatModel(
        id: docRef.id,
        uid: uid,
        title: title,
        durationMs: durationMs,
        visibility: visibility,
        status: 'processing', // البداية بحالة processing
        videoUrl: videoUrl,
        thumbUrl: thumbUrl,
        createdAt: DateTime.now(),
        transcodeProfile: transcodeProfile ?? 'feed-720p',
        region: region ?? 'QA',
        metadata: metadata,
      );

      await docRef.set(ramsha.toMap());

      debugPrint('Ramsha created successfully: ${docRef.id}');
      return docRef.id;
    } catch (e) {
      debugPrint('Failed to create ramsha: $e');
      rethrow;
    }
  }

  /// تحديث رمشة موجودة
  Future<void> updateRamsha({
    required String ramshaId,
    Map<String, dynamic>? updates,
  }) async {
    try {
      if (updates == null || updates.isEmpty) return;

      updates['updatedAt'] = FieldValue.serverTimestamp();

      await _firestore.collection(_collection).doc(ramshaId).update(updates);

      debugPrint('Ramsha updated successfully: $ramshaId');
    } catch (e) {
      debugPrint('Failed to update ramsha: $e');
      rethrow;
    }
  }

  /// تحديث حالة الرمشة
  Future<void> updateStatus({
    required String ramshaId,
    required String status,
  }) async {
    try {
      await updateRamsha(ramshaId: ramshaId, updates: {'status': status});
    } catch (e) {
      debugPrint('Failed to update ramsha status: $e');
      rethrow;
    }
  }

  /// حذف رمشة
  Future<void> deleteRamsha(String ramshaId) async {
    try {
      await _firestore.collection(_collection).doc(ramshaId).delete();
      debugPrint('Ramsha deleted successfully: $ramshaId');
    } catch (e) {
      debugPrint('Failed to delete ramsha: $e');
      rethrow;
    }
  }

  /// الحصول على رمشة واحدة
  Future<RamshatModel?> getRamsha(String ramshaId) async {
    try {
      final doc = await _firestore.collection(_collection).doc(ramshaId).get();

      if (!doc.exists) return null;

      return RamshatModel.fromFirestore(doc);
    } catch (e) {
      debugPrint('Failed to get ramsha: $e');
      return null;
    }
  }

  /// جلب feed عام (جميع الرمشات المنشورة)
  ///
  /// يستخدم pagination مع limit و startAfter للأداء الأفضل
  /// متوافق مع Security Rules: visibility='public' و status='published'
  Future<List<RamshatModel>> getFeed({
    int limit = 10,
    DocumentSnapshot? startAfter,
  }) async {
    try {
      Query query = _firestore
          .collection(_collection)
          .where('visibility', isEqualTo: 'public')
          .where('status', isEqualTo: 'published')
          .orderBy('createdAt', descending: true)
          .limit(limit);

      if (startAfter != null) {
        query = query.startAfterDocument(startAfter);
      }

      final snapshot = await query.get();

      return snapshot.docs
          .map((doc) => RamshatModel.fromFirestore(doc))
          .toList();
    } catch (e) {
      debugPrint('Failed to get feed: $e');
      return [];
    }
  }

  /// جلب رمشات مستخدم معين
  Future<List<RamshatModel>> getUserRamshat({
    required String uid,
    int limit = 20,
    DocumentSnapshot? startAfter,
  }) async {
    try {
      Query query = _firestore
          .collection(_collection)
          .where('uid', isEqualTo: uid)
          .orderBy('createdAt', descending: true)
          .limit(limit);

      if (startAfter != null) {
        query = query.startAfterDocument(startAfter);
      }

      final snapshot = await query.get();

      return snapshot.docs
          .map((doc) => RamshatModel.fromFirestore(doc))
          .toList();
    } catch (e) {
      debugPrint('Failed to get user ramshat: $e');
      return [];
    }
  }

  /// Stream للاستماع لتحديثات رمشة واحدة
  Stream<RamshatModel?> watchRamsha(String ramshaId) {
    return _firestore.collection(_collection).doc(ramshaId).snapshots().map((
      doc,
    ) {
      if (!doc.exists) return null;
      return RamshatModel.fromFirestore(doc);
    });
  }

  /// Stream للاستماع لـ feed (استخدم بحذر - يستهلك reads)
  Stream<List<RamshatModel>> watchFeed({int limit = 10}) {
    return _firestore
        .collection(_collection)
        .where('visibility', isEqualTo: 'public')
        .where('status', isEqualTo: 'published')
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) {
          return snapshot.docs
              .map((doc) => RamshatModel.fromFirestore(doc))
              .toList();
        });
  }

  /// زيادة عدد المشاهدات (يُفضل أن يتم من الخادم)
  Future<void> incrementViews(String ramshaId) async {
    try {
      await _firestore.collection(_collection).doc(ramshaId).update({
        'views': FieldValue.increment(1),
      });
    } catch (e) {
      debugPrint('Failed to increment views: $e');
    }
  }

  /// زيادة عدد الإعجابات (يُفضل أن يتم من الخادم)
  Future<void> incrementLikes(String ramshaId) async {
    try {
      await _firestore.collection(_collection).doc(ramshaId).update({
        'likes': FieldValue.increment(1),
      });
    } catch (e) {
      debugPrint('Failed to increment likes: $e');
    }
  }

  /// تقليل عدد الإعجابات
  Future<void> decrementLikes(String ramshaId) async {
    try {
      await _firestore.collection(_collection).doc(ramshaId).update({
        'likes': FieldValue.increment(-1),
      });
    } catch (e) {
      debugPrint('Failed to decrement likes: $e');
    }
  }

  /// البحث في الرمشات حسب العنوان
  Future<List<RamshatModel>> searchRamshat({
    required String query,
    int limit = 20,
  }) async {
    try {
      // Firestore doesn't support full-text search natively
      // This is a basic implementation - consider using Algolia or ElasticSearch for production

      final snapshot = await _firestore
          .collection(_collection)
          .where('visibility', isEqualTo: 'public')
          .where('status', isEqualTo: 'published')
          .orderBy('title')
          .startAt([query])
          .endAt(['$query\uf8ff'])
          .limit(limit)
          .get();

      return snapshot.docs
          .map((doc) => RamshatModel.fromFirestore(doc))
          .toList();
    } catch (e) {
      debugPrint('Failed to search ramshat: $e');
      return [];
    }
  }

  /// جلب الرمشات الشائعة (حسب المشاهدات)
  Future<List<RamshatModel>> getTrendingRamshat({
    int limit = 20,
    Duration? within,
  }) async {
    try {
      Query query = _firestore
          .collection(_collection)
          .where('visibility', isEqualTo: 'public')
          .where('status', isEqualTo: 'published');

      // إذا كان هناك فترة زمنية محددة
      if (within != null) {
        final since = DateTime.now().subtract(within);
        query = query.where(
          'createdAt',
          isGreaterThan: Timestamp.fromDate(since),
        );
      }

      query = query.orderBy('views', descending: true).limit(limit);

      final snapshot = await query.get();

      return snapshot.docs
          .map((doc) => RamshatModel.fromFirestore(doc))
          .toList();
    } catch (e) {
      debugPrint('Failed to get trending ramshat: $e');
      return [];
    }
  }

  /// احصائيات المستخدم
  Future<Map<String, int>> getUserStats(String uid) async {
    try {
      final snapshot = await _firestore
          .collection(_collection)
          .where('uid', isEqualTo: uid)
          .get();

      int totalViews = 0;
      int totalLikes = 0;
      int publishedCount = 0;

      for (var doc in snapshot.docs) {
        final data = doc.data();
        totalViews += (data['views'] as int?) ?? 0;
        totalLikes += (data['likes'] as int?) ?? 0;
        if (data['status'] == 'published') {
          publishedCount++;
        }
      }

      return {
        'totalRamshat': snapshot.docs.length,
        'publishedRamshat': publishedCount,
        'totalViews': totalViews,
        'totalLikes': totalLikes,
      };
    } catch (e) {
      debugPrint('Failed to get user stats: $e');
      return {};
    }
  }
}
