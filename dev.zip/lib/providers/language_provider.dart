import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LanguageProvider with ChangeNotifier {
  Locale? _appLocale;

  Locale? get appLocale => _appLocale;

  LanguageProvider() {
    _loadLocale();
  }

  void _loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    String? languageCode = prefs.getString('language_code');
    if (languageCode != null) {
      _appLocale = Locale(languageCode);
    }
    // If languageCode is null, _appLocale remains null, and MaterialApp will use its default locale resolution.
    notifyListeners();
  }

  void changeLanguage(Locale newLocale) async {
    if (_appLocale == newLocale) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language_code', newLocale.languageCode);
    _appLocale = newLocale;
    notifyListeners();
  }
}
