# 🔐 دليل إصلاح reCAPTCHA - Hide Verification Page

> **المشكلة**: صفحة ويب للـ reCAPTCHA تظهر عند تسجيل الدخول  
> **الحل**: تفعيل Play Integrity API لإجراء التحقق في الخلفية  
> **النتيجة**: ✅ تحقق خفي بدون أي صفحات ظاهرة

---

## 🎯 نظرة عامة

### ما يحدث الآن (قبل الإصلاح):
```
المستخدم يدخل رقم الهاتف
      ↓
Firebase يفتح صفحة ويب reCAPTCHA  ❌ (مرئية)
      ↓
المستخدم يحل التحدي
      ↓
يتم إرسال OTP
```

### ما سيحدث (بعد الإصلاح):
```
المستخدم يدخل رقم الهاتف
      ↓
Play Integrity API تعمل في الخلفية  ✅ (خفية)
      ↓
يتم إرسال OTP مباشرة
      ↓
تجربة مستخدم سلسة!
```

---

## 📝 الخطوات التفصيلية

### ✅ **الخطوة 1: استخراج SHA-1 و SHA-256**

#### 1.1. لـ Debug Build (للتطوير):

```powershell
# في PowerShell داخل مجلد المشروع:
cd android
.\gradlew signingReport
```

**ابحث عن**:
```
Variant: debug
Config: debug
Store: C:\Users\khali\.android\debug.keystore
Alias: AndroidDebugKey
SHA1: XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX
SHA-256: YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY:YY
```

**📋 انسخ SHA-1 و SHA-256**

---

#### 1.2. لـ Release Build (للإنتاج):

**بعد إنشاء keystore الإنتاج**:

```powershell
# الطريقة 1: باستخدام keytool (خارج PowerShell):
keytool -list -v -keystore android\app\keystore\release.jks -alias zoli-release

# الطريقة 2: باستخدام Gradle:
cd android
.\gradlew signingReport
```

**📋 انسخ SHA-1 و SHA-256 للـ release أيضاً**

---

### ✅ **الخطوة 2: إضافة البصمات في Firebase Console**

#### 2.1. افتح Firebase Console:
```
https://console.firebase.google.com/
```

#### 2.2. اختر المشروع الخاص بك

#### 2.3. اذهب إلى:
```
⚙️ Project Settings (إعدادات المشروع)
   ↓
Your apps (تطبيقاتك)
   ↓
Android app (com.zoli.app)
   ↓
أسفل الصفحة: "SHA certificate fingerprints"
```

#### 2.4. اضغط **"Add fingerprint"**

#### 2.5. الصق SHA-1 من Debug
- اضغط **Save**

#### 2.6. اضغط **"Add fingerprint"** مرة أخرى
- الصق SHA-256 من Debug
- اضغط **Save**

#### 2.7. كرر العملية لـ Release (إذا كان لديك keystore):
- أضف SHA-1 للـ Release
- أضف SHA-256 للـ Release

**✅ يجب أن يكون لديك 4 بصمات (2 لـ debug + 2 لـ release)**

---

### ✅ **الخطوة 3: تنزيل google-services.json الجديد**

بعد إضافة البصمات:

#### 3.1. في Firebase Console → نفس الصفحة:
```
Project Settings → Your apps → Android app
```

#### 3.2. اضغط **"google-services.json"** (زر التنزيل)

#### 3.3. استبدل الملف القديم:
```
android/app/google-services.json
```

**⚠️ مهم**: يجب تنزيل الملف الجديد بعد إضافة البصمات!

---

### ✅ **الخطوة 4: تفعيل Play Integrity API في Google Cloud**

#### 4.1. افتح Google Cloud Console:
```
https://console.cloud.google.com/
```

#### 4.2. اختر نفس المشروع (نفس اسم Firebase Project)

#### 4.3. في شريط البحث أعلى الصفحة:
```
ابحث عن: Play Integrity API
```

#### 4.4. اختر **"Play Integrity API"**

#### 4.5. اضغط **"Enable"** (تفعيل)

#### 4.6. انتظر حتى تظهر:
```
✅ API enabled
```

**📌 ملاحظة**: إذا كان المشروع غير مرتبط بحساب Google Cloud، سيطلب منك:
- تفعيل Billing (قد يحتاج بطاقة ائتمان للتحقق فقط)
- Play Integrity API مجاني للاستخدام العادي

---

### ✅ **الخطوة 5: تفعيل App Check في Firebase Console**

#### 5.1. في Firebase Console → القائمة الجانبية:
```
Build (بناء)
  ↓
App Check
```

#### 5.2. اختر تطبيق Android

#### 5.3. في **"Play Integrity"** → اضغط **"Register"**

#### 5.4. بعد التسجيل، ستظهر:
```
✅ Play Integrity provider registered
```

#### 5.5. (اختياري) تفعيل Enforcement:

انتقل إلى تبويب **"APIs"**:

```
Authentication (المصادقة)
  - Status: Not enforced (اتركها هكذا للتطوير)
  - يمكن تفعيلها لاحقاً في الإنتاج

Firestore Database
  - Status: Not enforced
  - يمكن تفعيلها في الإنتاج

Storage
  - Status: Not enforced
  - يمكن تفعيلها في الإنتاج
```

**⚠️ تنبيه**: لا تفعّل Enforcement في بيئة التطوير وإلا لن يعمل التطبيق!

---

### ✅ **الخطوة 6: التأكد من الكود جاهز**

#### 6.1. تحقق من `lib/main.dart`:

**الكود موجود بالفعل** ✅:

```dart
// في main() function:
await FirebaseAppCheck.instance.activate(
  androidProvider: AndroidProvider.playIntegrity,  // ✅ جاهز
  appleProvider: AppleProvider.deviceCheck,
  webProvider: ReCaptchaV3Provider('recaptcha-v3-site-key'),
);
```

#### 6.2. تحقق من `web/index.html`:

**CSS مضاف بالفعل** ✅:

```html
<style>
  .grecaptcha-badge,
  #firebase-auth-container,
  iframe[src*="recaptcha"] {
    display: none !important;
    visibility: hidden !important;
    opacity: 0 !important;
    pointer-events: none !important;
  }
</style>
```

---

### ✅ **الخطوة 7: اختبار الحل**

#### 7.1. نظف المشروع:
```powershell
flutter clean
cd android
.\gradlew clean
cd ..
```

#### 7.2. احذف التطبيق من الجهاز (إذا كان مثبتاً)

#### 7.3. أعد التثبيت:
```powershell
flutter run -d <DEVICE_ID>
```

#### 7.4. اختبر تسجيل الدخول:
1. أدخل رقم هاتف
2. **يجب أن لا تظهر أي صفحة reCAPTCHA** ✅
3. OTP يُرسل مباشرة
4. أدخل الكود وتم!

---

## 🐛 استكشاف الأخطاء

### ❌ المشكلة 1: صفحة reCAPTCHA ما زالت تظهر

**الحلول**:

1. **تأكد من SHA-1 و SHA-256 مضافة صحيحة**:
   ```powershell
   cd android
   .\gradlew signingReport
   ```
   قارن البصمات مع Firebase Console

2. **تأكد من تنزيل google-services.json الجديد**:
   - يجب تنزيله **بعد** إضافة البصمات
   - استبدل الملف في `android/app/google-services.json`

3. **انتظر 5-10 دقائق**:
   - Google يحتاج وقت لنشر التغييرات
   - اعمل `flutter clean` ثم أعد التشغيل

4. **تحقق من Play Integrity API**:
   ```
   Google Cloud Console → Play Integrity API → تأكد أنها Enabled
   ```

5. **تأكد من package name صحيح**:
   - في `android/app/build.gradle.kts`: `applicationId = "com.zoli.app"`
   - في Firebase Console: يجب أن يكون نفس الـ package name

---

### ❌ المشكلة 2: خطأ "App Check token is invalid"

**الحل**:
```
Firebase Console → App Check → Android app → Re-register
```

---

### ❌ المشكلة 3: "Play Integrity API not enabled"

**الحل**:
1. اذهب إلى Google Cloud Console
2. ابحث عن "Play Integrity API"
3. اضغط Enable
4. انتظر 2-3 دقائق
5. أعد تشغيل التطبيق

---

### ❌ المشكلة 4: خطأ في Build

```
Failed to generate debug signing report
```

**الحل**:
```powershell
# احذف الملفات المؤقتة:
Remove-Item -Recurse -Force android\.gradle -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force android\app\build -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force build -ErrorAction SilentlyContinue

# أعد المحاولة:
cd android
.\gradlew clean
.\gradlew signingReport
```

---

## 📊 التحقق من النجاح

### ✅ علامات النجاح:

1. **في Console Logs أثناء التشغيل**:
   ```
   ✅ Firebase initialized
   ✅ App Check activated
   ✅ Play Integrity provider ready
   ```

2. **عند تسجيل الدخول**:
   - ✅ لا تظهر صفحة ويب
   - ✅ لا يظهر reCAPTCHA
   - ✅ OTP يُرسل مباشرة
   - ✅ تجربة سلسة للمستخدم

3. **في Firebase Console → App Check → Metrics**:
   ```
   ✅ App Check verifications: عدد التحققات
   ✅ Valid tokens issued: عدد الـ tokens الناجحة
   ```

---

## 🔒 أمان إضافي (اختياري)

### تفعيل Enforcement في الإنتاج:

بعد التأكد أن كل شيء يعمل:

```
Firebase Console → App Check → APIs
```

**Authentication**:
```
Status: Not enforced → Enforced
```

**Firestore**:
```
Status: Not enforced → Enforced
```

**Storage**:
```
Status: Not enforced → Enforced
```

**⚠️ ملاحظة**: 
- فقط في **الإنتاج**
- بعد اختبار كامل في التطوير
- تأكد أن App Check يعمل 100% قبل التفعيل

---

## 📋 Checklist النهائي

قبل إعلان النجاح، تأكد من:

### Firebase Console
- [ ] SHA-1 Debug مضاف
- [ ] SHA-256 Debug مضاف
- [ ] SHA-1 Release مضاف (إن وُجد)
- [ ] SHA-256 Release مضاف (إن وُجد)
- [ ] google-services.json محدّث ومُنزّل

### Google Cloud Console
- [ ] Play Integrity API مفعّلة (Enabled)
- [ ] Billing محدد (إذا طُلب)

### Firebase App Check
- [ ] Play Integrity provider مسجّل
- [ ] Enforcement: Not enforced (للتطوير)

### الكود
- [ ] `firebase_app_check` في pubspec.yaml
- [ ] App Check مفعّل في main.dart
- [ ] CSS لإخفاء reCAPTCHA في web/index.html

### الاختبار
- [ ] flutter clean تم تشغيله
- [ ] التطبيق مُعاد تثبيته من الصفر
- [ ] تسجيل دخول اختباري نجح بدون صفحة ويب
- [ ] OTP وصل بسرعة
- [ ] لا أخطاء في Console

---

## 🎯 ملخص سريع

### الأوامر الأساسية:

```powershell
# 1. استخراج SHA:
cd android
.\gradlew signingReport

# 2. تنظيف:
flutter clean
cd android
.\gradlew clean
cd ..

# 3. إعادة التثبيت:
flutter pub get
flutter run -d <DEVICE_ID>
```

### الخطوات الأساسية:

1. ✅ استخراج SHA-1 و SHA-256
2. ✅ إضافتها في Firebase Console
3. ✅ تنزيل google-services.json الجديد
4. ✅ تفعيل Play Integrity API في Google Cloud
5. ✅ تسجيل Play Integrity في Firebase App Check
6. ✅ الكود جاهز (موجود بالفعل)
7. ✅ اختبار النتيجة

---

## 🎉 النتيجة المتوقعة

بعد إتمام جميع الخطوات:

### قبل:
```
المستخدم يرى صفحة ويب reCAPTCHA ❌
تجربة مزعجة ❌
وقت أطول ❌
```

### بعد:
```
تحقق خفي في الخلفية ✅
تجربة سلسة للمستخدم ✅
OTP يصل فوراً ✅
لا صفحات ويب ✅
أمان أقوى مع Play Integrity ✅
```

---

## 📞 الدعم

إذا واجهت أي مشكلة:

1. **راجع قسم "استكشاف الأخطاء" أعلاه**
2. **تحقق من Console Logs** في VS Code
3. **راجع Firebase Console → App Check → Metrics**
4. **تأكد من Google Cloud Console → Play Integrity API → Enabled**

---

**✨ بالتوفيق!**

---

**تم إنشاؤه**: 4 أكتوبر 2025  
**المشروع**: Zoli Chat  
**الهدف**: إخفاء reCAPTCHA تماماً من تجربة المستخدم  
**الطريقة**: Firebase App Check + Play Integrity API
