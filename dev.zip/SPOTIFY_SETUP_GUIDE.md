# دليل Spotify Integration 🎵

## نظرة عامة

تكامل Spotify API الرسمي في تطبيق Zoli Chat - **الخيار الأفضل للإنتاج!**

---

## ⭐ المميزات

### ✅ رسمي ومستقر
- API رسمي من Spotify
- توثيق شامل
- دعم طويل الأمد
- مجاني 100%

### 🎵 مكتبة ضخمة
- **100+ مليون تراك**
- جميع الأنواع الموسيقية
- تحديث مستمر
- جودة عالية

### 🔒 آمن وقانوني
- بدون انتهاك حقوق
- شروط استخدام واضحة
- مرخص للاستخدام

---

## 📋 خطوات الإعداد

### 1️⃣ إنشاء تطبيق Spotify

#### أ. التسجيل
```
1. اذهب إلى: https://developer.spotify.com/dashboard
2. سجل دخول بحساب Spotify (أو أنشئ حساب جديد)
3. اضغط "Create an App"
```

#### ب. معلومات التطبيق
```
App Name: Zoli Chat
App Description: Video chat application with music integration
Website: (اختياري)
Redirect URIs: http://localhost:8888/callback
```

#### ج. احفظ المعلومات
```
✅ Client ID: نسخ وحفظ
✅ Client Secret: اضغط "Show Client Secret" ثم نسخ
✅ Redirect URI: تأكد من الإضافة
```

---

### 2️⃣ إضافة المعلومات للتطبيق

#### الطريقة 1: تعديل مباشر (للتطوير)
في `lib/config/spotify_config.dart`:

```dart
class SpotifyConfig {
  static const String clientId = 'YOUR_CLIENT_ID_HERE';
  static const String clientSecret = 'YOUR_CLIENT_SECRET_HERE';
  // ...
}
```

#### الطريقة 2: Environment Variables (موصى به للإنتاج)
```bash
# تشغيل مع متغيرات البيئة
flutter run \
  --dart-define=SPOTIFY_CLIENT_ID=your_actual_client_id \
  --dart-define=SPOTIFY_CLIENT_SECRET=your_actual_secret
```

#### الطريقة 3: ملف .env (للإنتاج)
```bash
# أنشئ ملف .env
SPOTIFY_CLIENT_ID=your_client_id
SPOTIFY_CLIENT_SECRET=your_client_secret

# أضف في pubspec.yaml
dependencies:
  flutter_dotenv: ^5.1.0

# في main.dart
await dotenv.load();
final clientId = dotenv.env['SPOTIFY_CLIENT_ID'];
```

---

### 3️⃣ التحقق من الإعداد

```dart
import 'package:zoli_chat/config/spotify_config.dart';

void main() {
  if (SpotifyConfig.isConfigured) {
    print('✅ Spotify مُعد بنجاح!');
  } else {
    print('❌ الرجاء إعداد Spotify:');
    print(SpotifyConfig.configError);
  }
}
```

---

## 🎬 كيفية الاستخدام

### في التطبيق

#### 1. فتح محرر الفيديو
```
Blinks → Record/Upload → VideoEditorScreen
```

#### 2. اختر الموسيقى
```
اضغط زر "صوت" (Audio) في شريط الأدوات
```

#### 3. اختر المصدر
```
اضغط أيقونة الموسيقى في الأعلى
← المكتبة المحلية (10 تراكات)
← Spotify (ملايين التراكات)
```

#### 4. ابحث واختر
```
🔍 استخدم البحث
🏷️ صفّي حسب النوع
▶️ اضغط للاستماع (معاينة 30 ثانية)
✅ اضغط على البطاقة للاختيار
```

---

## 💻 استخدام API

### البحث عن موسيقى

```dart
import 'package:zoli_chat/services/spotify_service.dart';

final spotify = SpotifyService();

// المصادقة أولاً
await spotify.authenticate();

// البحث
final tracks = await spotify.searchTracks('summer vibes', limit: 20);

for (var track in tracks) {
  print('${track.title} by ${track.artist}');
}
```

### الحصول على التراكات الشائعة

```dart
final trending = await spotify.getTrendingTracks();

print('Found ${trending.length} trending tracks');
```

### البحث حسب النوع

```dart
final jazzTracks = await spotify.searchByGenre('jazz');
final rockTracks = await spotify.searchByGenre('rock');
```

### الحصول على معلومات تراك

```dart
final track = await spotify.getTrack('track_id_here');

if (track != null) {
  print('Title: ${track.title}');
  print('Artist: ${track.artist}');
  print('Duration: ${track.formattedDuration}');
  print('Preview URL: ${track.audioUrl}');
}
```

---

## 🎨 الأنواع المتاحة

```dart
// استخدم SpotifyService للحصول على قائمة كاملة
final genres = await spotify.getAvailableGenres();

print('Available genres: ${genres.join(', ')}');
```

### أمثلة شائعة:
- Pop
- Rock  
- Hip-Hop
- Electronic
- Jazz
- Classical
- Country
- R&B
- Indie
- Latin
- Metal
- Blues
- Folk
- Dance

---

## ⚠️ القيود والملاحظات

### 1. معاينة 30 ثانية
```
❗ Spotify API يوفر preview 30 ثانية فقط
✅ كافية للاستماع قبل الاختيار
⚠️ ليست كل التراكات لها preview
```

### 2. Client Credentials Flow
```
✅ للقراءة والبحث (مُطبق حالياً)
❌ لا يمكن الوصول لمكتبة المستخدم
❌ لا يمكن إنشاء playlists

للميزات المتقدمة: استخدم OAuth 2.0
```

### 3. Rate Limiting
```
⚠️ Spotify لديه حدود للطلبات
✅ النظام الحالي مناسب للاستخدام العادي
📊 للاستخدام المكثف: استخدم التخزين المؤقت
```

---

## 🔐 الأمان

### ✅ الممارسات الجيدة

#### 1. إخفاء Client Secret
```dart
// ❌ لا تضع في الكود مباشرة
static const clientSecret = 'abc123...';

// ✅ استخدم Environment Variables
static const clientSecret = String.fromEnvironment('SPOTIFY_CLIENT_SECRET');

// ✅ أو استخدم Backend
// أرسل الطلبات من Server بدلاً من Client
```

#### 2. استخدام .gitignore
```gitignore
# لا ترفع ملفات الإعدادات
.env
*.env
lib/config/*_private.dart
```

#### 3. Backend Integration (موصى به للإنتاج)
```
Client → Backend → Spotify API
     ↓       ↓
  نطلب   يخفي Client Secret
          ويُعيد النتائج
```

---

## 📊 مقارنة المصادر

| الميزة | المكتبة المحلية | Spotify |
|--------|-----------------|---------|
| **الحجم** | 10 تراكات | 100M+ |
| **الجودة** | كاملة | 30s preview |
| **القانونية** | ✅ آمن | ✅ آمن |
| **الاستقرار** | ✅ 100% | ✅ 99% |
| **السرعة** | ⚡ فوري | 🌐 يعتمد على الاتصال |
| **التكلفة** | مجاني | مجاني |
| **التحديث** | يدوي | تلقائي |

---

## 🔄 الميزات المتقدمة (اختياري)

### OAuth 2.0 للوصول لمكتبة المستخدم

```dart
// في SpotifyService
Future<void> authenticateWithOAuth() async {
  final grant = SpotifyApi.authorizationCodeGrant(
    SpotifyApiCredentials(
      SpotifyConfig.clientId,
      SpotifyConfig.clientSecret,
    ),
  );

  final authUri = grant.getAuthorizationUrl(
    Uri.parse(SpotifyConfig.redirectUri),
    scopes: SpotifyConfig.scopes,
  );

  // فتح المتصفح للمصادقة
  final result = await FlutterWebAuth.authenticate(
    url: authUri.toString(),
    callbackUrlScheme: 'http',
  );

  final code = Uri.parse(result).queryParameters['code'];
  
  // الحصول على Access Token
  final credentials = await grant.handleAuthorizationResponse(
    {'code': code!},
  );

  _spotify = SpotifyApi.fromCredentials(credentials);
}
```

### التخزين المؤقت

```dart
class SpotifyService {
  final Map<String, List<MusicTrack>> _searchCache = {};
  final Duration _cacheExpiry = const Duration(hours: 1);

  Future<List<MusicTrack>> searchTracks(String query) async {
    // تحقق من الذاكرة المؤقتة
    if (_searchCache.containsKey(query)) {
      return _searchCache[query]!;
    }

    // ابحث وخزن
    final tracks = await _performSearch(query);
    _searchCache[query] = tracks;

    return tracks;
  }
}
```

---

## 🐛 استكشاف الأخطاء

### المشكلة: "فشل الاتصال بـ Spotify"

**الحل:**
```
1. تحقق من Client ID و Client Secret
2. تأكد من الاتصال بالإنترنت
3. تحقق من Spotify Dashboard
4. جرب إعادة المصادقة
```

### المشكلة: "معاينة الصوت غير متاحة"

**الحل:**
```
ℹ️ ليست كل تراكات Spotify لها preview
✅ هذا طبيعي
🔄 جرب تراك آخر
```

### المشكلة: "Client ID غير صحيح"

**الحل:**
```
1. تحقق من النسخ بدون مسافات
2. تأكد من SpotifyConfig.clientId
3. أعد تشغيل التطبيق
```

### المشكلة: Rate Limit exceeded

**الحل:**
```
⏱️ انتظر دقيقة
💾 استخدم التخزين المؤقت
🎯 قلل عدد الطلبات
```

---

## 📈 الأداء

### تحسينات موصى بها

#### 1. Lazy Loading
```dart
// تحميل 20 تراك في كل مرة
final tracks = await spotify.searchTracks(query, limit: 20);

// للمزيد: استخدم offset
final moreTracks = await spotify.searchTracks(query, limit: 20, offset: 20);
```

#### 2. Image Caching
```dart
// استخدام cached_network_image (مُطبق)
CachedNetworkImage(
  imageUrl: track.coverArtUrl,
  placeholder: (context, url) => CircularProgressIndicator(),
  errorWidget: (context, url, error) => Icon(Icons.error),
)
```

#### 3. Debouncing للبحث
```dart
Timer? _searchDebounce;

void _onSearchChanged(String query) {
  _searchDebounce?.cancel();
  _searchDebounce = Timer(const Duration(milliseconds: 500), () {
    _searchTracks(query);
  });
}
```

---

## 🎯 أفضل الممارسات

### 1. معالجة الأخطاء
```dart
try {
  final tracks = await spotify.searchTracks(query);
  // استخدم التراكات
} on SpotifyException catch (e) {
  // خطأ من Spotify
  showError('Spotify error: ${e.message}');
} on SocketException {
  // خطأ اتصال
  showError('No internet connection');
} catch (e) {
  // أخطاء أخرى
  showError('Unknown error: $e');
}
```

### 2. تجربة المستخدم
```
✅ اعرض مؤشر تحميل
✅ رسائل خطأ واضحة
✅ معاينة سريعة
✅ حفظ التراك المختار
✅ مؤشر المصدر (Spotify/Local)
```

### 3. الاختبار
```dart
// اختبار البحث
test('search returns tracks', () async {
  final spotify = SpotifyService();
  await spotify.authenticate();
  final tracks = await spotify.searchTracks('test');
  expect(tracks.isNotEmpty, true);
});
```

---

## 📱 الواجهة

### الألوان

```dart
// Spotify Brand Colors
static const spotifyGreen = Color(0xFF1DB954);
static const spotifyBlack = Color(0xFF191414);
static const spotifyWhite = Color(0xFFFFFFFF);
```

### الأيقونات

```dart
// استخدام Ionicons
Ionicons.logo_spotify  // أيقونة Spotify
Ionicons.musical_notes // أيقونة المكتبة المحلية
```

---

## 📚 موارد إضافية

### التوثيق الرسمي
- [Spotify Web API](https://developer.spotify.com/documentation/web-api)
- [Spotify Dashboard](https://developer.spotify.com/dashboard)
- [API Reference](https://developer.spotify.com/documentation/web-api/reference)

### المكتبات
- [spotify (Dart package)](https://pub.dev/packages/spotify)
- [OAuth 2.0](https://pub.dev/packages/oauth2)

### أدوات
- [Spotify Console](https://developer.spotify.com/console) - اختبار API
- [Postman Collection](https://www.postman.com/spotify-api) - أمثلة

---

## 📝 الخلاصة

### ✅ الإعداد الأساسي (5 دقائق)
1. أنشئ تطبيق في Spotify Dashboard
2. انسخ Client ID و Client Secret
3. أضفهما في SpotifyConfig
4. شغل التطبيق

### 🎵 الاستخدام
- اختر Spotify من قائمة المصادر
- ابحث في ملايين التراكات
- استمع للمعاينة (30 ثانية)
- اختر واستخدم

### 🚀 للإنتاج
- استخدم Environment Variables
- أخفي Client Secret في Backend
- أضف التخزين المؤقت
- اختبر بشكل شامل

---

**🎉 تم! الآن لديك أكبر مكتبة موسيقى في العالم متاحة في تطبيقك!**

---

Made with ❤️ for Zoli Chat
