# 📲 FCM Topics - دليل سريع

## Topics الجديدة المطلوبة

يجب إنشاؤها في Firebase Console:

### 1. blinks-new
**الاستخدام**: إشعارات عن Blinks جديدة من المستخدمين المتابَعين

**مثال Payload**:
```json
{
  "notification": {
    "title": "فيديو جديد!",
    "body": "محمد نشر blink جديد"
  },
  "data": {
    "type": "blink",
    "id": "blink123",
    "action": "blink_published"
  },
  "topic": "blinks-new"
}
```

### 2. blinks-trending
**الاستخدام**: إشعارات عن Blinks الرائجة

**مثال Payload**:
```json
{
  "notification": {
    "title": "فيديو رائج! 🔥",
    "body": "شاهد أكثر الفيديوهات مشاهدة اليوم"
  },
  "data": {
    "type": "blink",
    "id": "blink456",
    "action": "blink_trending"
  },
  "topic": "blinks-trending"
}
```

### 3. system-announcements
**الاستخدام**: إعلانات النظام والأخبار

**مثال Payload**:
```json
{
  "notification": {
    "title": "ميزة جديدة!",
    "body": "الآن يمكنك إضافة موسيقى لفيديوهاتك"
  },
  "data": {
    "type": "system_alert",
    "action": "open_features"
  },
  "topic": "system-announcements"
}
```

### 4. maintenance
**الاستخدام**: إشعارات الصيانة

**مثال Payload**:
```json
{
  "notification": {
    "title": "صيانة مجدولة",
    "body": "سيكون التطبيق متوقفاً لمدة ساعة"
  },
  "data": {
    "type": "system_alert",
    "action": "maintenance_mode"
  },
  "topic": "maintenance"
}
```

---

## كيفية الاستخدام في الكود

### الاشتراك في Topic

```dart
import 'package:zoli_chat/services/fcm_service.dart';

// الاشتراك
await FCMService().subscribeToTopic('blinks-new');
await FCMService().subscribeToTopic('blinks-trending');

// أو باستخدام الـ Constants
await FCMService().subscribeToTopic(FCMTopics.blinksNew);
await FCMService().subscribeToTopic(FCMTopics.blinksTrending);
```

### إلغاء الاشتراك

```dart
await FCMService().unsubscribeFromTopic('blinks-new');
```

### استقبال الإشعار

```dart
// تلقائياً - FCMService معالج بالفعل
// انظر lib/services/fcm_service.dart للتفاصيل

// عند النقر على الإشعار:
// - type == "blink" → يفتح BlinkDetailScreen
// - type == "chat" → يفتح ChatScreen
```

---

## إرسال إشعار من Firebase Console

1. افتح Firebase Console
2. اذهب إلى **Cloud Messaging**
3. اضغط **Send your first message**
4. املأ:
   - **Notification title**: العنوان
   - **Notification text**: النص
5. اضغط **Next**
6. في **Target**:
   - اختر **Topic**
   - أدخل: `blinks-new` (أو أي topic)
7. اضغط **Next** ثم **Publish**

---

## إرسال إشعار من Backend/Server

### باستخدام Node.js (Firebase Admin SDK)

```javascript
const admin = require('firebase-admin');

// تهيئة
admin.initializeApp({
  credential: admin.credential.applicationDefault()
});

// إرسال إلى topic
const message = {
  notification: {
    title: 'فيديو جديد!',
    body: 'محمد نشر blink جديد'
  },
  data: {
    type: 'blink',
    id: 'blink123',
    action: 'blink_published'
  },
  topic: 'blinks-new'
};

admin.messaging().send(message)
  .then((response) => {
    console.log('Successfully sent message:', response);
  })
  .catch((error) => {
    console.log('Error sending message:', error);
  });
```

### باستخدام Cloud Functions

```javascript
const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

// عند نشر blink جديد
exports.onBlinkPublished = functions.firestore
  .document('reels/{blinkId}')
  .onUpdate(async (change, context) => {
    const after = change.after.data();
    const before = change.before.data();
    
    // إذا تغيرت الحالة من processing إلى published
    if (before.status === 'processing' && after.status === 'published') {
      // إرسال إشعار
      const message = {
        notification: {
          title: 'فيديو جديد! 🎬',
          body: `${after.title} منشور الآن`
        },
        data: {
          type: 'blink',
          id: context.params.blinkId,
          action: 'blink_published'
        },
        topic: 'blinks-new'
      };
      
      await admin.messaging().send(message);
    }
  });
```

---

## أنواع الإشعارات المدعومة

```dart
class NotificationType {
  static const String blinkPublished = 'blink_published';     // blink نُشر
  static const String blinkLiked = 'blink_liked';             // إعجاب بـ blink
  static const String blinkCommented = 'blink_commented';     // تعليق على blink
  static const String newFollower = 'new_follower';           // متابع جديد
  static const String newMessage = 'new_message';             // رسالة جديدة
  static const String systemAlert = 'system_alert';           // تنبيه النظام
}
```

---

## الخلاصة

- ✅ استخدم `blinks-new` للإشعارات عن Blinks جديدة
- ✅ استخدم `blinks-trending` للـ Trending Blinks
- ✅ FCMService جاهز ومهيأ بالكامل
- ✅ التعامل مع الإشعارات تلقائي

🚀 **جاهز للإطلاق!**
