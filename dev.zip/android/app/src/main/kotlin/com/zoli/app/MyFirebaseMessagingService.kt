package com.zoli.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        
        // Handle FCM messages here
        remoteMessage.notification?.let {
            // Notification payload
            val title = it.title
            val body = it.body
            // Handle notification
        }

        // Handle data payload
        if (remoteMessage.data.isNotEmpty()) {
            val data = remoteMessage.data
            // Handle data message
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Send token to server
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

            // High importance channel for important notifications
            val highChannel = NotificationChannel(
                "high_importance_channel",
                "High Importance Notifications",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Channel for important notifications like new ramshat and messages"
                enableLights(true)
                enableVibration(true)
            }

            // Default channel
            val defaultChannel = NotificationChannel(
                "default_channel",
                "Default Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Channel for general notifications"
            }

            // Low importance channel
            val lowChannel = NotificationChannel(
                "low_importance_channel",
                "Low Importance Notifications",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Channel for low priority notifications"
            }

            // Register channels
            notificationManager.createNotificationChannel(highChannel)
            notificationManager.createNotificationChannel(defaultChannel)
            notificationManager.createNotificationChannel(lowChannel)
        }
    }
}
