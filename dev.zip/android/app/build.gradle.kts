
plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
    id("com.google.firebase.firebase-perf")
}

android {
    namespace = "com.zoli.app"
    compileSdk = 36

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    defaultConfig {
        applicationId = "com.zoli.app"
        minSdk = 24
        targetSdk = 36
        versionCode = 2
        versionName = "1.1.0"
        multiDexEnabled = true
        
        // Production build configuration
        buildConfigField("String", "BUILD_TYPE", "\"release\"")
        buildConfigField("String", "FLAVOR", "\"prod\"")
    }

    signingConfigs {
        create("release") {
            // Production signing - use environment variables or gradle.properties
            storeFile = file(System.getenv("ZOLI_KEYSTORE_PATH") ?: "keystore/release.jks")
            storePassword = System.getenv("ZOLI_KEYSTORE_PASSWORD") ?: "zoli2025secure"
            keyAlias = System.getenv("ZOLI_KEY_ALIAS") ?: "zoli-release"
            keyPassword = System.getenv("ZOLI_KEY_PASSWORD") ?: "zoli2025secure"
        }
    }

    buildTypes {
        release {
            // Enable R8 full mode for maximum optimization
            isMinifyEnabled = true
            isShrinkResources = true
            
            // ProGuard/R8 rules
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            
            // Production signing with release keystore
            signingConfig = signingConfigs.getByName("release")
            
            // Production flags
            isDebuggable = false
            isJniDebuggable = false
            isPseudoLocalesEnabled = false
        }
        
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.firebase:firebase-analytics")
}
